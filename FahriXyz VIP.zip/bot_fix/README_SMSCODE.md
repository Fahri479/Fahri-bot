# Bot OTP — Nokos: smscode.gg | Deposit: Cashi.id | Auto Update Harga (multi-app)

## 1. WAJIB diisi di settings.js
```js
global.smscodeApiKey   = "ISI_TOKEN_SMSCODE_DISINI";   // smscode.gg → API Token
global.cashiApiKey     = "ISI_APIKEY_CASHI_DISINI";    // Cashi.id → Portal Merchant → API Key
global.cashiQrisCustom = false;   // true = nama merchant QRIS jadi NAMA TOKO (aktifkan dulu fiturnya di dashboard Cashi)
global.hargaChannel    = "";      // username channel broadcast harga TANPA @ (bot HARUS admin). kosong = pakai wajibJoinHarga
```

## 2. DEPOSIT via Cashi.id (sesuai docs final)
- Create : `POST https://cashi.id/api/create-order`  header `x-api-key`, body `{ amount, order_id, QRIS_CUSTOM? }`
- Status : `GET /api/check-status/:orderId` (bot juga otomatis coba `/order-status/:orderId` sebagai cadangan)
- amount: Min Rp 2.000 — Max Rp 10.000.000

Detail yang sudah disesuaikan dengan respons asli Cashi:
- **Auth** pakai header `x-api-key` (sesuai contoh curl di docs).
- **QR**: field `qrUrl` berisi **base64 (data:image/png;base64,...)**. Bot men-decode-nya jadi gambar dan mengirim langsung sebagai foto QRIS. (Kalau provider mengirim string QR biasa, bot bikin gambar otomatis.)
- **Kode unik**: kamu minta mis. Rp 50.000, Cashi menambah kode unik kecil → user bayar mis. **Rp 50.042**. Saldo user dikredit **Rp 50.000** (nominal yang diminta). `expected_net` = yang diterima owner setelah fee.
- **Cek status**: bot pakai `order_id` yang dibuat sendiri (`DEP-...`), selaras dengan webhook (`data.order_id`). Begitu **SETTLED → saldo user nambah otomatis**.
- Verifikasi cepat: owner kirim `/cekcashi` → tampil respons MENTAH (pastikan ada `qrUrl` & `amount`).

## 3. AUTO UPDATE HARGA — multi aplikasi & multi negara
```js
global.hargaMonitorOn   = true;
global.hargaApps        = ["WhatsApp", "Telegram", "Facebook", "Google", "Instagram"];  // tambah sesukamu
global.hargaCountries   = ["Indonesia"];   // bisa banyak: ["Indonesia","Malaysia","Philippines"]
global.hargaIntervalMenit = 30;
```
- Bot memantau **setiap aplikasi × setiap negara** di daftar itu.
- Tiap grup yang harganya **NAIK/TURUN** dibroadcast TERPISAH ke channel, dengan **keterangan aplikasi + negara** di header (mis. "📈 UPDATE HARGA WHATSAPP / 📍 Negara: Indonesia").
- Format mengikuti contohmu (Total Server, Stok Total, daftar Server, blok ACTION) + tombol:
  💬 Customer Service · 🤖 Order Nokos · 📢 Channel Utama · 💰 Callback Transaksi · 📈 Callback Harga
  (link otomatis dari settings).
- Run pertama = simpan baseline (tidak broadcast). Nomor "Server" stabil per grup (disimpan di `database/harga_snapshot.json`).
- Manual: owner kirim `/cekharga`.
- Catatan: harga yang ditampilkan = harga JUAL (modal smscode + markup `profitUser`). Kalau smscode tak punya "Rate", baris Rate disembunyikan otomatis.

## 4. Perintah owner
- `/cekapi`   → diagnosa smscode.
- `/cekcashi` → tes create-order Cashi, tampilkan respons mentah (verifikasi field QR).
- `/cekharga` → cek & broadcast harga sekarang.

## 5. Catatan
- Fee Cashi (mis. 3%) ditanggung dari sisi owner (selisih amount vs expected_net). Atur markup `profitUser`/`profitVip` untuk menutup fee.
- Gateway lama (YoBasePay & mbjebe) sudah dihapus total — Cashi.id only.
