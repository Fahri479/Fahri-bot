kami melarang sc ini di perjual belikann, kami menyediakan sc ini
karena keinginan kita supaya para seller di mb jebe 
bisa jual nokos otomtais
mbjebe.store
- `grupNotifDeposit` & `grupNotifPembelian` → ID grup notif

### LANGKAH 3 — Install PM2

```bash
npm install -g pm2
```

### LANGKAH 4 — Jalankan Bot dengan PM2

```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
# Jalankan perintah yang muncul dari pm2 startup
```

### LANGKAH 5 — Buka Port Webhook (untuk SekalIPay)

```bash
ufw allow 3055
ufw reload
```

Daftarkan URL webhook di dashboard SekalIPay:
```
http://IP_VPS_KAMU:3055/webhook/sekalipay
```

### LANGKAH 6 — Setup Whitelist IP (opsional tapi disarankan)

Cek IP VPS:
```bash
curl ifconfig.me
```

Daftarkan IP ini di:
- SekalIPay → Settings → IP Whitelist
- WarungNokos → Profile → API Settings
- SMSCode.gg → Account → Allowed IPs
- RamaShop → Dashboard → API Settings

---

### PERINTAH PM2 BERGUNA

```bash
pm2 status          # lihat status bot
pm2 logs warungkos-bot   # lihat log real-time
pm2 restart warungkos-bot  # restart manual
pm2 stop warungkos-bot    # stop bot
pm2 monit           # monitor CPU/RAM
```

---

### ESTIMASI KAPASITAS

| Kondisi | Status |
|---|---|
| 1-200 user aktif bersamaan | ✅ Stabil |
| 200-500 user aktif bersamaan | ✅ Stabil dengan PM2 |
| 500-1000 user aktif bersamaan | ✅ Stabil, pantau RAM |
| 1000+ user bersamaan | ⚠️ Pertimbangkan upgrade RAM VPS ke 2GB+ |

Rekomendasi VPS minimum untuk 700+ user:
- **RAM:** 1 GB (2 GB lebih baik)
- **CPU:** 1 vCore
- **Storage:** 10 GB
- **OS:** Ubuntu 22.04

---

### KENAPA BOT BISA DOWN DAN SUDAH DIPERBAIKI

| # | Masalah | Solusi |
|---|---|---|
| 1 | `global.appList` shared semua user (data saling timpa) | Per-user session cache |
| 2 | `JSON.parse(readFileSync)` crash kalau file korup | `safeReadJSON()` dengan fallback |
| 3 | Polling interval tidak berhenti saat bot restart | `registerPolling` + `unregisterPolling` tracker |
| 4 | `uncaughtException` hanya log, tidak restart | Sekarang `process.exit(1)` → PM2 restart |
| 5 | Tidak ada process manager | PM2 dengan auto-restart |
| 6 | Axios tanpa timeout → bot freeze | Timeout 15 detik di setiap request |
| 7 | DB write bersamaan → file korup | Write queue (sudah ada sejak v2) |
