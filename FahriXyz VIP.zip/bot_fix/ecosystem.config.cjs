// =====================================================
// PM2 ECOSYSTEM CONFIG - WARUNG KOS BOT
// =====================================================
// Cara pakai:
//   npm install -g pm2
//   pm2 start ecosystem.config.cjs
//   pm2 save
//   pm2 startup   ← lalu jalankan perintah yang muncul
// =====================================================

module.exports = {
    apps: [
        {
            name: "warungkos-bot",
            script: "index.js",

            // ── Interpreter ──
            interpreter: "node",
            interpreter_args: "--experimental-vm-modules",

            // ── Auto restart ──
            watch: false,               // jangan watch file (boros CPU)
            autorestart: true,          // restart kalau crash
            restart_delay: 3000,        // tunggu 3 detik sebelum restart
            max_restarts: 20,           // maks 20x restart dalam 1 jam
            min_uptime: "10s",          // kalau mati < 10 detik → crash count naik

            // ── Memory ──
            max_memory_restart: "400M", // restart kalau makan RAM > 400MB

            // ── Logs ──
            log_date_format: "YYYY-MM-DD HH:mm:ss",
            out_file: "./logs/out.log",
            error_file: "./logs/error.log",
            merge_logs: true,
            log_type: "json",

            // ── Environment ──
            env: {
                NODE_ENV: "production",
                TZ: "Asia/Jakarta"
            }
        }
    ]
};
