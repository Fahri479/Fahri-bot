process.on("unhandledRejection", (reason) => {
    console.error("[UNHANDLED REJECTION]", reason);
    // Jangan crash untuk Promise rejection biasa (misal API timeout)
    // Cukup log dan lanjut
});

process.on("uncaughtException", (err) => {
    console.error("[UNCAUGHT EXCEPTION]", err);
    // Untuk error fatal yang tidak bisa dipulihkan, exit supaya PM2 bisa restart
    // Tunggu 1 detik supaya log sempat tertulis
    setTimeout(() => process.exit(1), 1000);
});

import fs from "fs";
import chalk from "chalk";
import { Telegraf } from "telegraf";
import "./settings.js";

// ── LOAD RUNTIME CONFIG (toggleable dari admin panel) ──
try {
    const rcPath = "./database/runtime_config.json";
    if (fs.existsSync(rcPath)) {
        const rc = JSON.parse(fs.readFileSync(rcPath, "utf-8"));
        if (typeof rc.maintenanceEnabled === "boolean") {
            global.maintenanceEnabled = rc.maintenanceEnabled;
            console.log(chalk.cyan(`Runtime config: maintenanceEnabled=${rc.maintenanceEnabled}`));
        }
    } else {
        if (!fs.existsSync("./database")) fs.mkdirSync("./database", { recursive: true });
    }
} catch (e) { console.warn("Runtime config load error:", e.message); }

import main from "./main.js";

const bot = new Telegraf(global.botToken);

// ================= TIME =================
function getTime() {
    const date = new Date(Date.now() + 7 * 60 * 60 * 1000); // WIB

    const hari  = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
    const bulan = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];

    return {
        hari: hari[date.getDay()],
        tanggalISO: date.toISOString().slice(0, 10),
        tanggal: `${date.getDate()} ${bulan[date.getMonth()]} ${date.getFullYear()}`,
        waktu: date.toTimeString().split(" ")[0]
    };
}

// ================= LOGGER =================
function box(title, content, color = chalk.cyan) {
    const line = "─".repeat(45);
    return `\n${color(`┌─[ ${title} ]${"─".repeat(45 - title.length)}`)}\n${content}${color(`└${line}`)}\n`;
}

function tag(ctx) {
    return ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.first_name} (${ctx.from.id})`;
}

// ================= PATH =================
const DB_DIR = "./database";
const TRANSACTIONS_PATH = `${DB_DIR}/transactions.json`;
const WEEKLY_REKAP_PATH = `${DB_DIR}/weekly_rekap.json`;

// ================= ENSURE FILE =================
function ensureDB() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
    if (!fs.existsSync(TRANSACTIONS_PATH)) fs.writeFileSync(TRANSACTIONS_PATH, JSON.stringify({}, null, 2));
    if (!fs.existsSync(WEEKLY_REKAP_PATH)) fs.writeFileSync(
        WEEKLY_REKAP_PATH,
        JSON.stringify({ last_sent: null, reports: [] }, null, 2)
    );
}

// ================= HITUNG REKAP =================
function generateWeeklyRekap() {
    ensureDB();
    const trxData = JSON.parse(fs.readFileSync(TRANSACTIONS_PATH));
    const users = Object.values(trxData).flat();

    let result = {
        total: 0,
        success: 0,
        expired: 0,
        canceled: 0,
        finance: { modal: 0, jual: 0, profit: 0 },
        vip: { success: 0, failed: 0, jual: 0, profit: 0 },
        regular: { success: 0, failed: 0, jual: 0, profit: 0 },
        owner: { success: 0, failed: 0, keluar: 0 }
    };

    for (let t of users) {
        result.total++;

        if (t.status === "success") result.success++;
        if (t.status === "expired") result.expired++;
        if (t.status === "canceled") result.canceled++;

        if (t.user_type !== "owner" && t.status === "success") {
            result.finance.modal += t.price_api;
            result.finance.jual += t.price_sell;
            result.finance.profit += t.profit;
        }

        if (t.user_type === "vip") {
            if (t.status === "success") {
                result.vip.success++;
                result.vip.jual += t.price_sell;
                result.vip.profit += t.profit;
            } else result.vip.failed++;
        }

        if (t.user_type === "regular") {
            if (t.status === "success") {
                result.regular.success++;
                result.regular.jual += t.price_sell;
                result.regular.profit += t.profit;
            } else result.regular.failed++;
        }

        if (t.user_type === "owner") {
            if (t.status === "success") {
                result.owner.success++;
                result.owner.keluar += t.price_api;
            } else result.owner.failed++;
        }
    }

    return result;
}

// ================= FORMAT MESSAGE =================
function formatRekapMessage(r) {
    return `
📊 *REKAP MINGGUAN BOT OTP*

📦 Total Transaksi: ${r.total}
✅ Sukses : ${r.success}
⌛ Expired : ${r.expired}
❌ Cancel : ${r.canceled}

💰 *Keuangan (NON-OWNER)*
Modal API : Rp ${r.finance.modal.toLocaleString()}
Penjualan : Rp ${r.finance.jual.toLocaleString()}
Profit    : Rp ${r.finance.profit.toLocaleString()}

👑 *VIP*
• ${r.vip.success} sukses / ${r.vip.failed} gagal
• Penjualan : Rp ${r.vip.jual.toLocaleString()}
• Profit    : Rp ${r.vip.profit.toLocaleString()}

👤 *Regular*
• ${r.regular.success} sukses / ${r.regular.failed} gagal
• Penjualan : Rp ${r.regular.jual.toLocaleString()}
• Profit    : Rp ${r.regular.profit.toLocaleString()}

🛠 *OWNER*
• ${r.owner.success} sukses / ${r.owner.failed} gagal
• Pengeluaran : Rp ${r.owner.keluar.toLocaleString()}
`;
}

// ================= KIRIM & RESET =================
async function sendWeeklyRekap(bot) {
    const t = getTime();
    ensureDB();

    const rekap = generateWeeklyRekap();
    const msg = formatRekapMessage(rekap);

    for (let owner of global.ownerID) {
        await bot.telegram.sendMessage(owner, msg, { parse_mode: "Markdown" });
    }

    const weekly = JSON.parse(fs.readFileSync(WEEKLY_REKAP_PATH));
    weekly.last_sent = t.tanggalISO;
    weekly.reports.push({ date: t.tanggalISO, ...rekap });
    fs.writeFileSync(WEEKLY_REKAP_PATH, JSON.stringify(weekly, null, 2));

    fs.writeFileSync(TRANSACTIONS_PATH, JSON.stringify({}, null, 2));
}

// ================= LOG + SCHEDULER =================
bot.use(async (ctx, next) => {
    const t = getTime();

    if (ctx.message?.text) {
        console.log(box("MESSAGE", `
📅 ${t.tanggal}
🗓 ${t.hari}
⏱ ${t.waktu}
👤 ${tag(ctx)}
💬 ${ctx.message.text}
`, chalk.blue));
    }

    if (ctx.callbackQuery) {
        console.log(box("CALLBACK", `
📅 ${t.tanggal}
🗓 ${t.hari}
⏱ ${t.waktu}
👤 ${tag(ctx)}
🔘 ${ctx.callbackQuery.data}
`, chalk.yellow));
    }

    try {
        if (
            t.hari === "Minggu" &&
            t.waktu >= "23:59"
        ) {
            ensureDB();
            const weekly = JSON.parse(fs.readFileSync(WEEKLY_REKAP_PATH));
            if (weekly.last_sent !== t.tanggalISO) {
                console.log(chalk.magenta("📊 Mengirim rekap mingguan..."));
                await sendWeeklyRekap(bot);
            }
        }
    } catch (e) {
        console.log(chalk.red("REKAP ERROR:"), e);
    }

    return next();
});

// ================= LOAD MAIN BOT FEATURE =================
main(bot);

// ================= GLOBAL ERROR HANDLER (PENTING untuk ribuan user) =================
// Menangkap semua error dari handler Telegraf supaya bot tidak mati
bot.catch((err, ctx) => {
    const userId = ctx?.from?.id || "?";
    const action = ctx?.callbackQuery?.data || ctx?.message?.text || "?";
    console.error(`[BOT ERROR] User:${userId} Action:${action}`, err?.message || err);
    // Balas user supaya tidak stuck loading
    try {
        if (ctx?.callbackQuery) {
            ctx.answerCbQuery("❌ Terjadi kesalahan. Silakan coba lagi.").catch(() => {});
        } else if (ctx?.reply) {
            ctx.reply("❌ Terjadi kesalahan. Silakan coba lagi.").catch(() => {});
        }
    } catch {}
});

// ================= START BOT =================
bot.launch({
    // Drop update yang menumpuk saat bot restart (penting jika bot down lama)
    dropPendingUpdates: true,
    // Timeout 30 detik per handler (cegah hang)
    handlerTimeout: 30_000
});
console.log(chalk.green(`🤖 Bot ${global.botName} berjalan...`));

// Graceful shutdown
process.once("SIGINT",  () => { console.log("SIGINT — stopping bot..."); bot.stop("SIGINT"); });
process.once("SIGTERM", () => { console.log("SIGTERM — stopping bot..."); bot.stop("SIGTERM"); });

// ================= HOT RELOAD =================
const file = import.meta.url.replace("file://", "");
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Reloading ${file}`));
    process.exit(0);
});