
import axios from "axios";
import chalk from "chalk";
import fs from "fs";
import moment from "moment-timezone";
import {
    isRateLimited,
    getSession, setSession,
    registerPolling, unregisterPolling,
    queueWrite,
    safeReadJSON,
    safeSend,
    sleep,
    axiosWithRetry
} from "./stability.js";

// ======================================================
// ================= SCHEDULED TASKS ===================
// ======================================================

// ── MAINTENANCE TIME CHECK ──────────────────────────────
// Format jam: "HH:MM" → return true jika sekarang dalam window maintenance
function isMaintenanceTime() {
    if (!global.maintenanceEnabled) return false;
    const now   = moment().tz("Asia/Jakarta");
    const [sh, sm] = (global.maintenanceStart || "23:00").split(":").map(Number);
    const [eh, em] = (global.maintenanceEnd   || "00:10").split(":").map(Number);

    const nowMin   = now.hour() * 60 + now.minute();
    const startMin = sh * 60 + sm;
    const endMin   = eh * 60 + em;

    // Kalau end < start (lewat tengah malam, contoh 23:00–00:10)
    if (endMin < startMin) {
        return nowMin >= startMin || nowMin < endMin;
    }
    return nowMin >= startMin && nowMin < endMin;
}

// State untuk track apakah notif maintenance sudah dikirim
let maintenanceNotifSent = { start: false, end: false };

async function cekJadwalMaintenance(bot) {
    if (!global.maintenanceEnabled) return;
    const now    = moment().tz("Asia/Jakarta");
    const hhmm   = now.format("HH:mm");

    // Notif MULAI maintenance (kirim 1x saat jam mulai)
    if (hhmm === global.maintenanceStart && !maintenanceNotifSent.start) {
        maintenanceNotifSent.start = true;
        maintenanceNotifSent.end   = false; // reset
        const msg =
            `🔧 <b>BOT MAINTENANCE DIMULAI</b>\n\n` +
            `Bot akan ditutup sementara untuk perbaikan dari pukul <b>${global.maintenanceStart}</b> sampai <b>${global.maintenanceEnd} WIB</b>.\n\n` +
            `⏰ Mulai: ${now.format("YYYY-MM-DD HH:mm:ss")} WIB\n\n` +
            `Mohon maaf atas ketidaknyamanannya. Bot akan kembali normal setelah maintenance selesai. 🙏`;
        if (global.grubinformasi) {
            try { await bot.telegram.sendMessage(global.grubinformasi, msg, { parse_mode: "HTML" }); } catch {}
        }
    }

    // Notif SELESAI maintenance (kirim 1x saat jam selesai)
    if (hhmm === global.maintenanceEnd && !maintenanceNotifSent.end) {
        maintenanceNotifSent.end   = true;
        maintenanceNotifSent.start = false; // reset
        const msg =
            `✅ <b>BOT SUDAH NORMAL KEMBALI!</b>\n\n` +
            `Maintenance selesai pada pukul <b>${global.maintenanceEnd} WIB</b>.\n` +
            `Bot sudah bisa digunakan lagi.\n\n` +
            `⏰ Selesai: ${now.format("YYYY-MM-DD HH:mm:ss")} WIB\n\n` +
            `Terima kasih atas kesabarannya! 🎉`;
        if (global.grubinformasi) {
            try { await bot.telegram.sendMessage(global.grubinformasi, msg, { parse_mode: "HTML" }); } catch {}
        }
    }
}

async function kirimLaporanPenjualan(bot) {
    try {
        const sendLaporan = async (tipe, check) => {
            if (!check) return;
            const laporan = await buatLaporanPenjualan(tipe);
            for (const owner of global.ownerID) {
                try { await bot.telegram.sendMessage(owner, laporan, { parse_mode: "HTML" }); }
                catch (e) { console.error(`LAPORAN ${tipe} KE ${owner}:`, e.message); }
            }
        };
        await sendLaporan("harian",   global.laporanHarian   && saatnyaLaporanHarian());
        await sendLaporan("mingguan", global.laporanMingguan && saatnyaLaporanMingguan());
        await sendLaporan("bulanan",  global.laporanBulanan  && saatnyaLaporanBulanan());
    } catch (e) {
        console.error("LAPORAN ERROR:", e.message);
    }
}

function saatnyaLaporanHarian() {
    const now = moment().tz("Asia/Jakarta");
    return now.hour() === 23 && now.minute() === 59;
}
function saatnyaLaporanMingguan() {
    const now = moment().tz("Asia/Jakarta");
    return now.day() === 0 && now.hour() === 23 && now.minute() === 59;
}
function saatnyaLaporanBulanan() {
    const now = moment().tz("Asia/Jakarta");
    return now.date() === now.daysInMonth() && now.hour() === 23 && now.minute() === 59;
}

async function buatLaporanPenjualan(periode) {
    ensureTransactionsDB();
    const db = safeReadJSON(transactionsPath,{});
    let totalPenjualan = 0, totalProfit = 0;
    const now = moment().tz("Asia/Jakarta");

    for (const userId in db) {
        for (const trx of db[userId]) {
            const trxDate = moment(trx.finished_at, "YYYY-MM-DD HH:mm:ss").tz("Asia/Jakarta");
            let dalamPeriode = false;
            if (periode === "harian" && trxDate.isSame(now, "day")) dalamPeriode = true;
            if (periode === "mingguan" && trxDate.isSame(now, "isoWeek")) dalamPeriode = true;
            if (periode === "bulanan" && trxDate.isSame(now, "month")) dalamPeriode = true;
            if (dalamPeriode && trx.status === "success" && trx.service !== "Deposit") {
                totalPenjualan += Number(trx.price_sell || 0);
                totalProfit += Number(trx.profit || 0);
            }
        }
    }

    return `<b>📊 Laporan Penjualan ${periode.charAt(0).toUpperCase() + periode.slice(1)}</b>\n\nTotal Penjualan: <b>Rp ${totalPenjualan.toLocaleString("id-ID")}</b>\nTotal Profit: <b>Rp ${totalProfit.toLocaleString("id-ID")}</b>\n\nDibuat: ${now.format("YYYY-MM-DD HH:mm:ss")}`;
}

async function safeEditOrReply(ctx, text, options = {}) {
    if (!ctx.callbackQuery?.message) return ctx.reply(text, options).catch(() => {});
    try {
        return await ctx.editMessageText(text, options);
    } catch (err) {
        // Jika gagal edit (misal pesan foto), hapus pesan lama lalu kirim baru
        try { await ctx.deleteMessage(); } catch {}
        try { await ctx.answerCbQuery(); } catch {}
        return ctx.reply(text, options).catch(() => {});
    }
}

// Wrapper: setiap handler action/command auto di-wrap try-catch
// Jika terjadi error apapun, user dapat pesan error dan tidak stuck
function safeHandler(fn) {
    return async (ctx) => {
        try {
            await fn(ctx);
        } catch (err) {
            const uid  = ctx?.from?.id || "?";
            const data = ctx?.callbackQuery?.data || ctx?.message?.text?.slice(0, 30) || "?";
            console.error(`[HANDLER ERROR] uid=${uid} data=${data}:`, err.message);
            try {
                if (ctx?.callbackQuery) await ctx.answerCbQuery("❌ Error, coba lagi.", { show_alert: false }).catch(() => {});
                else await ctx.reply("❌ Terjadi kesalahan, silakan coba lagi.").catch(() => {});
            } catch {}
        }
    };
}

// ======================================================
// ================ WAJIB JOIN CHECK ====================
// ======================================================

// Cek apakah bot adalah admin di chat tertentu
async function isBotAdmin(bot, chatUsername) {
    try {
        const botInfo = await bot.telegram.getMe();
        const botMember = await bot.telegram.getChatMember(`@${chatUsername}`, botInfo.id);
        return ["administrator", "creator"].includes(botMember?.status);
    } catch (e) {
        console.warn(`CEK ADMIN BOT @${chatUsername} ERROR:`, e.message);
        return false;
    }
}

async function cekWajibJoin(bot, userId) {
    const hasil = { harus: false, belumJoin: [], botBukanAdmin: [] };

    if (global.wajibJoinSaluran) {
        const namaSaluran = global.wajibJoinSaluranNama || `Channel @${global.wajibJoinSaluran}`;
        // Cek dulu apakah bot admin di channel ini
        const botAdmin = await isBotAdmin(bot, global.wajibJoinSaluran);
        if (!botAdmin) {
            // Bot bukan admin → tidak bisa cek member → blokir semua user
            console.warn(`[WAJIB JOIN] Bot bukan admin di @${global.wajibJoinSaluran} - semua user diblokir`);
            hasil.belumJoin.push({ nama: namaSaluran, link: `https://t.me/${global.wajibJoinSaluran}` });
            hasil.botBukanAdmin.push(namaSaluran);
        } else {
            try {
                const member = await bot.telegram.getChatMember(`@${global.wajibJoinSaluran}`, userId);
                const status = member?.status;
                if (!["member", "administrator", "creator"].includes(status)) {
                    hasil.belumJoin.push({ nama: namaSaluran, link: `https://t.me/${global.wajibJoinSaluran}` });
                }
            } catch (e) {
                console.warn("CEK MEMBER SALURAN ERROR:", e.message);
                hasil.belumJoin.push({ nama: namaSaluran, link: `https://t.me/${global.wajibJoinSaluran}` });
            }
        }
    }

    if (global.wajibJoinGrup) {
        const namaChannel2 = global.wajibJoinGrupNama || `Channel @${global.wajibJoinGrup}`;
        // Cek dulu apakah bot admin di channel ini
        const botAdmin = await isBotAdmin(bot, global.wajibJoinGrup);
        if (!botAdmin) {
            console.warn(`[WAJIB JOIN] Bot bukan admin di @${global.wajibJoinGrup} - semua user diblokir`);
            hasil.belumJoin.push({ nama: namaChannel2, link: `https://t.me/${global.wajibJoinGrup}` });
            hasil.botBukanAdmin.push(namaChannel2);
        } else {
            try {
                const member = await bot.telegram.getChatMember(`@${global.wajibJoinGrup}`, userId);
                const status = member?.status;
                if (!["member", "administrator", "creator"].includes(status)) {
                    hasil.belumJoin.push({ nama: namaChannel2, link: `https://t.me/${global.wajibJoinGrup}` });
                }
            } catch (e) {
                console.warn("CEK MEMBER CHANNEL 2 ERROR:", e.message);
                hasil.belumJoin.push({ nama: namaChannel2, link: `https://t.me/${global.wajibJoinGrup}` });
            }
        }
    }

    if (global.wajibJoinHarga) {
        const namaHarga = global.wajibJoinHargaNama || `Channel @${global.wajibJoinHarga}`;
        const botAdmin = await isBotAdmin(bot, global.wajibJoinHarga);
        if (!botAdmin) {
            console.warn(`[WAJIB JOIN] Bot bukan admin di @${global.wajibJoinHarga} - semua user diblokir`);
            hasil.belumJoin.push({ nama: namaHarga, link: `https://t.me/${global.wajibJoinHarga}` });
            hasil.botBukanAdmin.push(namaHarga);
        } else {
            try {
                const member = await bot.telegram.getChatMember(`@${global.wajibJoinHarga}`, userId);
                const status = member?.status;
                if (!["member", "administrator", "creator"].includes(status)) {
                    hasil.belumJoin.push({ nama: namaHarga, link: `https://t.me/${global.wajibJoinHarga}` });
                }
            } catch (e) {
                console.warn("CEK MEMBER CHANNEL HARGA ERROR:", e.message);
                hasil.belumJoin.push({ nama: namaHarga, link: `https://t.me/${global.wajibJoinHarga}` });
            }
        }
    }

    if (hasil.belumJoin.length > 0) hasil.harus = true;
    return hasil;
}

function pesanWajibJoin(belumJoin, userInfo = {}) {
    const namaUser = userInfo.first_name || userInfo.username || "User";
    const idUser   = userInfo.id || "-";

    // Buat daftar channel yang belum dijoin dengan format rapi
    const listBelum = belumJoin.map(item => {
        const username = item.link.replace("https://t.me/", "");
        return `• @${username} — ${item.nama}`;
    }).join("\n");

    const teks =
        `🔐 <b>VERIFIKASI KEANGGOTAAN</b>\n\n` +
        `👤 <b>Nama:</b> ${namaUser}\n` +
        `🪪 <b>ID:</b> <code>${idUser}</code>\n\n` +
        `⚠️ <b>AKSES DITOLAK</b>\n` +
        `Anda harus bergabung ke semua channel\n` +
        `terlebih dahulu untuk menggunakan bot ini.\n\n` +
        `📋 <b>PETUNJUK</b>\n` +
        `1. Join semua channel di bawah\n` +
        `2. Klik "🔄 Cek Ulang Keanggotaan"\n` +
        `3. Atau kirim /start lagi\n\n` +
        `📢 <b>CHANNEL YANG HARUS DIJOIN:</b>\n` +
        `${listBelum}`;

    // Buat tombol inline per channel yang belum dijoin
    // Ditambah tombol "Cek Ulang Keanggotaan" di baris terakhir
    const keyboard = {
        inline_keyboard: [
            // Tombol join untuk setiap channel yang belum diikuti
            ...belumJoin.map(item => {
                const username = item.link.replace("https://t.me/", "");
                // FIX: case-insensitive supaya "Log Transaksi" / "log" juga match, bukan hanya "LOG"
                const namaLower = item.nama.toLowerCase();
                const icon = (namaLower.includes("log") || namaLower.includes("transaksi") || namaLower.includes("proof"))
                    ? "📋" : "📢";
                return [{ text: `${icon} Join ${item.nama}`, url: item.link }];
            }),
            // Tombol cek ulang keanggotaan
            [{ text: "🔄 Cek Ulang Keanggotaan", callback_data: "cek_join" }]
        ]
    };

    return { teks, keyboard };
}

// ======================================================
// ================= TRANSACTION HISTORY ================
// ======================================================

const transactionsPath = "./database/transactions.json";

function ensureTransactionsDB() {
    if (!fs.existsSync("./database")) fs.mkdirSync("./database", { recursive: true });
    if (!fs.existsSync(transactionsPath)) fs.writeFileSync(transactionsPath, JSON.stringify({}, null, 2));
}

function getUserType(userId, userObj) {
    if (global.ownerID.includes(String(userId))) return "owner";
    if (userObj?.vip) return "vip";
    return "regular";
}

function estimatePriceApi(priceSell, userType) {
    if (userType === "owner") return priceSell;
    const p = userType === "vip" ? Number(global.profitVip || 0) : Number(global.profitUser || 0);
    const denom = 1 + p / 100;
    if (!isFinite(denom) || denom <= 0) return priceSell;
    return Math.round(priceSell / denom);
}

// Bersihkan nama produk dari tanda dolar ($0.xxxx)
function cleanProductName(name) {
    if (!name) return name;
    return String(name)
        .replace(/\s*\(\$[0-9.]+\)/g, "")  // hapus ($0.1630)
        .replace(/\s*\$[0-9.]+/g, "")       // hapus $0.1630 tanpa kurung
        .replace(/\s*—\s*$/, "")             // hapus dash di akhir
        .trim();
}

function saveFinalTransaction(trxActive, extra) {
    return queueWrite(() => {
        ensureTransactionsDB();
        const db = safeReadJSON(transactionsPath,{});
        const uid = String(trxActive.user_id);
        if (!db[uid]) db[uid] = [];
        db[uid].push({ ...trxActive, ...extra });
        fs.writeFileSync(transactionsPath, JSON.stringify(db, null, 2));
    });
}

// ======================================================
// ====================== DATABASE ======================
// ======================================================

const userDBPath = "./database/user.json";

function ensureFile(p, defaultData) {
    if (!fs.existsSync(p)) {
        const dir = p.substring(0, p.lastIndexOf("/"));
        if (dir && !fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(p, JSON.stringify(defaultData, null, 2));
    }
}

function loadDB() {
    ensureFile(userDBPath, { users: {} });
    return safeReadJSON(userDBPath,{users:{}});
}

function saveDB(db) {
    return queueWrite(() => {
        fs.writeFileSync(userDBPath, JSON.stringify(db, null, 2));
    });
}

async function sendLog(bot, groupId, message) {
    try {
        await bot.telegram.sendMessage(groupId, message, { parse_mode: "HTML" });
    } catch (e) {
        console.error(`Gagal kirim log ke grup ${groupId}:`, e.message);
    }
}

// Helper: kirim notif auto-up ke channel/grup dengan inline keyboard tombol ORDER SEKARANG
// Bot HARUS admin di channel agar bisa posting
// Tombol ORDER SEKARANG langsung buka @FahriXyz_OTP_bot
async function autoUpSend(bot, chatTarget, message, botUsername) {
    // Tombol 5 baris sesuai tampilan channel transaksi profesional
    // Data: CS @Fahr1Xyz | Order @FahriXyz_OTP_bot | Channel @FahriXyz_OTP | Callbacktrx @Proof_Fahr1Xyz | CallbackHarga
    const csUsername       = global.csUsername       || "Fahr1Xyz";
    const orderBotUsername = global.botUsername      || botUsername || "FahriXyz_OTP_bot";
    const channelUsername  = global.wajibJoinSaluran || "FahriXyz_OTP";
    const callbackChannel  = global.callbackChannel  || "Proof_Fahr1Xyz";
    const callbackHarga  = global.callbackHarga  || "Proof_Fahr1Xyz";

    const keyboard = {
        inline_keyboard: [
            [{ text: "💬 Customer Service",    url: `https://t.me/${csUsername}` }],
            [{ text: "🤖 Order Layanan",        url: `https://t.me/${orderBotUsername}` }],
            [{ text: "📢 Channel Utama",        url: `https://t.me/${channelUsername}` }],
            [{ text: "💰 Callback Transaksi",   url: `https://t.me/${callbackChannel}` }],
            [{ text: "📈 Callback Harga",   url: `https://t.me/${callbackHarga}` }],
        ]
    };
    try {
        await bot.telegram.sendMessage(chatTarget, message, {
            parse_mode: "HTML",
            reply_markup: keyboard
        });
        return true;
    } catch (e) {
        console.error(`[AUTO UP] Gagal kirim ke ${chatTarget}:`, e.message);
        return false;
    }
}

// ======================================================
// ==================== STATE SYSTEM ====================
// ======================================================

function setState(userId, state) {
    const dir = "./database/state";
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(`${dir}/${userId}.json`, JSON.stringify({ state }, null, 2));
}

function getState(userId) {
    const file = `./database/state/${userId}.json`;
    if (!fs.existsSync(file)) return null;
    try { return safeReadJSON(file, {}).state; } catch { return null; }
}

function clearState(userId) {
    const file = `./database/state/${userId}.json`;
    if (fs.existsSync(file)) fs.unlinkSync(file);
}

// ======================================================
// ==================== USER SYSTEM =====================
// ======================================================

function getUser(id, username) {
    const db = loadDB();
    if (!db.users[id]) {
        db.users[id] = {
            id,
            username: username || "",
            registered: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"),
            saldo: 0,
            vip: false
        };
        saveDB(db);
    }
    if (global.ownerID.includes(String(id)) && !db.users[id].vip) {
        db.users[id].vip = true;
        saveDB(db);
    }
    return db.users[id];
}

// ======================================================
// ================== SEARCH APP HELPER =================
// ======================================================

// FIX BUG: searchApps harus terima userId — ctx tidak tersedia di scope global
function searchApps(keyword, userId) {
    keyword = keyword.toLowerCase().trim();
    if (keyword.length < 3) return [];
    // Ambil serviceList dari session user yang bersangkutan
    const sessionData = getSession(userId) || {};
    const appList = sessionData.serviceList || sessionData.appList || [];
    return appList.filter(app => {
        const name = (app.service_name || app.name || "").toLowerCase();
        if (name.includes(keyword)) return true;
        for (let len = 3; len <= 5; len++) {
            for (let i = 0; i <= keyword.length - len; i++) {
                if (name.includes(keyword.slice(i, i + len))) return true;
            }
        }
        return false;
    });
}

// ======================================================
// ===== CACHE TTL (dipakai cache katalog smscode) ======
// ======================================================

const CACHE_COUNTRIES_TTL = 30 * 60 * 1000; // 30 menit (dipakai cache smscode)
const CACHE_PRODUCTS_TTL  =  5 * 60 * 1000; //  5 menit (dipakai cache smscode)

// ======================================================
// ===== GATEWAY QRIS DEPOSIT — Cashi.id (cashi.id) =====
// Docs : https://cashi.id/documentation
// Base : https://cashi.id/api
// Auth : API key (dikirim sebagai Authorization: Bearer + header cadangan)
// Cashi pakai NOMINAL PAS (tanpa kode unik) & settle langsung ke saldo merchant.
//
// Endpoint:
//   POST /api/create-order        body { amount, order_id, QRIS_CUSTOM? } → QRIS
//   GET  /api/order-status/:id    → status PENDING | SETTLED | EXPIRED
//   Webhook event PAYMENT_SETTLED { data:{ order_id, amount, status:"SETTLED" } }
// QRIS_CUSTOM:true → nama merchant di QRIS jadi nama toko (harus diaktifkan di dashboard).
//
// CATATAN: respons sukses create-order di-parse defensif (cari field qr_string/qr_image
// dgn beberapa nama umum). Kalau tidak ada gambar, QR dibuat dari qr_string via
// api.qrserver.com. Pakai /cekcashi untuk lihat respons MENTAH bila perlu sesuaikan.
// ======================================================

const CASHI_BASE = "https://cashi.id/api";
function cashiHeaders() {
    const k = global.cashiApiKey || "";
    const h = {
        "Content-Type": "application/json",
        "Accept"      : "application/json",
        "x-api-key"   : k    // sesuai docs Cashi: -H "x-api-key: YOUR_API_KEY"
    };
    if (global.cashiReferer) { h["Referer"] = global.cashiReferer; h["Origin"] = global.cashiReferer; }
    return h;
}

// POST /api/create-order → bentuk respon disamakan dgn gateway lain (dipakai createDeposit)
// Respons asli Cashi: { success, orderId, amount, expected_net, qrUrl(base64 data URI), expires_at, is_qris_custom }
async function cashiCreateDeposit(amount) {
    const base    = Math.round(Number(amount));
    const orderId = `DEP-${Date.now()}-${Math.floor(Math.random() * 1000)}`; // order_id milik kita (dipakai cek status & cocokkan webhook)
    const bodyReq = { amount: base, order_id: orderId };
    if (global.cashiQrisCustom) bodyReq.QRIS_CUSTOM = true;

    const res  = await axiosWithRetry({
        method: "POST", url: `${CASHI_BASE}/create-order`,
        headers: cashiHeaders(), data: bodyReq, validateStatus: () => true
    }, 1);
    const body = res.data || {};
    if (res.status === 429) { const e = new Error("Server Cashi.id sibuk, coba lagi."); e.isRateLimit = true; throw e; }

    const okFlag = body.success === true || body.status === true || String(body.status).toLowerCase() === "success" || (res.status >= 200 && res.status < 300 && body.error == null && body.message == null);
    const d = (body.data && typeof body.data === "object") ? body.data : body;
    if (!okFlag || !d || typeof d !== "object") {
        throw new Error(body.message || body.error || (d && d.message) || `Gagal membuat QRIS Cashi.id (HTTP ${res.status}). Cek API key / saldo / fitur QRIS aktif.`);
    }

    // QR: field utama Cashi = qrUrl (bisa berupa data URI base64 ATAU URL). Defensif utk nama lain.
    const qrString = d.qr_string || d.qris_string || d.qris_content || d.qr_content || d.qris || d.qrString || "";
    let qrImage    = d.qrUrl || d.qr_url || d.qr_image || d.qr_image_url || d.qris_url || d.qrImageUrl || d.image_url || d.qris_image || d.qr || "";
    if (!qrImage && qrString) {
        qrImage = `https://api.qrserver.com/v1/create-qr-code/?size=450x450&data=${encodeURIComponent(qrString)}`;
    }

    // Kode unik: Cashi menambah selisih kecil. amount(diminta) = saldo user; respon.amount = total bayar.
    const totalBayar = Math.round(Number(d.amount)) || base;
    const cashiRef   = String(d.orderId || d.order_id || d.id || d.trx_id || orderId); // ref internal Cashi (mis. GRAB-...)

    let expires_at = null;
    const expRaw = d.expires_at || d.expired_at || d.expired || d.expiry || d.expire_at;
    if (expRaw) { const t = Date.parse(String(expRaw).replace(" ", "T")); if (!isNaN(t)) expires_at = new Date(t).toISOString(); }

    return {
        ok          : true,
        deposit_id  : orderId,                          // order_id kita → dipakai cek status (selaras webhook)
        cashi_ref   : cashiRef,                          // ref internal Cashi (cadangan)
        base_amount : base,                              // saldo yang masuk ke user
        total_amount: totalBayar,                        // yang dibayar user (sudah termasuk kode unik)
        unique_code : Math.max(0, totalBayar - base),
        qr_image    : qrImage,
        qr_string   : qrString,
        payment_url : d.payment_url || d.checkout_url || "",
        expires_at
    };
}

// GET status → coba /check-status lalu /order-status (docs Cashi tampil 2 versi path)
async function cashiGetDeposit(orderId) {
    const paths = ["check-status", "order-status"];
    let lastBody = null, lastStatus = 0;
    for (const p of paths) {
        const res  = await axiosWithRetry({
            method: "GET", url: `${CASHI_BASE}/${p}/${encodeURIComponent(orderId)}`,
            headers: cashiHeaders(), validateStatus: () => true
        }, 1);
        lastStatus = res.status;
        const body = res.data || {};
        lastBody = body;
        const d  = (body.data && typeof body.data === "object") ? body.data : body;
        const st = String(d.status || body.status || "").toUpperCase();
        // kalau endpoint valid & ada status → pakai
        if (st) {
            let status = "pending";
            if (["SETTLED", "SUCCESS", "PAID", "SUKSES"].includes(st))  status = "success";
            else if (st === "EXPIRED")                                  status = "expired";
            else if (["CANCELLED", "CANCELED", "FAILED"].includes(st))  status = "cancelled";
            return { status, raw: d };
        }
        if (res.status === 404) continue; // path salah → coba path lain
    }
    // tidak dapat status valid → anggap pending (jangan hapus order)
    return { status: "pending", raw: lastBody, httpStatus: lastStatus };
}

// Cashi.id tidak ada endpoint cancel resmi → pembatalan cukup di sisi bot.
async function cashiCancelDeposit(orderId) {
    return { ok: true };
}

// ======================================================
// ===== GATEWAY DEPOSIT = Cashi.id (only) ==============
// ======================================================
function gwCreateDeposit(amount) { return cashiCreateDeposit(amount); }
function gwGetDeposit(id)         { return cashiGetDeposit(id); }
function gwCancelDeposit(id)      { return cashiCancelDeposit(id); }

// ======================================================
// ===== AUTO UPDATE HARGA (Callback Harga) =============
// Cek harga smscode tiap interval → deteksi NAIK/TURUN → broadcast ke channel.
// Snapshot harga disimpan di database/harga_snapshot.json (nomor server stabil).
// ======================================================
const HARGA_SNAPSHOT = "./database/harga_snapshot.json";

// Tombol di bawah broadcast (link diambil dari settings.js)
function buildHargaButtons() {
    const rows = [];
    if (global.csUsername)       rows.push([{ text: "💬 Customer Service", url: `https://t.me/${global.csUsername}` }]);
    if (global.botUsername)      rows.push([{ text: "🤖 Order Nokos",       url: `https://t.me/${global.botUsername}` }]);
    if (global.wajibJoinSaluran) rows.push([{ text: "📢 Channel Utama",     url: `https://t.me/${global.wajibJoinSaluran}` }]);
    const trxCh = global.callbackChannel || global.wajibJoinGrup;
    if (trxCh)                   rows.push([{ text: "💰 Callback Transaksi", url: `https://t.me/${trxCh}` }]);
    const hrgCh = global.hargaChannel || global.wajibJoinHarga;
    if (hrgCh)                   rows.push([{ text: "📈 Callback Harga",     url: `https://t.me/${hrgCh}` }]);
    return { inline_keyboard: rows };
}

// Resolusi negara dari nama → object {id,name}
function findCountryByName(countries, nm) {
    const q = String(nm || "").toLowerCase().trim();
    return countries.find(c => (c.name || "").toLowerCase() === q)
        || countries.find(c => (c.name || "").toLowerCase().includes(q));
}
function findServiceByName(services, nm) {
    const q = String(nm || "").toLowerCase().trim();
    return services.find(s => (s.name || "").toLowerCase() === q)
        || services.find(s => (s.name || "").toLowerCase().includes(q));
}

// Proses 1 grup (1 aplikasi + 1 negara): hitung perubahan & broadcast bila ada.
async function processHargaGroup(bot, service, country, channel, snapAll, markup) {
    const raw = await smscodeGetProducts(service.id, country.id);
    const products = (raw || [])
        .filter(p => Number(p.price) > 0)
        .map(p => ({
            id   : String(p.id),
            name : p.name,
            stock: Number(p.available) || 0,
            rate : (p.rate != null ? Number(p.rate) : (p.success_rate != null ? Number(p.success_rate) : null)),
            sell : Math.round(Number(p.price) * (1 + markup / 100))
        }));
    if (!products.length) return 0;

    const key = `${service.id}:${country.id}`;
    let snap = snapAll[key] || { map: {}, nextNo: 1, prices: {} };

    [...products].sort((a, b) => a.sell - b.sell).forEach(p => {
        if (!snap.map[p.id]) snap.map[p.id] = snap.nextNo++;
    });

    const naik = [], turun = [];
    for (const p of products) {
        const old = snap.prices[p.id];
        if (old != null && old !== p.sell) {
            const diff = p.sell - old;
            const pct  = old > 0 ? Math.abs(diff) / old * 100 : 0;
            const item = { no: snap.map[p.id], old, neu: p.sell, diff: Math.abs(diff), pct, stock: p.stock, rate: p.rate };
            (diff > 0 ? naik : turun).push(item);
        }
    }

    const newPrices = {};
    for (const p of products) newPrices[p.id] = p.sell;
    snap.prices = newPrices;
    snapAll[key] = snap;

    if (naik.length === 0 && turun.length === 0) return 0;

    const totalStok = products.reduce((s, p) => s + p.stock, 0);
    const t     = moment().tz("Asia/Jakarta").format("D/M/YYYY, HH.mm.ss");
    const garis = "━━━━━━━━━━━━━━━━━━━";
    // Keterangan: aplikasi + negara di header tiap update
    let msg = `📈 <b>UPDATE HARGA ${(service.name || "").toUpperCase()}</b>\n\n`;
    msg += `📍 Negara: ${country.name}\n🕐 Waktu: ${t}\n📊 Total Server: ${products.length}\n📦 Stok Total: ${totalStok.toLocaleString("id-ID")}\n\n${garis}\n`;

    const fmtItem = (it, up) => {
        let s = `\nServer ${it.no}\n`;
        s += `💰 Rp ${it.old.toLocaleString("id-ID")} → Rp ${it.neu.toLocaleString("id-ID")}\n`;
        s += `${up ? "📈 Naik" : "📉 Turun"} Rp ${it.diff.toLocaleString("id-ID")} (${it.pct.toFixed(1)}%)\n`;
        s += (it.rate != null ? `📊 Rate: ${it.rate}% | 📦 Stok: ${it.stock}\n` : `📦 Stok: ${it.stock}\n`);
        return s;
    };

    const cap = 20;
    if (naik.length) {
        msg += `\n🔴 <b>HARGA NAIK!</b>\n`;
        naik.sort((a, b) => a.no - b.no).slice(0, cap).forEach(it => msg += fmtItem(it, true));
        if (naik.length > cap) msg += `\n…dan ${naik.length - cap} server lainnya\n`;
    }
    if (turun.length) {
        msg += `\n🟢 <b>HARGA TURUN!</b>\n`;
        turun.sort((a, b) => a.no - b.no).slice(0, cap).forEach(it => msg += fmtItem(it, false));
        if (turun.length > cap) msg += `\n…dan ${turun.length - cap} server lainnya\n`;
    }
    msg += `\n${garis}\n\n🎯 <b>ACTION</b>\n• Order sekarang untuk harga terbaik\n• Harga dapat berubah sewaktu-waktu\n• Stok terbatas`;
    if (msg.length > 4000) msg = msg.slice(0, 3950) + "\n…(dipotong)";

    await bot.telegram.sendMessage(`@${channel}`, msg, {
        parse_mode: "HTML",
        reply_markup: buildHargaButtons(),
        disable_web_page_preview: true
    });
    console.log(`[HARGA] ${service.name}/${country.name}: naik=${naik.length} turun=${turun.length} → @${channel}`);
    return naik.length + turun.length;
}

// Pantau BANYAK aplikasi populer × BANYAK negara (di settings.js)
async function runHargaMonitor(bot, opts = {}) {
    try {
        if (!global.smscodeApiKey || global.smscodeApiKey.includes("ISI_TOKEN")) return { ok: false, reason: "smscode key kosong" };
        const channel = global.hargaChannel || global.wajibJoinHarga;
        if (!channel) { console.warn("[HARGA] channel broadcast kosong (set global.hargaChannel / wajibJoinHarga)"); return { ok: false, reason: "channel kosong" }; }

        const apps = (Array.isArray(global.hargaApps) && global.hargaApps.length)
            ? global.hargaApps : [global.hargaServiceName || "Telegram"];
        const countryNames = (Array.isArray(global.hargaCountries) && global.hargaCountries.length)
            ? global.hargaCountries : [global.hargaCountryName || "Indonesia"];

        const markup    = global.profitUser || 0;
        const countries = await smscodeGetCountries();

        let snapAll = safeReadJSON(HARGA_SNAPSHOT, {});
        if (!snapAll || typeof snapAll !== "object") snapAll = {};

        let totalChanged = 0, groups = 0, missed = [];
        for (const cName of countryNames) {
            const country = findCountryByName(countries, cName);
            if (!country) { missed.push(`negara:${cName}`); continue; }
            let services;
            try { services = await smscodeGetServices(country.id); }
            catch (e) { console.warn(`[HARGA] services ${cName}:`, e.message); continue; }

            for (const appName of apps) {
                const service = findServiceByName(services, appName);
                if (!service) { missed.push(`${appName}@${country.name}`); continue; }
                try {
                    totalChanged += await processHargaGroup(bot, service, country, channel, snapAll, markup);
                    groups++;
                } catch (e) {
                    console.warn(`[HARGA] ${appName}/${cName}:`, e.message);
                }
                await sleep(1200); // jeda antar grup biar tidak kena rate limit smscode
            }
        }

        try { fs.writeFileSync(HARGA_SNAPSHOT, JSON.stringify(snapAll, null, 2)); }
        catch (e) { console.warn("[HARGA] save snapshot:", e.message); }

        return { ok: true, changed: totalChanged, groups, missed };
    } catch (e) {
        console.warn("[HARGA MONITOR]", e.message);
        return { ok: false, reason: e.message };
    }
}

// ======================================================
// ===== SMSCODE.GG API (Nokos V2 — Server smscode) =====
// Base URL : https://api.smscode.gg/v1   (versi IDR, harga Rupiah integer)
// Auth     : Authorization: Bearer <token>
// Docs     : https://smscode.gg/docs
// Envelope : { success: true, data: {...} } | { success:false, error:{code,message} }
//
// Endpoint dipakai bot:
//   GET  /balance                                       → saldo akun owner
//   GET  /catalog/countries                             → daftar negara  (cache 30 mnt)
//   GET  /catalog/services?country_id=X                 → daftar aplikasi (cache 30 mnt)
//   GET  /catalog/products?country_id=X&platform_id=Y   → produk + harga (cache 5 mnt)
//   POST /orders/create  {product_id, quantity:1}       → beli nomor
//   GET  /orders/{id}                                   → cek OTP + status
//   POST /orders/cancel  {id}                            → cancel (min 2 menit) + refund
//
// CATATAN PENTING: smscode.gg TIDAK punya endpoint deposit/QRIS. Saldo bot (user)
// tetap diisi lewat Deposit Auto (QRIS Cashi.id) — itu menambah
// db.users[uid].saldo. Nokos V2 hanya MEMOTONG saldo yang sama, persis seperti V1.
// ======================================================

const SMSCODE_BASE = "https://api.smscode.gg/v1";
const smscodeHeaders = () => ({
    "Authorization": `Bearer ${global.smscodeApiKey}`,
    "Content-Type" : "application/json",
    "Accept"       : "application/json"
});

const _smscodeCache = {
    countries   : null,
    countriesTs : 0,
    svc         : {},  // key country → services[]
    svcTs       : {},
    prod        : {},  // key platform:country → products[]
    prodTs      : {},
};

// Ubah kode error smscode jadi pesan Indonesia yang ramah
function smscodeErrorID(code, fallback) {
    const m = {
        UNAUTHORIZED        : "Token smscode.gg tidak valid. Owner: isi global.smscodeApiKey yang benar di settings.js",
        INSUFFICIENT_BALANCE: "Saldo akun Provider (owner) tidak cukup. Owner perlu top up di Provider.",
        NO_OFFER_AVAILABLE  : "Stok nomor habis untuk produk ini. Coba produk / negara lain.",
        PROVIDER_ERROR      : "Provider menolak permintaan (stok / harga berubah). Coba lagi atau pilih produk lain.",
        CANCEL_TOO_EARLY    : "Order belum bisa dibatalkan. Tunggu minimal 2 menit dulu.",
        RATE_LIMIT_EXCEEDED : "Server sibuk (rate limit). Tunggu sebentar lalu coba lagi.",
        SERVICE_UNAVAILABLE : "Layanan smscode.gg sedang maintenance. Coba lagi nanti.",
        VALIDATION_ERROR    : "Permintaan tidak valid.",
        NOT_FOUND           : "Order tidak ditemukan.",
    };
    return m[code] || fallback || "Terjadi kesalahan Provider";
}

// Request generic ke smscode + parsing envelope { success, data, error }
async function smscodeRequest(config, retries = 2) {
    let res;
    try {
        res = await axiosWithRetry({
            ...config,
            headers      : { ...smscodeHeaders(), ...(config.headers || {}) },
            validateStatus: () => true  // jangan lempar di non-2xx, kita handle manual via envelope
        }, retries);
    } catch (e) {
        throw new Error(e.message || "Koneksi ke provider dari gagal");
    }
    const body = res.data || {};

    if (res.status === 429) {
        const retryAfter = Number(res.headers?.["retry-after"]) || 60;
        const err = new Error(`Server sibuk (rate limit). Tunggu ${retryAfter} detik.`);
        err.isRateLimit = true;
        err.retryAfter  = retryAfter;
        throw err;
    }
    if (body.success === false || res.status >= 400) {
        const code = body?.error?.code || `HTTP_${res.status}`;
        const err  = new Error(smscodeErrorID(code, body?.error?.message));
        err.code       = code;
        err.httpStatus = res.status;
        throw err;
    }
    return body.data;
}

// GET /balance → { balance, currency }
async function smscodeGetBalance() {
    const d = await smscodeRequest({ method: "GET", url: `${SMSCODE_BASE}/balance` });
    return { balance: Number(d.balance) || 0, currency: d.currency || "IDR" };
}

// GET /catalog/countries → [{id, name, emoji}]  (cache 30 mnt)
async function smscodeGetCountries() {
    if (_smscodeCache.countries && (Date.now() - _smscodeCache.countriesTs) < CACHE_COUNTRIES_TTL) {
        console.log(`[CACHE] SMSCODE Countries: ${_smscodeCache.countries.length} negara`);
        return _smscodeCache.countries;
    }
    const d    = await smscodeRequest({ method: "GET", url: `${SMSCODE_BASE}/catalog/countries` }, 1);
    const data = (Array.isArray(d) ? d : [])
        .filter(c => c.active !== false)
        .map(c => ({ id: c.id, name: c.name, emoji: c.emoji || getCountryEmoji(c.name) }));
    _smscodeCache.countries   = data;
    _smscodeCache.countriesTs = Date.now();
    console.log(`[SMSCODE] Countries: ${data.length} negara (cached 30 mnt)`);
    return data;
}

// GET /catalog/services?country_id=X → [{id, name, code}]  (cache 30 mnt per negara)
async function smscodeGetServices(countryId) {
    const key = `svc:${countryId || "all"}`;
    if (_smscodeCache.svc[key] && (Date.now() - (_smscodeCache.svcTs[key] || 0)) < CACHE_COUNTRIES_TTL) {
        console.log(`[CACHE] SMSCODE Services ${countryId}: ${_smscodeCache.svc[key].length} aplikasi`);
        return _smscodeCache.svc[key];
    }
    let url = `${SMSCODE_BASE}/catalog/services`;
    if (countryId) url += `?country_id=${countryId}`;
    const d    = await smscodeRequest({ method: "GET", url }, 1);
    const data = (Array.isArray(d) ? d : [])
        .filter(s => s.active !== false)
        .map(s => ({ id: s.id, name: s.name, code: s.code }));
    _smscodeCache.svc[key]   = data;
    _smscodeCache.svcTs[key] = Date.now();
    console.log(`[SMSCODE] Services ${countryId}: ${data.length} aplikasi (cached 30 mnt)`);
    return data;
}

// GET /catalog/products?platform_id=X&country_id=Y → [{id, name, available, price, ...}] (cache 5 mnt)
async function smscodeGetProducts(platformId, countryId) {
    const key = `p:${platformId}:${countryId || "all"}`;
    if (_smscodeCache.prod[key] && (Date.now() - (_smscodeCache.prodTs[key] || 0)) < CACHE_PRODUCTS_TTL) {
        console.log(`[CACHE] SMSCODE Products ${platformId}/${countryId}: ${_smscodeCache.prod[key].length}`);
        return _smscodeCache.prod[key];
    }
    let url = `${SMSCODE_BASE}/catalog/products?limit=1000&sort=price_asc&platform_id=${platformId}`;
    if (countryId) url += `&country_id=${countryId}`;
    const d    = await smscodeRequest({ method: "GET", url }, 1);
    const data = Array.isArray(d) ? d : [];
    _smscodeCache.prod[key]   = data;
    _smscodeCache.prodTs[key] = Date.now();
    console.log(`[SMSCODE] Products ${platformId}/${countryId}: ${data.length} produk (cached 5 mnt)`);
    return data;
}

// POST /orders/create {product_id, quantity:1} → ambil orders[0]
async function smscodeCreateOrder(productId) {
    const idemKey = `tg-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
    const d = await smscodeRequest({
        method : "POST",
        url    : `${SMSCODE_BASE}/orders/create`,
        headers: { "Idempotency-Key": idemKey },
        data   : { product_id: Number(productId), quantity: 1 }
    }, 1);
    const order = (d.orders && d.orders[0]) || null;
    if (!order) throw new Error("Provider tidak mengembalikan nomor. Coba produk lain.");
    return {
        order_id    : String(order.id),
        phone_number: order.phone_number,
        price       : Number(order.amount) || 0,   // harga modal real (IDR) dari provider
        service     : order.service || "",
        expired_at  : order.expires_at || null
    };
}

// GET /orders/{id} → normalisasi status ke format internal (sama seperti mbjebeGetOrder)
// Status smscode: ACTIVE | OTP_RECEIVED | COMPLETED | CANCELED | EXPIRED ; OTP di field otp_code
async function smscodeGetOrder(orderId) {
    const raw = await smscodeRequest({ method: "GET", url: `${SMSCODE_BASE}/orders/${orderId}` });
    const rs  = String(raw.status || "").toUpperCase();
    const otp = raw.otp_code || null;
    let status = "ACTIVE";
    if (rs === "OTP_RECEIVED" || (rs === "COMPLETED" && otp))           status = "OTP_RECEIVED";
    else if (rs === "CANCELED" || rs === "EXPIRED" || (rs === "COMPLETED" && !otp)) status = "CANCELED";
    return {
        order_id    : String(raw.id),
        phone_number: raw.phone_number,
        otp_code    : otp,
        status,
        raw_status  : rs
    };
}

// POST /orders/cancel {id} — min 2 menit, refund otomatis ke akun owner
async function smscodeCancelOrder(orderId) {
    try {
        return await smscodeRequest({
            method: "POST",
            url   : `${SMSCODE_BASE}/orders/cancel`,
            data  : { id: Number(orderId) }
        }, 1);
    } catch (e) {
        console.warn(`[SMSCODE CANCEL ORDER] ${orderId}: ${e.message}`);
        throw e;
    }
}

// ======================================================
// ===== ROUTER PROVIDER (V1 mbjebe / V2 smscode) =======
// Dipakai oleh polling, cek manual, & cancel order supaya
// satu file order bisa diarahkan ke API yang benar.
// ======================================================
function getOrderByProvider(provider, orderId) {
    return smscodeGetOrder(orderId);
}
function cancelOrderByProvider(provider, orderId) {
    return smscodeCancelOrder(orderId);
}

// ======================================================

const depositDir = "./database/deposit";
if (!fs.existsSync(depositDir)) fs.mkdirSync(depositDir, { recursive: true });

async function createDeposit(bot, ctx, userId, amount) {
    try {
        // Cek deposit pending dulu
        const existingFile = `${depositDir}/${userId}.json`;
        if (fs.existsSync(existingFile)) {
            const existing = safeReadJSON(existingFile, {});
            if (existing.expired_ts && Date.now() < existing.expired_ts) {
                return ctx.reply("⚠️ Kamu masih punya deposit pending. Tunggu selesai atau batalkan dulu.");
            }
            // Sudah expired, hapus
            try { fs.unlinkSync(existingFile); } catch {}
        }

        // Hit API MB JEBE untuk buat deposit + QRIS
        await ctx.reply("⏳ Membuat QRIS, tunggu sebentar...");

        const dep = await gwCreateDeposit(amount);
        // Cashi create-order → { ok, deposit_id, base_amount, total_amount, unique_code:0, qr_image, qr_string, expires_at }

        const depositId   = dep.deposit_id;
        const baseAmount  = dep.base_amount || amount; // saldo yang masuk ke user
        const totalAmount = dep.total_amount;
        const uniqueCode  = dep.unique_code;
        const qrImageUrl  = dep.qr_image;               // Cashi: URL gambar QR (atau dibuat dari qr_string)
        const expiredTs   = dep.expires_at ? new Date(dep.expires_at).getTime() : (Date.now() + 15 * 60 * 1000);

        const caption =
            `💰 <b>Deposit Saldo (QRIS Otomatis)</b>\n\n` +
            (uniqueCode > 0
                ? `Nominal Saldo : <b>Rp ${amount.toLocaleString("id-ID")}</b>\n` +
                  `Total Bayar   : <b>Rp ${totalAmount.toLocaleString("id-ID")}</b>\n` +
                  `Kode Unik     : <b>+${uniqueCode}</b>\n\n` +
                  `⚠️ Scan QRIS dan bayar <b>SAMA PERSIS</b> Rp ${totalAmount.toLocaleString("id-ID")}\n` +
                  `(termasuk kode unik untuk identifikasi otomatis)\n\n`
                : `Nominal Bayar : <b>Rp ${totalAmount.toLocaleString("id-ID")}</b>\n\n` +
                  `⚠️ Scan QRIS dan bayar <b>SAMA PERSIS</b> Rp ${totalAmount.toLocaleString("id-ID")}\n\n`) +
            `⏰ Expired: <b>${moment(expiredTs).tz("Asia/Jakarta").format("HH:mm:ss")} WIB</b>\n\n` +
            `⏳ <b>Sistem otomatis deteksi pembayaran...</b>\nSaldo masuk otomatis 5-10 detik setelah bayar.`;

        const keyboard = {
            inline_keyboard: [
                [{ text: "❌ Batal Deposit", callback_data: "deposit_cancel" }]
            ]
        };

        let msg;
        let photoSource = null;
        if (qrImageUrl && qrImageUrl.startsWith("data:image")) {
            // Cashi qrUrl = base64 data URI → decode ke Buffer untuk dikirim sebagai foto
            try {
                const b64 = qrImageUrl.split(",")[1] || "";
                photoSource = { source: Buffer.from(b64, "base64") };
            } catch { photoSource = null; }
        } else if (qrImageUrl && qrImageUrl.startsWith("http")) {
            photoSource = qrImageUrl;
        }

        if (photoSource) {
            try {
                msg = await ctx.replyWithPhoto(photoSource, { caption, parse_mode: "HTML", reply_markup: keyboard });
            } catch (e) {
                console.log("QRIS photo gagal:", e.message);
                msg = await ctx.reply(
                    caption + (typeof qrImageUrl === "string" && qrImageUrl.startsWith("http") ? `\n\n🔗 <a href="${qrImageUrl}">Buka QRIS</a>` : ""),
                    { parse_mode: "HTML", reply_markup: keyboard, disable_web_page_preview: false }
                );
            }
        } else {
            msg = await ctx.reply(caption, { parse_mode: "HTML", reply_markup: keyboard });
        }

        fs.writeFileSync(`${depositDir}/${userId}.json`, JSON.stringify({
            deposit_id   : depositId,
            amount_user  : baseAmount,  // saldo yang akan masuk ke user (base_amount)
            amount_total : totalAmount, // yang dibayar user termasuk kode unik
            unique_code  : uniqueCode,
            expired_ts   : expiredTs,
            qr_image_url : qrImageUrl,
            chat_id      : msg.chat.id,
            message_id   : msg.message_id,
            status       : "pending"
        }, null, 2));

        // Mulai polling status deposit ke MB JEBE API
        startPollingDeposit(bot, ctx, userId, depositId);

    } catch (err) {
        console.log("CREATE DEPOSIT ERROR:", err.message);
        ctx.reply("❌ Gagal membuat deposit: " + err.message + "\n\nCoba lagi atau hubungi owner.");
    }
}

function startPollingDeposit(bot, ctx, userId, depositId) {
    let pollCount = 0;
    const MAX_POLLS = 360; // 360 × 5 detik = 30 menit (sesuai expired_at API)

    const interval = setInterval(async () => {
        pollCount++;
        const file = `${depositDir}/${userId}.json`;
        if (!fs.existsSync(file)) { clearInterval(interval); unregisterPolling(`dep_${userId}`); return; }

        const dep = safeReadJSON(file, null);
        if (!dep || !dep.deposit_id) { clearInterval(interval); unregisterPolling(`dep_${userId}`); return; }

        // Cek expired
        if (pollCount > MAX_POLLS || Date.now() > dep.expired_ts) {
            clearInterval(interval);
            unregisterPolling(`dep_${userId}`);
            try {
                await bot.telegram.editMessageCaption(dep.chat_id, dep.message_id, null,
                    `⏰ <b>DEPOSIT EXPIRED</b>\n\nQRIS sudah tidak berlaku.\nBuat deposit baru jika masih ingin top up.`,
                    { parse_mode: "HTML" }
                );
            } catch {
                try {
                    await bot.telegram.editMessageText(dep.chat_id, dep.message_id, null,
                        `⏰ <b>DEPOSIT EXPIRED</b>`,
                        { parse_mode: "HTML" }
                    );
                } catch {}
            }
            await sleep(3000);
            try { await bot.telegram.deleteMessage(dep.chat_id, dep.message_id); } catch {}
            if (fs.existsSync(file)) fs.unlinkSync(file);
            return;
        }

        // Cek status di API MB JEBE
        try {
            const status = await gwGetDeposit(depositId);
            console.log(`DEPOSIT POLL [${userId}] ${depositId}: ${status.status}`);

            if (status.status === "success") { // Cashi: SETTLED → saldo user ditambah
                clearInterval(interval);
                unregisterPolling(`dep_${userId}`);
                await approveDeposit(bot, ctx, userId, dep);
            } else if (status.status === "cancelled" || status.status === "expired") {
                clearInterval(interval);
                unregisterPolling(`dep_${userId}`);
                try {
                    await bot.telegram.editMessageCaption(dep.chat_id, dep.message_id, null,
                        `❌ <b>DEPOSIT ${status.status.toUpperCase()}</b>`,
                        { parse_mode: "HTML" }
                    );
                } catch {}
                await sleep(2000);
                try { await bot.telegram.deleteMessage(dep.chat_id, dep.message_id); } catch {}
                if (fs.existsSync(file)) fs.unlinkSync(file);
            }
        } catch (err) {
            console.log("DEPOSIT POLL ERROR:", err.response?.data || err.message);
        }
    }, 5000); // poll cek status tiap 5 detik
    registerPolling(`dep_${userId}`, interval);
}

async function approveDeposit(bot, ctx, userId, dep) {
    const file = `${depositDir}/${userId}.json`;
    if (!fs.existsSync(file)) return;

    // Update saldo user
    const db = loadDB();
    const uid = String(userId);
    if (!db.users[uid]) getUser(uid);
    db.users[uid].saldo += dep.amount_user;
    await saveDB(db);

    fs.unlinkSync(file);

    // Edit pesan jadi sukses + hapus
    try {
        await bot.telegram.editMessageCaption(dep.chat_id, dep.message_id, null,
            `✅ <b>PEMBAYARAN DITERIMA!</b>\n\nDeposit Rp ${dep.amount_user.toLocaleString("id-ID")} berhasil.\nSaldo telah ditambahkan otomatis.\n\n<i>Pesan ini akan hilang otomatis.</i>`,
            { parse_mode: "HTML" }
        );
    } catch {
        try {
            await bot.telegram.editMessageText(dep.chat_id, dep.message_id, null,
                `✅ <b>PEMBAYARAN DITERIMA!</b>\n\nDeposit Rp ${dep.amount_user.toLocaleString("id-ID")} berhasil.`,
                { parse_mode: "HTML" }
            );
        } catch {}
    }
    await sleep(3000);
    try { await bot.telegram.deleteMessage(dep.chat_id, dep.message_id); } catch {}

    await saveFinalTransaction(
        { user_id: uid, service: "Deposit", price: dep.amount_user, created_ts: Date.now() },
        { status: "success", finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"), price_sell: dep.amount_user }
    );

    // PROSES KOMISI REFERRAL
    await prosesKomisiReferral(bot, uid, dep.amount_user);

    // Notif user
    const u = getUser(uid);
    try {
        await bot.telegram.sendMessage(Number(uid),
            `✅ <b>Deposit Berhasil!</b>\n\n💰 Saldo bertambah: <b>+Rp ${dep.amount_user.toLocaleString("id-ID")}</b>\n💳 Saldo sekarang: <b>Rp ${db.users[uid].saldo.toLocaleString("id-ID")}</b>\n\n🎉 Selamat berbelanja!`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] } }
        );
    } catch {}

    // Log ke grup notif (grupNotifDeposit)
    const waktuDeposit = moment().tz("Asia/Jakarta");
    const logMsgDeposit =
        `💰 <b>DEPOSIT BERHASIL</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `📋 <b>TRANSACTION DETAILS</b>\n` +
        `• Nama User: ${ctx?.from?.first_name || u.username || "User"}\n` +
        `• Jumlah Deposit: <b>Rp ${dep.amount_user.toLocaleString("id-ID")}</b>\n` +
        `• Pembayaran: ${dep.payment_method || "QRIS"}\n` +
        `• Points Earned: +1\n` +
        `• Tanggal: ${waktuDeposit.format("MMM DD, YYYY")}\n` +
        `• Waktu: ${waktuDeposit.format("HH.mm.ss")}\n\n` +
        `📊 <b>USER STATISTICS</b>\n` +
        `• User ID: ${uid}\n` +
        `• Saldo Total: <b>Rp ${db.users[uid].saldo.toLocaleString("id-ID")}</b>\n` +
        `• Status: ✅ Transaksi Sukses\n` +
        `• Sistem: Auto Processing\n\n` +
        `🎯 <b>ROYALTY SYSTEM</b>\n` +
        `• Total Points: ${(db.users[uid].points || 0) + 1}\n` +
        `• Deposit Count: ${(db.users[uid].depositCount || 0)}x\n` +
        `• Reward Status: Active`;

    // Kirim notif ke grup notif deposit
    if (global.grupNotifDeposit) {
        await autoUpSend(bot, global.grupNotifDeposit, logMsgDeposit, global.botUsername);
    }

    // NOTE: autoUpChannel sengaja TIDAK digunakan di sini karena grupNotifDeposit
    // sudah menunjuk ke channel yang sama → mencegah pesan dobel di channel transaksi
}

async function cancelDeposit(ctx, userId) {
    const file = `${depositDir}/${userId}.json`;
    if (!fs.existsSync(file)) return ctx.answerCbQuery("Tidak ada deposit pending.");
    const dep = safeReadJSON(file, {});

    // Cancel di MB JEBE dulu (best-effort)
    try { await gwCancelDeposit(dep.deposit_id); } catch {}

    try {
        await ctx.telegram.editMessageCaption(dep.chat_id, dep.message_id, null,
            `❌ <b>DEPOSIT DIBATALKAN</b>\n\n<i>Pesan ini akan hilang otomatis.</i>`,
            { parse_mode: "HTML" }
        );
    } catch {
        try {
            await ctx.telegram.editMessageText(dep.chat_id, dep.message_id, null,
                `❌ <b>DEPOSIT DIBATALKAN</b>`,
                { parse_mode: "HTML" }
            );
        } catch {}
    }
    await sleep(2000);
    try { await ctx.telegram.deleteMessage(dep.chat_id, dep.message_id); } catch {}
    try { fs.unlinkSync(file); } catch {}
    await ctx.reply("❌ Deposit dibatalkan.");
    ctx.answerCbQuery("Deposit dibatalkan.");
}

// ======================================================
// ============== SISTEM WITHDRAW (WD) ==================
// ======================================================
//
// Alur:
//  1. User buka menu WD → pilih e-wallet (DANA, OVO, GoPay, dll)
//  2. Input nomor HP tujuan
//  3. Input nominal WD (minimal global.wdMinimal)
//  4. Cek saldo mencukupi
//  5. Kirim permohonan WD ke owner (dengan tombol ACC / Tolak)
//  6. Owner klik ACC → saldo user terpotong, kirim notif ke user
//  7. Owner klik Tolak → saldo tetap, kirim notif ke user
//
// Data WD pending di ./database/wd/{userId}.json
// ======================================================

const wdDir = "./database/wd";
if (!fs.existsSync(wdDir)) fs.mkdirSync(wdDir, { recursive: true });

// Daftar e-wallet yang tersedia — bisa ditambah di sini
const EWALLET_LIST = [
    { id: "dana",    nama: "DANA",       emoji: "💙" },
    { id: "ovo",     nama: "OVO",        emoji: "💜" },
    { id: "gopay",   nama: "GoPay",      emoji: "💚" },
    { id: "shopeepay", nama: "ShopeePay", emoji: "🧡" },
    { id: "bri",     nama: "BRI",        emoji: "🏦" },
    { id: "bca",     nama: "BCA",        emoji: "🏦" },
    { id: "mandiri", nama: "Mandiri",    emoji: "🏦" },
    { id: "bni",     nama: "BNI",        emoji: "🏦" },
];

// ======================================================
// ============= SISTEM REFERRAL / UNDANG TEMAN =========
// ======================================================
//
// Alur:
//  1. User A kirim /start?ref=USERID_B → user A dicatat referredBy = B
//  2. Setiap user A deposit, sistem cek:
//     a. Apakah A punya referrer (B)?
//     b. Apakah deposit ini dalam periode aktif (30 hari sejak deposit pertama bulan ini)?
//     c. Apakah komisi bulan ini sudah diklaim? (per bulan, bukan per deposit)
//  3. Hitung komisi = amount_user × global.referralPersen / 100
//  4. Tambah ke saldo B, kirim notif ke B
//
// Data referral disimpan di ./database/referral.json:
// {
//   "USER_A_ID": {
//     "referredBy": "USER_B_ID",
//     "joinedAt": "2026-05-01 10:00:00",
//     "totalKomisi": 5000
//   },
//   ...
// }
//
// Data komisi bulanan di ./database/komisi_bulanan.json:
// {
//   "USER_B_ID": {
//     "2026-05": 10000,   // total komisi diterima di bulan ini
//     ...
//   }
// }
// ======================================================

const referralPath     = "./database/referral.json";
const komisiBulananPath = "./database/komisi_bulanan.json";

function loadReferralDB() {
    if (!fs.existsSync(referralPath)) fs.writeFileSync(referralPath, JSON.stringify({}, null, 2));
    try { return safeReadJSON(referralPath, {}); } catch { return {}; }
}

function saveReferralDB(db) {
    return queueWrite(() => fs.writeFileSync(referralPath, JSON.stringify(db, null, 2)));
}

function loadKomisiBulanan() {
    if (!fs.existsSync(komisiBulananPath)) fs.writeFileSync(komisiBulananPath, JSON.stringify({}, null, 2));
    try { return safeReadJSON(komisiBulananPath, {}); } catch { return {}; }
}

function saveKomisiBulanan(db) {
    return queueWrite(() => fs.writeFileSync(komisiBulananPath, JSON.stringify(db, null, 2)));
}

// Daftarkan referral (dipanggil saat /start?ref=XXX)
function daftarReferral(userId, referrerId) {
    userId     = String(userId);
    referrerId = String(referrerId);

    // Jangan bisa referral diri sendiri
    if (userId === referrerId) return false;

    const db = loadReferralDB();
    // Hanya bisa didaftarkan sekali
    if (db[userId]?.referredBy) return false;

    if (!db[userId]) db[userId] = {};
    db[userId].referredBy = referrerId;
    db[userId].joinedAt   = moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss");
    db[userId].totalKomisi = db[userId].totalKomisi || 0;
    saveReferralDB(db);
    return true;
}

// Proses komisi referral saat deposit berhasil
async function prosesKomisiReferral(bot, userId, depositAmount) {
    if (!global.referralPersen || global.referralPersen <= 0) return;

    userId = String(userId);
    const refDb = loadReferralDB();
    const userRef = refDb[userId];
    if (!userRef?.referredBy) return; // tidak punya referrer

    const referrerId = String(userRef.referredBy);

    // Cek apakah referrer masih ada di DB user
    const mainDb = loadDB();
    if (!mainDb.users[referrerId]) return;

    // Cek periode komisi: hitung per bulan kalender
    // Durasi 1 bulan = komisi hanya dihitung dalam bulan berjalan
    const bulanIni = moment().tz("Asia/Jakarta").format("YYYY-MM");

    const komisiDb = loadKomisiBulanan();
    if (!komisiDb[referrerId]) komisiDb[referrerId] = {};

    // Hitung komisi
    const komisi = Math.floor(depositAmount * global.referralPersen / 100);
    if (komisi <= 0) return;

    // Tambah ke saldo referrer
    mainDb.users[referrerId].saldo += komisi;
    await saveDB(mainDb);

    // Catat komisi bulanan
    komisiDb[referrerId][bulanIni] = (komisiDb[referrerId][bulanIni] || 0) + komisi;
    await saveKomisiBulanan(komisiDb);

    // Update total komisi di referral DB
    refDb[userId].totalKomisi = (refDb[userId].totalKomisi || 0) + komisi;
    await saveReferralDB(refDb);

    // Notif ke referrer
    try {
        const userDepositNama = mainDb.users[userId]?.username
            ? `@${mainDb.users[userId].username}`
            : `ID ${userId}`;

        await bot.telegram.sendMessage(Number(referrerId),
            `🎉 <b>Komisi Referral Masuk!</b>\n\n` +
            `Teman yang kamu undang (<b>${userDepositNama}</b>) baru saja deposit.\n\n` +
            `💰 Komisi (${global.referralPersen}%): <b>+Rp ${komisi.toLocaleString("id-ID")}</b>\n` +
            `📅 Bulan: <b>${bulanIni}</b>\n\n` +
            `Saldo kamu bertambah otomatis! 🚀`,
            { parse_mode: "HTML" }
        );
    } catch (e) {
        console.log("NOTIF KOMISI ERROR:", e.message);
    }

    console.log(`KOMISI REFERRAL: ${referrerId} ← Rp ${komisi} (dari deposit ${userId} Rp ${depositAmount})`);
}

// Ambil statistik referral untuk user tertentu
function getStatReferral(userId) {
    userId = String(userId);
    const refDb   = loadReferralDB();
    const komisiDb = loadKomisiBulanan();

    // Siapa yang diundang oleh userId ini
    const diundang = Object.entries(refDb)
        .filter(([, v]) => v.referredBy === userId)
        .map(([uid, v]) => ({ uid, joinedAt: v.joinedAt, totalKomisi: v.totalKomisi || 0 }));

    const totalKomisiSemua = diundang.reduce((s, x) => s + x.totalKomisi, 0);

    // Komisi bulan ini
    const bulanIni   = moment().tz("Asia/Jakarta").format("YYYY-MM");
    const komisiBulanIni = (komisiDb[userId]?.[bulanIni]) || 0;

    // Siapa yang mengundang userId ini
    const referredBy = refDb[userId]?.referredBy || null;

    return { diundang, totalKomisiSemua, komisiBulanIni, referredBy };
}

// Generate link referral
function getReferralLink(botUsername, userId) {
    return `https://t.me/${botUsername}?start=ref_${userId}`;
}

// ======================================================
// ============ PAGINATION: NEGARA → APLIKASI → HARGA ===
// MB JEBE API kasih flat list {id, name: "WhatsApp - Indonesia", available, price}
// Kita parse jadi 3 layer:
//   Layer 1: Negara (group by part setelah " - ")
//   Layer 2: Aplikasi di negara itu (filter by country)
//   Layer 3: Harga (kalau 1 app ada banyak variant/stock berbeda)
// ======================================================

const trxDir = "./database/transaction";
if (!fs.existsSync(trxDir)) fs.mkdirSync(trxDir, { recursive: true });

// Daftar emoji negara untuk tampilan
const COUNTRY_EMOJI = {
    "indonesia": "🇮🇩", "malaysia": "🇲🇾", "singapore": "🇸🇬", "philippines": "🇵🇭",
    "vietnam": "🇻🇳", "thailand": "🇹🇭", "myanmar": "🇲🇲", "cambodia": "🇰🇭",
    "india": "🇮🇳", "pakistan": "🇵🇰", "bangladesh": "🇧🇩", "nepal": "🇳🇵",
    "china": "🇨🇳", "hong kong": "🇭🇰", "taiwan": "🇹🇼", "macau": "🇲🇴",
    "japan": "🇯🇵", "south korea": "🇰🇷", "korea": "🇰🇷", "mongolia": "🇲🇳",
    "usa": "🇺🇸", "united states": "🇺🇸", "canada": "🇨🇦", "mexico": "🇲🇽",
    "brazil": "🇧🇷", "argentina": "🇦🇷", "colombia": "🇨🇴", "chile": "🇨🇱",
    "uk": "🇬🇧", "united kingdom": "🇬🇧", "ireland": "🇮🇪",
    "germany": "🇩🇪", "france": "🇫🇷", "italy": "🇮🇹", "spain": "🇪🇸",
    "netherlands": "🇳🇱", "belgium": "🇧🇪", "portugal": "🇵🇹", "poland": "🇵🇱",
    "russia": "🇷🇺", "ukraine": "🇺🇦", "turkey": "🇹🇷", "kazakhstan": "🇰🇿",
    "uae": "🇦🇪", "saudi arabia": "🇸🇦", "qatar": "🇶🇦", "kuwait": "🇰🇼",
    "egypt": "🇪🇬", "south africa": "🇿🇦", "nigeria": "🇳🇬", "kenya": "🇰🇪",
    "australia": "🇦🇺", "new zealand": "🇳🇿"
};
function getCountryEmoji(name) {
    return COUNTRY_EMOJI[name.toLowerCase().trim()] || "🌍";
}

// (UI 3 layer V1/mbjebe dihapus — diganti UI smscode di bawah)

// ======================================================
// ====== NOKOS V2 (smscode.gg) — UI 3 LAYER ===========
// Sesi terpisah dari V1 supaya tidak bentrok:
//   countryListV2  = [{id, name, emoji}]   dari /catalog/countries
//   serviceListV2  = [{id, name, code}]    dari /catalog/services?country_id=
//   currentCtrIdV2 / currentSvcIdV2        = id terpilih (integer)
//   currentProductsV2 = [{product_id, name, stock, price_api, _hargaJual}]
// Callback prefix khusus V2: v2cp_ / v2ctr_ / v2ap_ / v2svc_ / v2pp_ / buyv2_
// ======================================================

// ── Layer 1 (V2): Pilih Negara ─────────────────────────
async function showCountryPageV2(ctx, page = 1) {
    const countries = getSession(ctx.from.id).countryListV2 || [];
    if (!countries.length) return safeEditOrReply(ctx, "❌ Data negara kosong. Klik ulang Beli Nokos.");

    const perPage   = 10;
    const totalPage = Math.ceil(countries.length / perPage);
    page = Math.max(1, Math.min(page, totalPage));
    const slice = countries.slice((page - 1) * perPage, page * perPage);

    let rows = [];
    for (let i = 0; i < slice.length; i += 2) {
        const c1 = slice[i], c2 = slice[i + 1];
        const r = [{ text: `${c1.emoji || "🌍"} ${c1.name}`, callback_data: `v2ctr_${(page-1)*perPage+i}` }];
        if (c2) r.push({ text: `${c2.emoji || "🌍"} ${c2.name}`, callback_data: `v2ctr_${(page-1)*perPage+i+1}` });
        rows.push(r);
    }
    const nav = [];
    if (page > 1) nav.push({ text: "⬅ Prev", callback_data: `v2cp_${page-1}` });
    if (page < totalPage) nav.push({ text: "Next ➡", callback_data: `v2cp_${page+1}` });
    if (nav.length) rows.push(nav);
    rows.push([{ text: "⬅ Menu", callback_data: "back_menu" }]);

    return safeEditOrReply(ctx,
        `<blockquote>📱 NOMOR VIRTUAL || ${global.botName}</blockquote>
` +
        `🌍 <b>Pilih Negara</b> — ${countries.length} negara | Hal ${page}/${totalPage}

Tap negara untuk lihat aplikasi.`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } }
    );
}

// ── Layer 2 (V2): Pilih Aplikasi (services per negara) ──
async function showAppPageV2(ctx, countryIdx, page = 1) {
    const countries = getSession(ctx.from.id).countryListV2 || [];
    const cObj      = countries[countryIdx];
    if (!cObj) return safeEditOrReply(ctx, "❌ Negara tidak ditemukan. Buka ulang menu.");

    setSession(ctx.from.id, "currentCtrIdxV2", countryIdx);
    setSession(ctx.from.id, "currentCtrIdV2",  cObj.id);

    // services smscode bersifat per-negara → fetch saat negara dipilih
    await safeEditOrReply(ctx, "⏳ Memuat daftar aplikasi...", { parse_mode: "HTML" });
    let services;
    try {
        services = await smscodeGetServices(cObj.id);
        setSession(ctx.from.id, "serviceListV2", services);
    } catch (err) {
        const msg = err.isRateLimit
            ? `⏳ Server sibuk. Tunggu ${err.retryAfter || 60} detik lalu coba lagi.`
            : `❌ Gagal memuat aplikasi: ${err.message}`;
        return safeEditOrReply(ctx, msg, {
            reply_markup: { inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: `v2ctr_${countryIdx}` }, { text: "⬅ Negara", callback_data: "menu_layanan" }]] }
        });
    }

    if (!services.length) {
        return safeEditOrReply(ctx, `❌ Tidak ada aplikasi untuk <b>${cObj.name}</b>. Coba negara lain.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Negara", callback_data: "menu_layanan" }]] } });
    }

    const perPage   = 10;
    const totalPage = Math.ceil(services.length / perPage);
    page = Math.max(1, Math.min(page, totalPage));
    const slice = services.slice((page-1)*perPage, page*perPage);

    let rows = slice.map((svc, i) => ([{
        text         : svc.name,
        callback_data: `v2svc_${countryIdx}_${(page-1)*perPage+i}`
    }]));

    const nav = [];
    if (page > 1) nav.push({ text: "⬅ Prev", callback_data: `v2ap_${countryIdx}_${page-1}` });
    if (page < totalPage) nav.push({ text: "Next ➡", callback_data: `v2ap_${countryIdx}_${page+1}` });
    if (nav.length) rows.push(nav);
    rows.push([{ text: "🔍 Cari", callback_data: "search_app_v2" }, { text: "⬅ Negara", callback_data: "menu_layanan" }]);
    rows.push([{ text: "🏠 Menu", callback_data: "back_menu" }]);

    return safeEditOrReply(ctx,
        `<blockquote>${cObj.emoji || "🌍"} ${cObj.name.toUpperCase()}</blockquote>
📱 <b>Pilih Aplikasi</b> — ${services.length} aplikasi | Hal ${page}/${totalPage}`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } }
    );
}

// ── Layer 3 (V2): Pilih Produk / Harga ─────────────────
async function showProductPageV2(ctx, countryIdx, svcIdx, page = 1) {
    const countries = getSession(ctx.from.id).countryListV2 || [];
    const services  = getSession(ctx.from.id).serviceListV2 || [];
    const cObj      = countries[countryIdx];
    const sObj      = services[svcIdx];
    if (!cObj || !sObj) return safeEditOrReply(ctx, "❌ Data tidak ditemukan. Buka ulang menu.");

    setSession(ctx.from.id, "currentSvcIdxV2", svcIdx);
    setSession(ctx.from.id, "currentSvcIdV2",  sObj.id);

    await safeEditOrReply(ctx, `⏳ Memuat produk ${sObj.name} — ${cObj.name}...`, { parse_mode: "HTML" });

    let products;
    try {
        const raw     = await smscodeGetProducts(sObj.id, cObj.id);
        const user    = getUser(ctx.from.id, ctx.from.username);
        const isOwner = global.ownerID.includes(String(ctx.from.id));
        const markup  = isOwner ? 0 : (user.vip ? global.profitVip : global.profitUser);

        products = raw.map(p => ({
            product_id : Number(p.id),                       // smscode pakai id numerik
            name       : p.name,
            stock      : Number(p.available) || 0,
            price_api  : Number(p.price) || 0,
            _hargaJual : Math.round((Number(p.price) || 0) * (1 + markup / 100))
        })).filter(p => p.stock > 0 && p.price_api > 0);

        console.log(`[SMSCODE] ${sObj.name}/${cObj.name}: ${products.length} produk`);
    } catch (err) {
        console.log("SMSCODE PRODUCTS ERROR:", err.message);
        const msg = err.isRateLimit
            ? `⏳ Server sibuk. Tunggu ${err.retryAfter || 60} detik lalu coba lagi.`
            : `❌ Gagal memuat produk: ${err.message}`;
        return safeEditOrReply(ctx, msg, {
            reply_markup: { inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: `v2svc_${countryIdx}_${svcIdx}` }, { text: "⬅ Aplikasi", callback_data: `v2ctr_${countryIdx}` }]] }
        });
    }

    if (!products.length) {
        return safeEditOrReply(ctx,
            `❌ Stok <b>${sObj.name}</b> di <b>${cObj.name}</b> sedang habis.
Coba negara lain atau aplikasi lain.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Aplikasi", callback_data: `v2ctr_${countryIdx}` }]] } }
        );
    }

    const perPage   = 8;
    const totalPage = Math.ceil(products.length / perPage);
    page = Math.max(1, Math.min(page, totalPage));
    const slice = products.slice((page-1)*perPage, page*perPage);

    let text = `<blockquote>${cObj.emoji || "🌍"} ${sObj.name} — ${cObj.name}</blockquote>
💰 <b>Pilih Harga</b> | Hal ${page}/${totalPage}

`;
    let rows  = [];
    slice.forEach((p, i) => {
        const globalIdx = (page-1)*perPage+i;
        text += `<b>${globalIdx+1}.</b> ${p.name}
   📦 Stok: ${p.stock} | 💰 <b>Rp ${p._hargaJual.toLocaleString("id-ID")}</b>

`;
        const cleanName = cleanProductName(p.name).substring(0, 28);
        rows.push([{
            text         : `${globalIdx+1}. ${cleanName} — Rp ${p._hargaJual.toLocaleString("id-ID")}`,
            callback_data: `buyv2_${globalIdx}`
        }]);
    });

    const nav = [];
    if (page > 1) nav.push({ text: "⬅ Prev", callback_data: `v2pp_${countryIdx}_${svcIdx}_${page-1}` });
    if (page < totalPage) nav.push({ text: "Next ➡", callback_data: `v2pp_${countryIdx}_${svcIdx}_${page+1}` });
    if (nav.length) rows.push(nav);
    rows.push([{ text: "⬅ Aplikasi", callback_data: `v2ctr_${countryIdx}` }, { text: "🏠 Menu", callback_data: "back_menu" }]);

    setSession(ctx.from.id, "currentProductsV2", products);

    return safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
}

// ======================================================
// ============ POLLING ORDER (MB JEBE) =================
// ======================================================


function startPollingOrder(bot, botCtx, userId, orderId) {
    let pollCount = 0;
    const MAX_POLLS = 240; // ~20 menit (240 × 5 detik)

    const interval = setInterval(async () => {
        pollCount++;
        const file = `${trxDir}/${userId}.json`;
        if (!fs.existsSync(file)) { clearInterval(interval); unregisterPolling(`ord_${userId}`); return; }
        const trx = safeReadJSON(file, null);
        if (!trx || !trx.order_id) { clearInterval(interval); unregisterPolling(`ord_${userId}`); return; }

        // Batas waktu 8 menit
        if (pollCount > MAX_POLLS || Date.now() > trx.expires_ts) {
            clearInterval(interval);
            unregisterPolling(`ord_${userId}`);
            // MB JEBE otomatis refund saat expired, kita hanya cleanup
            try {
                await saveFinalTransaction(trx, {
                    username: getUser(userId).username || "",
                    user_type: getUserType(userId, getUser(userId)),
                    price_sell: trx.price,
                    price_api: estimatePriceApi(trx.price, getUserType(userId, getUser(userId))),
                    profit: 0, status: "expired", otp: null,
                    finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
                });
            } catch {}
            if (fs.existsSync(file)) fs.unlinkSync(file);
            return botCtx.reply("⚠️ Order expired.\nSaldo otomatis dikembalikan oleh sistem.", { parse_mode: "HTML" });
        }

        try {
            const d   = await getOrderByProvider(trx.provider, orderId);
            const st  = d.status;
            const otp = d.otp_code;

            // OTP MASUK
            if (st === "OTP_RECEIVED" && otp && otp !== "-") {
                clearInterval(interval);
                unregisterPolling(`ord_${userId}`);

                const u     = getUser(userId);
                const uType = getUserType(userId, u);
                const priceApi = estimatePriceApi(trx.price, uType);
                await saveFinalTransaction(trx, {
                    username: u.username || "", user_type: uType,
                    price_sell: trx.price, price_api: priceApi,
                    profit: uType === "owner" ? 0 : (trx.price - priceApi),
                    status: "success", otp,
                    finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
                });
                if (fs.existsSync(file)) fs.unlinkSync(file);

                const censoredNo = (d.phone_number || trx.phone_number || "").slice(0, -4) + "****";

                const waktuOrder = moment().tz("Asia/Jakarta");
                const notifOrder =
                    `✅ <b>ORDER SUKSES SELESAI DITERIMA</b>\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `📋 <b>ORDER INFORMATION</b>\n` +
                    `• Nama User: ${u.username || "User"}\n` +
                    `• Nominal: <b>Rp ${trx.price.toLocaleString("id-ID")}</b>\n` +
                    `• Tanggal: ${waktuOrder.format("MMM DD, YYYY")}\n` +
                    `• Waktu: ${waktuOrder.format("HH.mm.ss")}\n` +
                    `• Layanan: ${trx.service}\n\n` +
                    `<b>INFORMATION</b>\n` +
                    `• Status: ✅ Sukses Telah Diterima\n` +
                    `• Catatan: aman dan sudah terverifikasi`;

                // Kirim notif ke grup pembelian
                if (global.grupNotifPembelian) {
                    await autoUpSend(bot, global.grupNotifPembelian, notifOrder, global.botUsername);
                }

                // NOTE: autoUpChannel sengaja TIDAK digunakan di sini karena grupNotifPembelian
                // sudah menunjuk ke channel yang sama → mencegah pesan dobel di channel transaksi

                await botCtx.reply(
                    `✅ <b>OTP MASUK!</b>\n\n` +
                    `<b>Order:</b> <code>${orderId}</code>\n` +
                    `<b>Nomor:</b> ${d.phone_number || trx.phone_number}\n\n` +
                    `<b>OTP:</b>\n<pre>${otp}</pre>\n\n` +
                    `<b>Saldo terpotong:</b> Rp ${trx.price.toLocaleString("id-ID")}`,
                    { parse_mode: "HTML", reply_markup: { inline_keyboard: [
                        [{ text: "📋 Salin OTP", copy_text: { text: String(otp) } }],
                        [{ text: "🔙 Menu", callback_data: "back_menu" }]
                    ] } }
                );

            } else if (st === "CANCELED") {
                // Order dibatalkan/expired di MB JEBE → kembalikan saldo user
                clearInterval(interval);
                unregisterPolling(`ord_${userId}`);

                // Refund saldo user
                const db = loadDB();
                if (db.users[userId]) {
                    db.users[userId].saldo += trx.price;
                    await saveDB(db);
                }

                await saveFinalTransaction(trx, {
                    status: "expired", otp: null,
                    finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
                });
                if (fs.existsSync(file)) fs.unlinkSync(file);
                return botCtx.reply(
                    `❌ <b>Order dibatalkan/expired</b>\n💰 Saldo <b>Rp ${trx.price.toLocaleString("id-ID")}</b> dikembalikan.`,
                    { parse_mode: "HTML" }
                );
            }
        } catch (err) {
            console.log("ORDER POLL ERROR:", err.response?.data || err.message);
        }
    }, 7000);
    registerPolling(`ord_${userId}`, interval);
}

async function manualCheckOrder(ctx, userId) {
    const file = `${trxDir}/${userId}.json`;
    if (!fs.existsSync(file)) return ctx.answerCbQuery("Tidak ada order pending.");
    const trx = safeReadJSON(file, {});
    try {
        const d = await getOrderByProvider(trx.provider, trx.order_id);
        const otpNow = d.otp_code || "";
        const statusMsg = await ctx.reply(
            `📦 <b>Status Order</b>\n` +
            `Order ID: <code>${trx.order_id}</code>\n` +
            `Status  : <b>${d.raw_status || d.status}</b>\n` +
            `Nomor   : <b>${d.phone_number || trx.phone_number}</b>\n` +
            `OTP     : <code>${otpNow || "Menunggu..."}</code>`,
            { parse_mode: "HTML", reply_markup: otpNow
                ? { inline_keyboard: [[{ text: "📋 Salin OTP", copy_text: { text: String(otpNow) } }]] }
                : undefined }
        );
        // Simpan message_id pesan status untuk dihapus saat cancel
        try {
            const trxData = safeReadJSON(file, {});
            trxData.status_msg_id = statusMsg.message_id;
            fs.writeFileSync(file, JSON.stringify(trxData, null, 2));
        } catch {}
        ctx.answerCbQuery("Status diperbarui.");
    } catch (err) {
        console.log("MANUAL CHECK ERROR:", err.message);
        ctx.answerCbQuery("Error cek status.");
    }
}


async function cancelOrder(ctx, userId) {
    const file = `${trxDir}/${userId}.json`;
    if (!fs.existsSync(file)) return ctx.answerCbQuery("Tidak ada order pending.");
    const trx = safeReadJSON(file, {});

    // Cek durasi batal: tombol batal baru bisa diklik setelah jeda minimal provider
    if (trx.cancel_after && Date.now() < trx.cancel_after) {
        const sisaDetik = Math.ceil((trx.cancel_after - Date.now()) / 1000);
        const sisaMenit = Math.ceil(sisaDetik / 60);
        await ctx.answerCbQuery(
            `⏳ Order belum bisa dibatalkan.\nTunggu ${sisaDetik > 60 ? sisaMenit + " menit" : sisaDetik + " detik"} lagi.`,
            { show_alert: true }
        );
        return;
    }

    try {
        await cancelOrderByProvider(trx.provider, trx.order_id);
        const db = loadDB();
        if (db.users[userId]) {
            db.users[userId].saldo += trx.price;
            await saveDB(db);
        }
        await saveFinalTransaction(trx, {
            status: "canceled", otp: null,
            finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
        });
        if (fs.existsSync(file)) fs.unlinkSync(file);

        ctx.answerCbQuery("Order dibatalkan.");

        // Hapus pesan order dari chat
        const chatId = trx.msg_chat_id || ctx.chat?.id;
        if (chatId && trx.msg_id) {
            try { await ctx.telegram.deleteMessage(chatId, trx.msg_id); } catch {}
        }
        // Hapus pesan "Status Order" kalau ada
        if (chatId && trx.status_msg_id) {
            try { await ctx.telegram.deleteMessage(chatId, trx.status_msg_id); } catch {}
        }

        // Kirim notif singkat lalu hapus setelah 4 detik
        const notifMsg = await ctx.reply(
            `❌ <b>Order dibatalkan</b>\n💰 Saldo <b>Rp ${trx.price.toLocaleString("id-ID")}</b> dikembalikan.`,
            { parse_mode: "HTML" }
        );
        setTimeout(async () => {
            try { await ctx.telegram.deleteMessage(notifMsg.chat.id, notifMsg.message_id); } catch {}
        }, 4000);

    } catch (e) {
        await ctx.answerCbQuery(`❌ ${e.message}`, { show_alert: true });
    }
}


// ======================================================
// ===================== MAIN BOT =======================
// ======================================================

export default function main(bot) {

    setInterval(() => kirimLaporanPenjualan(bot), 60 * 1000);
    setInterval(() => cekJadwalMaintenance(bot), 60 * 1000);

    // =================== MIDDLEWARE MAINTENANCE ===================
    // Cek apakah sedang dalam jam maintenance (default: 23:00 - 00:10 WIB)
    bot.use(async (ctx, next) => {
        const userId = ctx.from?.id;
        if (!userId) return next();
        // Owner selalu bisa akses bahkan saat maintenance
        if (global.ownerID.includes(String(userId))) return next();

        if (isMaintenanceTime()) {
            const now = moment().tz("Asia/Jakarta");
            const msg =
                `🔧 <b>BOT SEDANG MAINTENANCE</b>\n\n` +
                `Bot tidak dapat digunakan dari pukul <b>${global.maintenanceStart}</b> sampai <b>${global.maintenanceEnd} WIB</b>.\n\n` +
                `⏰ Waktu sekarang: ${now.format("HH:mm:ss")} WIB\n\n` +
                `Silakan kembali setelah pukul ${global.maintenanceEnd} WIB.\n` +
                `Terima kasih atas kesabaran kamu! 🙏`;
            try {
                if (ctx.callbackQuery) await ctx.answerCbQuery("🔧 Sedang maintenance!", { show_alert: true });
                await ctx.reply(msg, { parse_mode: "HTML" });
            } catch {}
            return; // Stop, jangan lanjut ke handler
        }
        return next();
    });

    // =================== MIDDLEWARE WAJIB JOIN ===================
    bot.use(async (ctx, next) => {
        const userId = ctx.from?.id;
        if (!userId) return next();
        if (global.ownerID.includes(String(userId))) return next();

        // FIX BUG DOBEL PESAN:
        // Skip /start dan cek_join — keduanya sudah handle logika wajib join sendiri.
        // Kalau middleware ikut jalan di /start, user dapat 2 pesan verifikasi sekaligus.
        if (ctx.callbackQuery?.data === "cek_join") return next();
        if (ctx.message?.text?.startsWith("/start")) return next();

        // Cek hanya jika ada wajib join yang dikonfigurasi
        if (!global.wajibJoinSaluran && !global.wajibJoinGrup) return next();

        try {
            const { harus, belumJoin } = await cekWajibJoin(bot, userId);
            if (!harus) return next();

            const userInfo = { id: ctx.from.id, first_name: ctx.from.first_name, username: ctx.from.username };
            const { teks, keyboard } = pesanWajibJoin(belumJoin, userInfo);
            if (ctx.callbackQuery) {
                // Untuk callback — edit pesan yang ada, jangan kirim baru supaya tidak dobel
                try { await ctx.answerCbQuery("⚠️ Kamu belum join!", { show_alert: true }); } catch {}
                try {
                    await ctx.editMessageText(teks, { parse_mode: "HTML", reply_markup: keyboard });
                } catch {
                    await ctx.reply(teks, { parse_mode: "HTML", reply_markup: keyboard });
                }
                return;
            }
            return ctx.reply(teks, { parse_mode: "HTML", reply_markup: keyboard });
        } catch (e) {
            console.error("MIDDLEWARE WAJIB JOIN ERROR:", e.message);
            return next();
        }
    });

    // =================== TOMBOL CEK JOIN ===================
    // FIX: Tidak kirim pesan baru sama sekali — cukup edit pesan yang sudah ada.
    // Ini menghilangkan dobel pesan saat user pencet "Cek Ulang Keanggotaan".
    bot.action("cek_join", async (ctx) => {
        const userId = ctx.from.id;

        // Tampilkan loading di tombol saja — TIDAK reply pesan baru
        try { await ctx.answerCbQuery("⏳ Memeriksa keanggotaan..."); } catch {}

        const { harus, belumJoin } = await cekWajibJoin(bot, userId);

        if (!harus) {
            // Semua sudah join → hapus pesan verifikasi lalu tampilkan menu utama
            try { await ctx.deleteMessage(); } catch {}
            return kirimMenuUtama(bot, ctx);
        }

        // Masih ada yang belum join → UPDATE pesan yang sama (editMessageText), bukan kirim baru
        // Ini yang mencegah dobel: user tetap lihat 1 pesan, isinya diperbarui
        const userInfo = { id: ctx.from.id, first_name: ctx.from.first_name, username: ctx.from.username };
        const { teks, keyboard } = pesanWajibJoin(belumJoin, userInfo);

        // FIX DOBEL PESAN: answerCbQuery sudah dipanggil di atas ("⏳ Memeriksa...").
        // Jangan panggil lagi dengan show_alert=true — Telegram akan error di pemanggilan ke-2,
        // lalu catch block jalankan ctx.reply → itulah sumber pesan dobel.
        // User sudah tahu dari tombol yg tetap ada bahwa mereka belum join.

        // Edit pesan yang sudah ada — kalau gagal edit (misal pesan sudah terlalu lama), baru reply
        try {
            await ctx.editMessageText(teks, { parse_mode: "HTML", reply_markup: keyboard });
        } catch {
            // Fallback: hanya jika edit benar-benar gagal
            await ctx.reply(teks, { parse_mode: "HTML", reply_markup: keyboard });
        }
    });

    // ================= /broadcast (lama, tetap support) =================
    bot.command("broadcast", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");
        const text = ctx.message.text.replace("/broadcast", "").trim();
        if (!text) return ctx.reply("❌ Format:\n/broadcast isi pesan");
        const db = loadDB();
        const users = Object.values(db.users || {});
        let success = 0, failed = 0;
        const startMsg = await ctx.reply(`📢 Broadcast dimulai ke ${users.length} user...`);
        for (const user of users) {
            try {
                await ctx.telegram.sendMessage(user.id, `📢 <b>Broadcast</b>\n\n${text}`, { parse_mode: "HTML" });
                success++;
            } catch { failed++; }
            await sleep(80);
        }
        // Edit pesan status menjadi hasil akhir
        try {
            await ctx.telegram.editMessageText(ctx.chat.id, startMsg.message_id, null,
                `✅ <b>Broadcast selesai!</b>\n\n` +
                `🏁 Total  : ${users.length} user\n` +
                `📨 Berhasil: <b>${success}</b>\n` +
                `❌ Gagal  : <b>${failed}</b>`,
                { parse_mode: "HTML" }
            );
        } catch { ctx.reply(`✅ Broadcast selesai\n📨 Berhasil: ${success}\n❌ Gagal: ${failed}`); }
    });

    // ================= /bc — Broadcast Forward (reply pesan) =================
    // Cara pakai: reply pesan yang ingin dibroadcast, lalu ketik /bc
    bot.command("bc", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");

        // Harus reply ke pesan yang ingin diforward
        const replyTo = ctx.message?.reply_to_message;
        if (!replyTo) {
            return ctx.reply(
                `⚠️ <b>PERHATIAN!</b>\n\nReply pesan yang ingin di broadcast.`,
                { parse_mode: "HTML" }
            );
        }

        const db = loadDB();
        const users = Object.values(db.users || {});
        if (!users.length) return ctx.reply("❌ Tidak ada user terdaftar.");

        // Hapus command /bc supaya chat lebih bersih
        try { await ctx.deleteMessage(); } catch {}

        let success = 0, failed = 0;
        const startMsg = await ctx.reply(`📢 Broadcast dimulai ke <b>${users.length}</b> user...`, { parse_mode: "HTML" });

        for (const user of users) {
            try {
                // Forward pesan asli persis seperti aslinya (termasuk foto, video, dll)
                await ctx.telegram.forwardMessage(user.id, ctx.chat.id, replyTo.message_id);
                success++;
            } catch { failed++; }
            await sleep(80); // delay antar kirim agar tidak kena rate limit Telegram
        }

        // Edit pesan progres jadi hasil akhir
        try {
            await ctx.telegram.editMessageText(ctx.chat.id, startMsg.message_id, null,
                `✅ <b>Broadcast selesai!</b>\n\n` +
                `🏁 Total  : ${users.length} user\n` +
                `📨 Berhasil: <b>${success}</b>\n` +
                `❌ Gagal  : <b>${failed}</b>`,
                { parse_mode: "HTML" }
            );
        } catch {}
    });

    // ================= /bcsm — Broadcast + PIN (reply pesan) =================
    // Cara pakai: reply pesan yang ingin dibroadcast+pin, lalu ketik /bcsm
    // Pesan akan diforward ke semua user, lalu dipin, lalu auto-unpin setelah 7 detik
    bot.command("bcsm", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");

        const replyTo = ctx.message?.reply_to_message;
        if (!replyTo) {
            return ctx.reply(
                `⚠️ <b>PERHATIAN!</b>\n\nReply pesan yang ingin di broadcast.`,
                { parse_mode: "HTML" }
            );
        }

        const db = loadDB();
        const users = Object.values(db.users || {});
        if (!users.length) return ctx.reply("❌ Tidak ada user terdaftar.");

        try { await ctx.deleteMessage(); } catch {}

        let success = 0, failed = 0;
        const startMsg = await ctx.reply(
            `📢 Broadcast + PIN dimulai ke <b>${users.length}</b> user...`,
            { parse_mode: "HTML" }
        );

        for (const user of users) {
            try {
                // Forward pesan ke user
                const sentMsg = await ctx.telegram.forwardMessage(user.id, ctx.chat.id, replyTo.message_id);

                // Pin pesan yang baru dikirim di chat user tersebut
                // disable_notification: true supaya pin tidak mengirim notif tambahan
                try {
                    await ctx.telegram.pinChatMessage(user.id, sentMsg.message_id, { disable_notification: true });
                } catch {} // skip kalau bot tidak bisa pin (misal user private)

                // Auto-unpin setelah 7 detik
                // Pakai closure agar userId dan messageId tidak tertukar antar iterasi
                const uid = user.id;
                const mid = sentMsg.message_id;
                setTimeout(async () => {
                    try { await ctx.telegram.unpinChatMessage(uid, mid); } catch {}
                }, 7000);

                success++;
            } catch { failed++; }
            await sleep(80);
        }

        try {
            await ctx.telegram.editMessageText(ctx.chat.id, startMsg.message_id, null,
                `✅ <b>Broadcast + PIN selesai!</b>\n\n` +
                `🏁 Total  : ${users.length} user\n` +
                `📨 Berhasil: <b>${success}</b>\n` +
                `❌ Gagal  : <b>${failed}</b>\n\n` +
                `📌 Pesan dipin selama 7 detik lalu auto-unpin.`,
                { parse_mode: "HTML" }
            );
        } catch {}
    });

    // ================= /users =================
    bot.command("users", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");
        const db = loadDB();
        const users = Object.values(db.users || {});
        let msg = `Total Pengguna: ${users.length}\n\n`;
        users.forEach((u, i) => {
            msg += `${i + 1}. ID: ${u.id}\n   - @${u.username || "tidak ada"}\n   - Saldo: Rp ${u.saldo.toLocaleString("id-ID")}\n   - Daftar: ${u.registered}\n\n`;
        });
        try {
            const p = "./database/users.txt";
            fs.writeFileSync(p, msg);
            await ctx.replyWithDocument({ source: p });
            fs.unlinkSync(p);
        } catch { ctx.reply("❌ Gagal mengirim daftar."); }
    });

    // ================= /backup =================
    // ================= /cekapi (diagnosis MB JEBE) =================
    bot.command("cekapi", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Bukan owner.");
        await ctx.reply("⏳ Cek API smscode.gg...");
        let out = "";
        try {
            const bal = await smscodeGetBalance();
            out += `✅ Saldo akun smscode: <b>Rp ${bal.balance.toLocaleString("id-ID")}</b> (${bal.currency})\n`;
        } catch (e) {
            out += `❌ Cek saldo gagal: ${e.message}\n`;
        }
        try {
            const countries = await smscodeGetCountries();
            out += `\n🌍 Total negara: <b>${countries.length}</b>\n`;
            const idn = countries.find(c => /indonesia/i.test(c.name)) || countries[0];
            if (idn) {
                const svc = await smscodeGetServices(idn.id);
                out += `📱 Aplikasi di ${idn.name}: <b>${svc.length}</b>\n`;
                if (svc[0]) {
                    const prods = await smscodeGetProducts(svc[0].id, idn.id);
                    out += `📦 Contoh produk ${svc[0].name}: <b>${prods.length}</b>\n`;
                    prods.slice(0, 3).forEach(p => { out += `  • ${p.name} — Rp ${Number(p.price).toLocaleString("id-ID")} (stok ${p.available})\n`; });
                }
            }
        } catch (e) {
            out += `\n❌ Cek katalog gagal: ${e.message}`;
        }
        await ctx.reply(`🔍 <b>DIAGNOSIS API SMSCODE</b>\n\n${out}`, { parse_mode: "HTML" });
    });

    // Diagnosa gateway deposit Cashi.id — tampilkan respon MENTAH dari create-order
    // Pakai: /cekcashi  atau  /cekcashi 10000
    bot.command("cekcashi", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Bukan owner.");
        const parts  = ctx.message.text.trim().split(/\s+/);
        const amount = Math.max(1000, Number((parts[1] || "").replace(/[^0-9]/g, "")) || 1000);
        if (!global.cashiApiKey || global.cashiApiKey.includes("ISI_APIKEY")) {
            return ctx.reply("❌ global.cashiApiKey belum diisi di settings.js");
        }
        const orderId = `CEK-${Date.now()}`;
        const bodyReq = { amount, order_id: orderId };
        if (global.cashiQrisCustom) bodyReq.QRIS_CUSTOM = true;
        await ctx.reply(`⏳ Tes create-order Cashi.id (amount=${amount})...`);
        try {
            const res  = await axiosWithRetry({
                method: "POST", url: `${CASHI_BASE}/create-order`,
                headers: cashiHeaders(), data: bodyReq, validateStatus: () => true
            }, 1);
            const body = res.data;
            let pretty;
            try { pretty = typeof body === "string" ? body.slice(0, 1500) : JSON.stringify(body, null, 2).slice(0, 1500); }
            catch { pretty = String(body).slice(0, 1500); }
            await ctx.reply(
                `🔍 <b>DIAGNOSIS CASHI.ID</b>\n\n` +
                `• HTTP Status: <b>${res.status}</b>\n` +
                `• Base: <code>${CASHI_BASE}</code>\n` +
                `• order_id tes: <code>${orderId}</code>\n\n` +
                `<b>Respon mentah:</b>\n<pre>${pretty.replace(/</g, "&lt;")}</pre>\n\n` +
                `ℹ️ Pastikan ada field QR (qr_string / qr_image / qris_url) di respons. ` +
                `Kalau nama field-nya beda, kirim screenshot ini ke developer untuk disesuaikan.`,
                { parse_mode: "HTML" }
            );
        } catch (e) {
            await ctx.reply(`❌ Gagal hubungi Cashi.id: ${e.message}`);
        }
    });

    // Jalankan broadcast harga manual sekarang (owner)
    bot.command("cekharga", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Bukan owner.");
        await ctx.reply("⏳ Cek perubahan harga sekarang...");
        const r = await runHargaMonitor(bot);
        if (!r.ok) return ctx.reply(`⚠️ Gagal: ${r.reason}\n\nCek: smscode key, channel (hargaChannel/wajibJoinHarga), dan bot harus ADMIN di channel itu.`);
        const miss = (r.missed && r.missed.length) ? `\n⚠️ Tidak ketemu: ${r.missed.slice(0, 8).join(", ")}${r.missed.length > 8 ? " …" : ""}` : "";
        if (r.changed === 0) return ctx.reply(`✅ Tidak ada perubahan harga.\nGrup dipantau: ${r.groups}.${miss}\n\nBaseline tersimpan — perubahan berikutnya otomatis di-broadcast ke channel.`);
        return ctx.reply(`✅ Broadcast terkirim: ${r.changed} server berubah dari ${r.groups} grup (app×negara).${miss}`);
    });

        bot.command("backup", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");
        try {
            await ctx.reply("📦 Membuat backup semua database...");

            // Daftar semua file DB yang penting
            const backupFiles = [
                [userDBPath,                "📊 User DB (saldo, VIP, dll)"],
                [transactionsPath,          "💸 Transaksi"],
                ["./database/referral.json", "🤝 Referral"],
                ["./database/komisi_bulanan.json", "💰 Komisi Referral"],
                ["./database/manual_products.json", "📦 Produk Manual"]
            ];

            // Backup setiap file secara terpisah supaya owner bisa pilih restore
            for (const [src, caption] of backupFiles) {
                if (!fs.existsSync(src)) continue;
                const fname = src.split("/").pop().replace(".json", "");
                const ts    = moment().tz("Asia/Jakarta").format("YYYYMMDD_HHmmss");
                const tmp   = `./database/${fname}_${ts}.bak.txt`;
                fs.writeFileSync(tmp, fs.readFileSync(src, "utf-8"));
                try {
                    await ctx.replyWithDocument({ source: tmp }, { caption: `${caption}\n📅 ${moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")}` });
                } catch (e) {
                    console.warn("BACKUP SEND FAIL:", e.message);
                }
                try { fs.unlinkSync(tmp); } catch {}
            }

            // Backup ZIP semua sekaligus juga (sebagai opsi)
            ctx.reply("✅ Backup selesai. Simpan semua file di atas dengan aman!\n\n💡 Tips:\n• Untuk restore: kirim file backup ke owner, lalu rename jadi nama asli & taruh di folder database/\n• Disarankan backup setiap hari");
        } catch (e) {
            console.error("BACKUP ERROR:", e.message);
            ctx.reply("❌ Gagal backup: " + e.message);
        }
    });

    // ================= /laporan =================
    bot.command("laporan", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.reply("❌ Kamu bukan owner.");
        ctx.reply("📊 <b>Pilih Jenis Laporan</b>", {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "☀️ Harian", callback_data: "laporan_harian" }, { text: "📅 Mingguan", callback_data: "laporan_mingguan" }, { text: "🗓️ Bulanan", callback_data: "laporan_bulanan" }]
                ]
            }
        });
    });

    // ================= /server =================
    // ================= /start =================
    bot.start(async (ctx) => {
        try {
            const userId = ctx.from.id;
            getUser(userId, ctx.from.username);

            // ── WAJIB JOIN CHECK (langsung di /start, tidak bergantung middleware) ──
            if ((global.wajibJoinSaluran || global.wajibJoinGrup) && !global.ownerID.includes(String(userId))) {
                const { harus, belumJoin } = await cekWajibJoin(bot, userId);
                if (harus) {
                    const userInfo = { id: ctx.from.id, first_name: ctx.from.first_name, username: ctx.from.username };
                    const { teks, keyboard } = pesanWajibJoin(belumJoin, userInfo);
                    return ctx.reply(teks, { parse_mode: "HTML", reply_markup: keyboard });
                }
            }

            // ── Cek parameter referral: /start ref_USERID ──
            const payload = ctx.startPayload || "";
            if (payload.startsWith("ref_")) {
                const referrerId = payload.replace("ref_", "").trim();
                if (referrerId && referrerId !== String(userId)) {
                    const berhasil = daftarReferral(userId, referrerId);
                    if (berhasil) {
                        try {
                            const newUserNama = ctx.from.username ? `@${ctx.from.username}` : `ID ${userId}`;
                            await bot.telegram.sendMessage(Number(referrerId),
                                `🎉 <b>Teman Baru Bergabung!</b>\n\n` +
                                `${newUserNama} baru saja bergabung lewat link referralmu.\n\n` +
                                `Kamu akan dapat komisi <b>${global.referralPersen}%</b> setiap kali mereka deposit! 💰`,
                                { parse_mode: "HTML" }
                            );
                        } catch {}
                    }
                }
            }

            return kirimMenuUtama(bot, ctx);
        } catch (e) {
            console.error("ERROR /start:", e.message);
        }
    });

    // ===== HELPER: kirim menu utama (bisa dipanggil dari mana saja) =====
    async function kirimMenuUtama(bot, ctx) {
        const u = getUser(ctx.from.id, ctx.from.username);
        const isOwner = global.ownerID.includes(String(u.id));
        const images = global.menuImages || [];
        const photoUrl = images[Math.floor(Math.random() * images.length)] || "https://telegra.ph/file/2e4f0b296f08c3e1b9758.jpg";

        let inline_keyboard = [
            [{ text: "👤 Profil", callback_data: "menu_profile" }, { text: "✨ Beli Nokos ✨", callback_data: "menu_layanan" }],
            [{ text: "💰 Deposit Otomatis", callback_data: "menu_deposit" }, { text: "🏧 Deposit ke Owner", callback_data: "menu_deposit_owner" }],
            [{ text: "🛍️ Produk Manual", callback_data: "menu_manual" }, { text: "🤝 Undang Teman", callback_data: "menu_referral" }],
            [{ text: "📜 Riwayat", callback_data: "menu_history" }, { text: "🏆 Leaderboard", callback_data: "top_deposits" }],
            [{ text: "🤖 Bantuan AI", callback_data: "deposit_ai_helper" }, { text: "ℹ️ Info & Syarat", callback_data: "menu_info" }],
            [{ text: "💬 INFORMASI", url: global.grubinformasilink }],
        ];
        if (isOwner) {
            inline_keyboard.push([{ text: "💸 Withdraw", callback_data: "menu_wd" }]);
            inline_keyboard.push([{ text: "👑 ADMIN PANEL", callback_data: "admin_panel" }]);
            inline_keyboard.push([{ text: "📊 Laporan", callback_data: "menu_laporan" }]);
            inline_keyboard.push([{ text: "🗑️ Reset Database", callback_data: "menu_reset_db" }]);
        }
        inline_keyboard.push([{ text: "👑 OWNER", url: `https://t.me/${global.ownerUsername}` }]);

        const caption =
            `<blockquote>NOMOR VIRTUAL || ${global.botName}🤖</blockquote>\n` +
            `✨ Halo, <b>${ctx.from.first_name}</b>! Selamat datang\n\n` +
            `┌── <b>Informasi Akun</b>\n` +
            `│ • ID      : <code>${u.id}</code>\n` +
            `│ • Username: @${u.username || "unknown"}\n` +
            `│ • Saldo   : <b>Rp ${u.saldo.toLocaleString("id-ID")}</b>\n` +
            `│ • VIP     : <b>${u.vip ? "✅ YES" : "NO"}</b>\n` +
            `│ • Channel : t.me/${global.wajibJoinSaluran || "FahriXyz_OTP"}\n` +
            `│ • Log TRX : t.me/${global.wajibJoinGrup || "Proof_Fahr1Xyz"}\n` +
            `└──────────────────\n\n` +
            `Pilih menu di bawah.`;

        // Auto-delete pesan lama sebelum kirim menu utama (photo baru)
        if (ctx.callbackQuery?.message) {
            try { await ctx.deleteMessage(); } catch {}
        }

        return ctx.replyWithPhoto(photoUrl, { caption, parse_mode: "HTML", reply_markup: { inline_keyboard } });
    }

    // ================= PROFIL =================
    bot.action("menu_profile", async (ctx) => {
        const u = getUser(ctx.from.id, ctx.from.username);
        await safeEditOrReply(ctx,
            `<blockquote><b>👤 Profil Anda</b></blockquote>\n• ID       : <code>${u.id}</code>\n• Username : @${ctx.from.username || "unknown"}\n• Saldo    : <b>Rp ${u.saldo.toLocaleString("id-ID")}</b>\n• VIP      : ${u.vip ? "✅ YES" : "NO"}\n• Daftar   : ${u.registered}`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
        );
        ctx.answerCbQuery();
    });

    // ================= GANTI SERVER =================
    // ================= LAPORAN =================
    bot.action("menu_laporan", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Kamu bukan owner.");
        await safeEditOrReply(ctx, "📊 <b>Pilih Jenis Laporan</b>", {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "☀️ Harian", callback_data: "laporan_harian" }, { text: "📅 Mingguan", callback_data: "laporan_mingguan" }, { text: "🗓️ Bulanan", callback_data: "laporan_bulanan" }],
                    [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                ]
            }
        });
        ctx.answerCbQuery();
    });

    for (const p of ["harian", "mingguan", "bulanan"]) {
        bot.action(`laporan_${p}`, async (ctx) => {
            if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
            const r = await buatLaporanPenjualan(p);
            await ctx.reply(r, { parse_mode: "HTML" });
            ctx.answerCbQuery();
        });
    }

    // ========================= RESET DATABASE (OWNER) =========================

    bot.action("menu_reset_db", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();

        // Hitung statistik sebelum ditampilkan
        ensureTransactionsDB();
        const trxDb   = safeReadJSON(transactionsPath, {});
        const userDb  = loadDB();
        const jumlahUser = Object.keys(userDb.users || {}).length;
        const jumlahTrx  = Object.values(trxDb).reduce((s, arr) => s + arr.length, 0);

        await safeEditOrReply(ctx,
            `<blockquote>🗑️ <b>RESET DATABASE</b></blockquote>\n\n` +
            `⚠️ <b>HATI-HATI!</b> Aksi ini tidak bisa dibatalkan.\n\n` +
            `Pilih apa yang ingin direset:\n\n` +
            `📊 Transaksi : <b>${jumlahTrx} data</b>\n` +
            `👥 Pengguna  : <b>${jumlahUser} user</b>\n\n` +
            `Saldo user <b>tidak</b> akan terhapus kecuali pilih reset saldo.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🗑️ Hapus Semua Transaksi", callback_data: "reset_confirm_trx" }],
                        [{ text: "💰 Reset Semua Saldo User (jadi 0)", callback_data: "reset_confirm_saldo" }],
                        [{ text: "🏆 Reset Top Ranking (hapus transaksi deposit)", callback_data: "reset_confirm_ranking" }],
                        [{ text: "☢️ RESET TOTAL (Transaksi + Saldo)", callback_data: "reset_confirm_total" }],
                        [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                    ]
                }
            }
        );
    });

    // ── Konfirmasi sebelum eksekusi ──
    for (const tipe of ["trx", "saldo", "ranking", "total"]) {
        bot.action(`reset_confirm_${tipe}`, async (ctx) => {
            if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
            ctx.answerCbQuery();

            const label = {
                trx:     "Hapus Semua Transaksi",
                saldo:   "Reset Semua Saldo User",
                ranking: "Reset Top Ranking",
                total:   "RESET TOTAL (Transaksi + Saldo)"
            }[tipe];

            await safeEditOrReply(ctx,
                `⚠️ <b>KONFIRMASI RESET</b>\n\n` +
                `Kamu yakin ingin melakukan:\n<b>${label}</b>?\n\n` +
                `Aksi ini <b>TIDAK BISA DIBATALKAN</b>.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: `✅ Ya, Lakukan Sekarang`, callback_data: `reset_do_${tipe}` }],
                            [{ text: "❌ Batal", callback_data: "menu_reset_db" }]
                        ]
                    }
                }
            );
        });
    }

    // ── Eksekusi reset ──
    bot.action(/^reset_do_(.+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery("⏳ Memproses...");

        const tipe = ctx.match[1];
        const now  = moment().tz("Asia/Jakarta").format("YYYY-MM-DD_HH-mm-ss");
        const backupDir = "./database/backup";
        if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

        try {
            let pesanHasil = "";

            // ── RESET TRANSAKSI ──
            if (tipe === "trx" || tipe === "total") {
                // Backup dulu
                if (fs.existsSync(transactionsPath)) {
                    fs.copyFileSync(transactionsPath, `${backupDir}/transactions_${now}.json`);
                }
                await queueWrite(() => {
                    fs.writeFileSync(transactionsPath, JSON.stringify({}, null, 2));
                });
                pesanHasil += "✅ Semua transaksi dihapus.\n";
            }

            // ── RESET SALDO ──
            if (tipe === "saldo" || tipe === "total") {
                const db = loadDB();
                // Backup dulu
                fs.copyFileSync(userDBPath, `${backupDir}/user_${now}.json`);
                let jumlahDireset = 0;
                for (const uid of Object.keys(db.users)) {
                    if (db.users[uid].saldo > 0) {
                        db.users[uid].saldo = 0;
                        jumlahDireset++;
                    }
                }
                await saveDB(db);
                pesanHasil += `✅ Saldo ${jumlahDireset} user direset ke 0.\n`;
            }

            // ── RESET RANKING (hapus hanya transaksi tipe Deposit dari transactions.json) ──
            if (tipe === "ranking") {
                ensureTransactionsDB();
                const trxDb = safeReadJSON(transactionsPath, {});
                // Backup dulu
                fs.copyFileSync(transactionsPath, `${backupDir}/transactions_${now}.json`);

                let totalHapus = 0;
                for (const uid of Object.keys(trxDb)) {
                    const sebelum = trxDb[uid].length;
                    // Hapus hanya entri bertipe Deposit (untuk ranking)
                    trxDb[uid] = trxDb[uid].filter(t => t.service !== "Deposit");
                    totalHapus += sebelum - trxDb[uid].length;
                }
                await queueWrite(() => {
                    fs.writeFileSync(transactionsPath, JSON.stringify(trxDb, null, 2));
                });
                pesanHasil += `✅ ${totalHapus} data deposit dihapus dari ranking.\n`;
            }

            // Hapus juga file referral dan komisi kalau total reset
            if (tipe === "total") {
                const referralPath      = "./database/referral.json";
                const komisiBulananPath = "./database/komisi_bulanan.json";
                if (fs.existsSync(referralPath)) {
                    fs.copyFileSync(referralPath, `${backupDir}/referral_${now}.json`);
                    fs.writeFileSync(referralPath, JSON.stringify({}, null, 2));
                    pesanHasil += "✅ Data referral dihapus.\n";
                }
                if (fs.existsSync(komisiBulananPath)) {
                    fs.copyFileSync(komisiBulananPath, `${backupDir}/komisi_${now}.json`);
                    fs.writeFileSync(komisiBulananPath, JSON.stringify({}, null, 2));
                    pesanHasil += "✅ Data komisi dihapus.\n";
                }
            }

            pesanHasil += `\n📦 Backup disimpan di <code>database/backup/</code>`;

            await safeEditOrReply(ctx,
                `🗑️ <b>Reset Selesai!</b>\n\n${pesanHasil}\n` +
                `⏰ Waktu: ${moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")}`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "⬅ Menu Utama", callback_data: "back_menu" }]] }
                }
            );

        } catch (err) {
            console.error("RESET DB ERROR:", err.message);
            await safeEditOrReply(ctx,
                `❌ Error saat reset: ${err.message}`,
                { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "menu_reset_db" }]] } }
            );
        }
    });



    // ========================= ADMIN PANEL (OWNER ONLY) =========================

    const manualProductsPath = "./database/manual_products.json";

    function loadManualProducts() {
        return safeReadJSON(manualProductsPath, []);
    }
    function saveManualProducts(arr) {
        return queueWrite(() => fs.writeFileSync(manualProductsPath, JSON.stringify(arr, null, 2)));
    }

    // ── MENU ADMIN PANEL ──
    bot.action("admin_panel", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();

        const db          = loadDB();
        const trxDb       = safeReadJSON(transactionsPath, {});
        const totalUser   = Object.keys(db.users || {}).length;
        const totalSaldo  = Object.values(db.users || {}).reduce((s, u) => s + (u.saldo || 0), 0);
        const allTrx      = Object.values(trxDb).flat();
        const totalTrxSukses = allTrx.filter(t => t.status === "success" && t.service !== "Deposit").length;
        const totalTrxGagal  = allTrx.filter(t => ["expired", "canceled"].includes(t.status)).length;
        const totalDeposit   = allTrx.filter(t => t.service === "Deposit" && t.status === "success").reduce((s, t) => s + Number(t.price_sell || 0), 0);

        const text =
            `<blockquote>👑 <b>ADMIN PANEL || ${global.botName}</b></blockquote>\n\n` +
            `📊 <b>Statistik Bot</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `👥 Total User      : <b>${totalUser}</b>\n` +
            `💰 Total Saldo User: <b>Rp ${totalSaldo.toLocaleString("id-ID")}</b>\n` +
            `💵 Total Deposit   : <b>Rp ${totalDeposit.toLocaleString("id-ID")}</b>\n` +
            `✅ Transaksi Sukses: <b>${totalTrxSukses}</b>\n` +
            `❌ Transaksi Gagal : <b>${totalTrxGagal}</b>\n` +
            `🔧 Maintenance     : <b>${global.maintenanceEnabled ? "✅ AKTIF" : "❌ OFF"}</b> (${global.maintenanceStart}-${global.maintenanceEnd})\n` +
            `━━━━━━━━━━━━━━━━━━`;

        await safeEditOrReply(ctx, text, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "💸 Pantau Transaksi", callback_data: "admin_trx" }, { text: "👥 Pantau User", callback_data: "admin_users" }],
                    [{ text: "➕ Tambah Saldo User", callback_data: "admin_add_saldo" }, { text: "➖ Kurangi Saldo User", callback_data: "admin_minus_saldo" }],
                    [{ text: "🛍️ Kelola Produk Manual", callback_data: "admin_manual" }],
                    [{ text: "📢 Broadcast Pesan", callback_data: "admin_broadcast" }],
                    [{ text: `🔧 Maintenance: ${global.maintenanceEnabled ? "ON" : "OFF"}`, callback_data: "admin_toggle_maintenance" }],
                    [{ text: "⬅ Menu Utama", callback_data: "back_menu" }]
                ]
            }
        });
    });

    // ── PANTAU TRANSAKSI ──
    bot.action("admin_trx", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
            `📊 <b>Pantau Transaksi</b>\n\nPilih kategori:`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "✅ Sukses (Nokos)", callback_data: "admin_trx_sukses" }],
                        [{ text: "❌ Gagal/Expired", callback_data: "admin_trx_gagal" }],
                        [{ text: "💰 Deposit Sukses", callback_data: "admin_trx_deposit" }],
                        [{ text: "📋 Semua Transaksi (20 terbaru)", callback_data: "admin_trx_all" }],
                        [{ text: "⬅ Kembali", callback_data: "admin_panel" }]
                    ]
                }
            }
        );
    });

    for (const filterType of ["sukses", "gagal", "deposit", "all"]) {
        bot.action(`admin_trx_${filterType}`, async (ctx) => {
            if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
            ctx.answerCbQuery();

            const trxDb = safeReadJSON(transactionsPath, {});
            let allTrx  = [];
            for (const uid in trxDb) {
                for (const t of trxDb[uid]) {
                    allTrx.push({ ...t, user_id: uid });
                }
            }

            // Filter
            if (filterType === "sukses") allTrx = allTrx.filter(t => t.status === "success" && t.service !== "Deposit");
            else if (filterType === "gagal") allTrx = allTrx.filter(t => ["expired", "canceled"].includes(t.status));
            else if (filterType === "deposit") allTrx = allTrx.filter(t => t.service === "Deposit" && t.status === "success");

            allTrx.sort((a, b) => (b.created_ts || 0) - (a.created_ts || 0));
            const shown = allTrx.slice(0, 20);

            if (!shown.length) {
                return safeEditOrReply(ctx, `📭 Tidak ada transaksi untuk kategori ini.`,
                    { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "admin_trx" }]] } }
                );
            }

            let text = `<blockquote>📊 Transaksi (${filterType.toUpperCase()})</blockquote>\nMenampilkan ${shown.length} dari ${allTrx.length} transaksi\n\n`;
            for (let i = 0; i < shown.length; i++) {
                const t   = shown[i];
                const u   = getUser(t.user_id);
                const nm  = u.username ? `@${u.username}` : t.user_id;
                const ico = t.status === "success" ? "✅" : t.status === "canceled" ? "❌" : "⏰";
                text += `${i + 1}. ${ico} ${nm}\n`;
                text += `   ${t.service || "-"} | Rp ${Number(t.price_sell || t.price || 0).toLocaleString("id-ID")}\n`;
                text += `   ${t.finished_at || moment(t.created_ts).tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm") || "-"}\n\n`;
            }

            // Kirim sebagai file jika terlalu panjang
            if (text.length > 3500) {
                const tmpFile = `./database/trx_${filterType}_${Date.now()}.txt`;
                fs.writeFileSync(tmpFile, text);
                try { await ctx.replyWithDocument({ source: tmpFile }, { caption: `📊 ${filterType.toUpperCase()} — ${shown.length}/${allTrx.length} transaksi` }); }
                catch (e) { console.error(e); }
                try { fs.unlinkSync(tmpFile); } catch {}
                return;
            }

            await safeEditOrReply(ctx, text, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "admin_trx" }]] }
            });
        });
    }

    // ── PANTAU USER ──
    bot.action("admin_users", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();

        const db    = loadDB();
        const users = Object.values(db.users || {});
        users.sort((a, b) => (b.saldo || 0) - (a.saldo || 0));
        const shown = users.slice(0, 30);

        let text = `<blockquote>👥 <b>User Tertinggi (Top 30)</b></blockquote>\nTotal: ${users.length} user\n\n`;
        for (let i = 0; i < shown.length; i++) {
            const u  = shown[i];
            const nm = u.username ? `@${u.username}` : u.id;
            text += `${i + 1}. ${nm} ${u.vip ? "⭐" : ""}\n   ID: <code>${u.id}</code> | Saldo: <b>Rp ${(u.saldo || 0).toLocaleString("id-ID")}</b>\n\n`;
        }

        if (text.length > 3500) {
            const tmpFile = `./database/users_${Date.now()}.txt`;
            let txtFull = `Total: ${users.length} user\n\n`;
            users.forEach((u, i) => {
                txtFull += `${i + 1}. ID: ${u.id} | @${u.username || "?"} | Rp ${(u.saldo || 0).toLocaleString("id-ID")} | VIP: ${u.vip ? "YES" : "NO"} | ${u.registered}\n`;
            });
            fs.writeFileSync(tmpFile, txtFull);
            try { await ctx.replyWithDocument({ source: tmpFile }, { caption: `👥 Daftar Semua User (${users.length})` }); }
            catch (e) { console.error(e); }
            try { fs.unlinkSync(tmpFile); } catch {}
            return;
        }

        await safeEditOrReply(ctx, text, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "admin_panel" }]] }
        });
    });

    // ── TAMBAH SALDO USER ──
    bot.action("admin_add_saldo", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        setState(ctx.from.id, "admin_input_add_saldo");
        await safeEditOrReply(ctx,
            `➕ <b>Tambah Saldo User</b>\n\nKirim format:\n<code>USER_ID NOMINAL</code>\n\nContoh:\n<code>8506098180 10000</code>\n\nNominal akan DITAMBAHKAN ke saldo user.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "❌ Batal", callback_data: "admin_panel" }]] } }
        );
    });

    bot.action("admin_minus_saldo", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        setState(ctx.from.id, "admin_input_minus_saldo");
        await safeEditOrReply(ctx,
            `➖ <b>Kurangi Saldo User</b>\n\nKirim format:\n<code>USER_ID NOMINAL</code>\n\nContoh:\n<code>8506098180 5000</code>\n\nNominal akan DIKURANGI dari saldo user.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "❌ Batal", callback_data: "admin_panel" }]] } }
        );
    });

    // ── TOGGLE MAINTENANCE ──
    bot.action("admin_toggle_maintenance", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        global.maintenanceEnabled = !global.maintenanceEnabled;

        // Simpan ke file supaya persist
        const cfgPath = "./database/runtime_config.json";
        const cfg     = safeReadJSON(cfgPath, {});
        cfg.maintenanceEnabled = global.maintenanceEnabled;
        fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));

        await ctx.answerCbQuery(`Maintenance jadi: ${global.maintenanceEnabled ? "AKTIF" : "OFF"}`);
        // Refresh admin panel
        return ctx.telegram.sendMessage(ctx.from.id, `🔧 Maintenance auto sekarang: <b>${global.maintenanceEnabled ? "✅ AKTIF" : "❌ OFF"}</b>\n\nJadwal: ${global.maintenanceStart} - ${global.maintenanceEnd} WIB`, { parse_mode: "HTML" });
    });

    // ========================= BROADCAST PANEL (OWNER) =========================

    bot.action("admin_broadcast", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();

        const db = loadDB();
        const totalUser = Object.keys(db.users || {}).length;

        await safeEditOrReply(ctx,
            `<blockquote>📢 <b>BROADCAST PESAN</b> 📢</blockquote>\n\n` +
            `📣 <b>Broadcast ke Semua Users</b>\n\n` +
            `Pilih tipe broadcast:\n\n` +
            `• <b>Broadcast Biasa</b> - Forward pesan ke semua user\n` +
            `• <b>Broadcast + PIN</b> - Forward + Pin pesan (auto unpin 7 detik)\n\n` +
            `Cara pakai:\n` +
            `1. Reply pesan yang ingin dibroadcast\n` +
            `2. Gunakan command:\n` +
            `   /bc - Broadcast biasa\n` +
            `   /bcsm - Broadcast + PIN\n\n` +
            `─────────────────────\n` +
            `👥 Total user terdaftar: <b>${totalUser} user</b>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        // Tombol shortcut: owner pencet tombol ini lalu reply pesan target
                        [{ text: "📢 /bc — Broadcast Biasa", callback_data: "bc_guide" }],
                        [{ text: "📌 /bcsm — Broadcast + PIN", callback_data: "bcsm_guide" }],
                        [{ text: "« Kembali ke Owner Menu", callback_data: "admin_panel" }]
                    ]
                }
            }
        );
    });

    // Tombol petunjuk /bc
    bot.action("bc_guide", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
            `📢 <b>Cara Broadcast Biasa (/bc)</b>\n\n` +
            `1. Kirim atau cari pesan yang ingin kamu broadcast\n` +
            `2. <b>Reply</b> pesan tersebut\n` +
            `3. Ketik <code>/bc</code> lalu kirim\n\n` +
            `Bot akan mem-forward pesan itu ke semua user secara otomatis.\n\n` +
            `⚠️ Pesan apapun bisa dibroadcast: teks, foto, video, stiker, dll.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[{ text: "« Kembali", callback_data: "admin_broadcast" }]]
                }
            }
        );
    });

    // Tombol petunjuk /bcsm
    bot.action("bcsm_guide", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
            `📌 <b>Cara Broadcast + PIN (/bcsm)</b>\n\n` +
            `1. Kirim atau cari pesan yang ingin kamu broadcast\n` +
            `2. <b>Reply</b> pesan tersebut\n` +
            `3. Ketik <code>/bcsm</code> lalu kirim\n\n` +
            `Bot akan mem-forward pesan ke semua user <b>dan langsung menyematkan (PIN)</b> pesan tersebut di chat masing-masing user.\n\n` +
            `⏱️ Pesan otomatis di-unpin setelah <b>7 detik</b>.\n\n` +
            `⚠️ Bot perlu permission "Pin Messages" di private chat user untuk bisa pin.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[{ text: "« Kembali", callback_data: "admin_broadcast" }]]
                }
            }
        );
    });

    // ========================= PRODUK MANUAL (OWNER) =========================

    bot.action("admin_manual", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        const products = loadManualProducts();

        let text = `<blockquote>🛍️ <b>KELOLA PRODUK MANUAL</b></blockquote>\nTotal produk: <b>${products.length}</b>\n\n`;
        if (products.length > 0) {
            text += `<b>Daftar Produk:</b>\n`;
            products.slice(0, 15).forEach((p, i) => {
                text += `${i + 1}. <b>${p.name}</b>\n   💰 Rp ${Number(p.price).toLocaleString("id-ID")} | 📦 Stok: ${p.stock}\n`;
            });
            if (products.length > 15) text += `\n<i>...dan ${products.length - 15} produk lainnya</i>`;
        }

        await safeEditOrReply(ctx, text, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "➕ Tambah Produk", callback_data: "admin_manual_add" }],
                    [{ text: "✏️ Edit Produk", callback_data: "admin_manual_edit" }, { text: "🗑️ Hapus Produk", callback_data: "admin_manual_del" }],
                    [{ text: "⬅ Admin Panel", callback_data: "admin_panel" }]
                ]
            }
        });
    });

    bot.action("admin_manual_add", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        setState(ctx.from.id, "admin_manual_add_input");
        await safeEditOrReply(ctx,
            `➕ <b>Tambah Produk Manual</b>\n\n` +
            `Kirim dalam format (pisah dengan <code>|</code>):\n` +
            `<code>NAMA | HARGA | STOK | DESKRIPSI</code>\n\n` +
            `Contoh:\n` +
            `<code>Netflix 1 Bulan | 25000 | 10 | Akun Netflix Premium share 1 bulan</code>\n\n` +
            `Atau tanpa deskripsi:\n` +
            `<code>Spotify Premium | 15000 | 5</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "❌ Batal", callback_data: "admin_manual" }]] } }
        );
    });

    bot.action("admin_manual_edit", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        const products = loadManualProducts();
        if (!products.length) {
            return safeEditOrReply(ctx, "📭 Belum ada produk. Tambah dulu.",
                { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "admin_manual" }]] } }
            );
        }
        const rows = products.slice(0, 20).map((p, i) => ([{
            text: `${i + 1}. ${p.name} (Rp ${Number(p.price).toLocaleString("id-ID")})`,
            callback_data: `admin_edit_${p.id}`
        }]));
        rows.push([{ text: "⬅ Kembali", callback_data: "admin_manual" }]);
        await safeEditOrReply(ctx, `✏️ <b>Pilih Produk untuk Edit</b>`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    });

    bot.action(/^admin_edit_(.+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        const pid = ctx.match[1];
        const products = loadManualProducts();
        const p = products.find(x => x.id === pid);
        if (!p) return ctx.reply("❌ Produk tidak ditemukan.");

        setState(ctx.from.id, `admin_manual_edit_input_${pid}`);
        await safeEditOrReply(ctx,
            `✏️ <b>Edit Produk: ${p.name}</b>\n\n` +
            `📝 Saat ini:\n` +
            `Nama : ${p.name}\n` +
            `Harga: Rp ${Number(p.price).toLocaleString("id-ID")}\n` +
            `Stok : ${p.stock}\n` +
            `Desk : ${p.desc || "-"}\n\n` +
            `Kirim format baru:\n<code>NAMA | HARGA | STOK | DESKRIPSI</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "❌ Batal", callback_data: "admin_manual" }]] } }
        );
    });

    bot.action("admin_manual_del", async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        ctx.answerCbQuery();
        const products = loadManualProducts();
        if (!products.length) {
            return safeEditOrReply(ctx, "📭 Belum ada produk.",
                { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "admin_manual" }]] } }
            );
        }
        const rows = products.slice(0, 20).map((p, i) => ([{
            text: `${i + 1}. ${p.name}`,
            callback_data: `admin_del_${p.id}`
        }]));
        rows.push([{ text: "⬅ Kembali", callback_data: "admin_manual" }]);
        await safeEditOrReply(ctx, `🗑️ <b>Pilih Produk untuk Hapus</b>`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    });

    bot.action(/^admin_del_(.+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        const pid = ctx.match[1];
        let products = loadManualProducts();
        const p = products.find(x => x.id === pid);
        if (!p) return ctx.answerCbQuery("Produk tidak ada.");
        products = products.filter(x => x.id !== pid);
        await saveManualProducts(products);
        await ctx.answerCbQuery(`✅ Produk "${p.name}" dihapus`);
        // Refresh list
        return ctx.telegram.sendMessage(ctx.from.id, `🗑️ Produk <b>${p.name}</b> berhasil dihapus.`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "⬅ Admin Panel", callback_data: "admin_panel" }]] }
        });
    });

    // ========================= MENU PRODUK MANUAL (USER) =========================

    bot.action("menu_manual", async (ctx) => {
        ctx.answerCbQuery();
        const products = loadManualProducts().filter(p => p.stock > 0);

        if (!products.length) {
            return safeEditOrReply(ctx,
                `🛍️ <b>PRODUK MANUAL</b>\n\nBelum ada produk yang tersedia saat ini.\nCek lagi nanti ya!`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
            );
        }

        let text = `<blockquote>🛍️ <b>PRODUK MANUAL</b></blockquote>\n\nDaftar produk yang tersedia:\n\n`;
        const rows = [];
        products.slice(0, 20).forEach((p, i) => {
            text += `<b>${i + 1}. ${p.name}</b>\n💰 Rp ${Number(p.price).toLocaleString("id-ID")} | 📦 Stok: ${p.stock}\n`;
            if (p.desc) text += `📝 ${p.desc}\n`;
            text += `\n`;
            rows.push([{ text: `${i + 1}. ${p.name} (Rp ${Number(p.price).toLocaleString("id-ID")})`, callback_data: `manual_buy_${p.id}` }]);
        });
        rows.push([{ text: "⬅ Menu Utama", callback_data: "back_menu" }]);

        await safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    });

    bot.action(/^manual_buy_(.+)$/, async (ctx) => {
        ctx.answerCbQuery();
        const pid = ctx.match[1];
        if (isRateLimited(ctx.from.id, 2000)) return ctx.answerCbQuery("⏳ Terlalu cepat.", { show_alert: true });

        const products = loadManualProducts();
        const p = products.find(x => x.id === pid);
        if (!p) return ctx.reply("❌ Produk tidak ditemukan.");
        if (p.stock <= 0) return ctx.reply("❌ Produk sudah habis.");

        const user = getUser(ctx.from.id, ctx.from.username);
        if (user.saldo < p.price) {
            return safeEditOrReply(ctx,
                `❌ <b>Saldo Tidak Cukup</b>\n\nHarga produk: Rp ${Number(p.price).toLocaleString("id-ID")}\nSaldo kamu: Rp ${user.saldo.toLocaleString("id-ID")}\n\nDeposit dulu yuk!`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "💰 Deposit", callback_data: "menu_deposit" }, { text: "⬅ Kembali", callback_data: "menu_manual" }]] } }
            );
        }

        await safeEditOrReply(ctx,
            `🛒 <b>KONFIRMASI ORDER PRODUK MANUAL</b>\n\n` +
            `📦 Produk : <b>${p.name}</b>\n` +
            `💰 Harga  : <b>Rp ${Number(p.price).toLocaleString("id-ID")}</b>\n` +
            `📦 Stok   : ${p.stock}\n` +
            (p.desc ? `📝 Desk   : ${p.desc}\n` : "") +
            `\n💳 Saldo kamu: Rp ${user.saldo.toLocaleString("id-ID")}\n` +
            `💳 Sisa nanti: Rp ${(user.saldo - p.price).toLocaleString("id-ID")}\n\n` +
            `⚠️ Setelah konfirmasi, owner akan dihubungi untuk mengirim produk secara manual.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "✅ Konfirmasi Order", callback_data: `manual_confirm_${pid}` }],
                        [{ text: "❌ Batal", callback_data: "menu_manual" }]
                    ]
                }
            }
        );
    });

    bot.action(/^manual_confirm_(.+)$/, async (ctx) => {
        ctx.answerCbQuery();
        const pid = ctx.match[1];
        const userId = ctx.from.id;
        if (isRateLimited(userId, 3000)) return ctx.answerCbQuery("⏳ Terlalu cepat.", { show_alert: true });

        // Re-validasi
        const products = loadManualProducts();
        const pIdx = products.findIndex(x => x.id === pid);
        if (pIdx === -1) return ctx.reply("❌ Produk tidak ditemukan.");
        const p = products[pIdx];
        if (p.stock <= 0) return ctx.reply("❌ Produk habis.");

        // Fresh-read saldo
        const db   = loadDB();
        const uid  = String(userId);
        const u    = db.users?.[uid];
        if (!u || u.saldo < p.price) return ctx.reply("❌ Saldo tidak cukup.");

        // Potong saldo + kurangi stok
        u.saldo -= p.price;
        products[pIdx].stock -= 1;
        await saveDB(db);
        await saveManualProducts(products);

        const orderId = `MAN-${Date.now()}-${userId}`;
        await saveFinalTransaction(
            { user_id: userId, service: `Manual: ${p.name}`, price: p.price, created_ts: Date.now() },
            { status: "success", finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"), price_sell: p.price, manual_order_id: orderId }
        );

        // Notif user
        await safeEditOrReply(ctx,
            `✅ <b>Order Berhasil!</b>\n\n` +
            `📦 Produk : <b>${p.name}</b>\n` +
            `💰 Harga  : Rp ${Number(p.price).toLocaleString("id-ID")}\n` +
            `🆔 Order  : <code>${orderId}</code>\n\n` +
            `⏳ Owner akan menghubungi kamu untuk pengiriman produk.\nMohon tunggu, terima kasih!`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] } }
        );

        // Notif owner
        const userObj = getUser(userId);
        const notif =
            `🛍️ <b>ORDER PRODUK MANUAL BARU!</b>\n\n` +
            `👤 User  : @${userObj.username || "unknown"}\n` +
            `🆔 ID    : <code>${userId}</code>\n` +
            `📦 Produk: <b>${p.name}</b>\n` +
            `💰 Harga : Rp ${Number(p.price).toLocaleString("id-ID")}\n` +
            `🆔 Order : <code>${orderId}</code>\n\n` +
            `⚠️ Segera kirim produk ke user secara manual!`;
        for (const oid of global.ownerID) {
            try { await bot.telegram.sendMessage(Number(oid), notif, { parse_mode: "HTML" }); } catch {}
        }
        const waktuManual = moment().tz("Asia/Jakarta");
        const notifManualGrup =
            `✅ <b>ORDER SUKSES SELESAI DITERIMA</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `📋 <b>ORDER INFORMATION</b>\n` +
            `• Nama User: ${userObj.username || "User"}\n` +
            `• Nominal: <b>Rp ${Number(p.price).toLocaleString("id-ID")}</b>\n` +
            `• Tanggal: ${waktuManual.format("MMM DD, YYYY")}\n` +
            `• Waktu: ${waktuManual.format("HH.mm.ss")}\n` +
            `• Layanan: ${p.name} (Manual)\n\n` +
            `<b>INFORMATION</b>\n` +
            `• Status: ✅ Sukses Telah Diterima\n` +
            `• Catatan: aman dan sudah terverifikasi`;

        // Log ke grup pembelian
        if (global.grupNotifPembelian) {
            await autoUpSend(bot, global.grupNotifPembelian, notifManualGrup, global.botUsername);
        }
        // Auto Up ke channel transaksi khusus
        // NOTE: autoUpChannel sengaja TIDAK digunakan — cukup 1x via grupNotifPembelian
        if (false && global.autoUpChannel) {
            const botAdminAutoUp = await isBotAdmin(bot, global.autoUpChannel);
            if (botAdminAutoUp) {
                await autoUpSend(bot, `@${global.autoUpChannel}`, notifManualGrup, global.botUsername);
            } else {
                console.warn(`[AUTO UP MANUAL] Bot bukan admin di @${global.autoUpChannel}`);
            }
        }
    });

    bot.action("menu_referral", async (ctx) => {
        ctx.answerCbQuery();
        const userId = String(ctx.from.id);

        // Ambil username bot dari ctx
        let botUsername = global.botUsername || global.ownerUsername || "bot";
        try {
            const botInfo = await bot.telegram.getMe();
            if (botInfo?.username) botUsername = botInfo.username;
        } catch (e) { console.warn("getMe failed:", e.message); }

        const { diundang, totalKomisiSemua, komisiBulanIni, referredBy } = getStatReferral(userId);
        const linkReferral = getReferralLink(botUsername, userId);
        const bulanIni = moment().tz("Asia/Jakarta").format("MMMM YYYY");

        let text =
            `<blockquote>🤝 <b>PROGRAM UNDANG TEMAN</b></blockquote>\n\n` +
            `Dapatkan komisi <b>${global.referralPersen || 0}%</b> setiap kali teman yang kamu undang melakukan deposit!\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `📊 <b>Statistik Kamu</b>\n` +
            `👥 Teman diundang  : <b>${diundang.length} orang</b>\n` +
            `💰 Komisi bulan ini: <b>Rp ${komisiBulanIni.toLocaleString("id-ID")}</b>\n` +
            `💎 Total komisi    : <b>Rp ${totalKomisiSemua.toLocaleString("id-ID")}</b>\n`;

        if (referredBy) {
            const mainDb = loadDB();
            const refUser = mainDb.users[referredBy];
            const refNama = refUser?.username ? `@${refUser.username}` : `ID ${referredBy}`;
            text += `\n🔗 Kamu diundang oleh: <b>${refNama}</b>\n`;
        }

        text +=
            `\n━━━━━━━━━━━━━━━━━━━━\n` +
            `🔗 <b>Link Referralmu</b>\n` +
            `<code>${linkReferral}</code>\n\n` +
            `📋 <i>Tap link di atas untuk menyalin, lalu bagikan ke teman!</i>\n\n` +
            `⏱️ Komisi dihitung setiap deposit dalam bulan <b>${bulanIni}</b>.`;

        const rows = [
            [{ text: "📋 Daftar Teman Diundang", callback_data: "referral_list" }],
            [{ text: "⬅ Menu Utama", callback_data: "back_menu" }]
        ];

        await safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    });

    bot.action("referral_list", async (ctx) => {
        ctx.answerCbQuery();
        const userId = String(ctx.from.id);
        const { diundang } = getStatReferral(userId);

        if (!diundang.length) {
            return safeEditOrReply(ctx,
                `📋 <b>Daftar Teman Diundang</b>\n\nKamu belum mengundang siapapun.\n\nBagikan link referralmu dan mulai dapat komisi!`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "menu_referral" }]] } }
            );
        }

        const mainDb = loadDB();
        let text = `📋 <b>Daftar Teman Diundang (${diundang.length} orang)</b>\n\n`;

        diundang.slice(0, 20).forEach((item, i) => {
            const u = mainDb.users[item.uid];
            const nama = u?.username ? `@${u.username}` : `ID ${item.uid}`;
            text += `${i + 1}. ${nama}\n`;
            text += `   Bergabung: ${item.joinedAt || "-"}\n`;
            text += `   Komisi dihasilkan: Rp ${item.totalKomisi.toLocaleString("id-ID")}\n\n`;
        });

        if (diundang.length > 20) {
            text += `<i>...dan ${diundang.length - 20} orang lainnya.</i>`;
        }

        // FIX: tambah await agar safeEditOrReply tidak di-discard
        // Tanpa await, Promise ini berjalan di background dan tidak ada jaminan pesan terkirim
        await safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "menu_referral" }]] } });
    });

    // ========================= CHECK-IN HARIAN =========================

    const checkinDir = "./database/checkin";
    if (!fs.existsSync(checkinDir)) fs.mkdirSync(checkinDir, { recursive: true });

    bot.action("menu_checkin", async (ctx) => {
        ctx.answerCbQuery();
        if (!ctx.from) return;
        const userId  = String(ctx.from.id);
        const hariIni = moment().tz("Asia/Jakarta").format("YYYY-MM-DD");
        const file    = `${checkinDir}/${userId}.json`;

        const data    = safeReadJSON(file, { lastCheckin: null, streak: 0, totalCheckin: 0 });
        const sudah   = data.lastCheckin === hariIni;

        // Hitung hadiah hari ini berdasarkan streak
        const streak    = sudah ? data.streak : (data.lastCheckin === moment().tz("Asia/Jakarta").subtract(1, "day").format("YYYY-MM-DD") ? data.streak + 1 : 1);
        const hadiahHariIni = hitungHadiahCheckin(streak);

        const pesan =
            `<blockquote>🎁 <b>CHECK-IN HARIAN</b></blockquote>\n\n` +
            `🔥 Streak saat ini: <b>${data.streak} hari</b>\n` +
            `📅 Total check-in : <b>${data.totalCheckin} kali</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Jadwal Hadiah:</b>\n` +
            `Hari 1   → Rp ${global.checkinHari1.toLocaleString("id-ID")}\n` +
            `Hari 2   → Rp ${global.checkinHari2.toLocaleString("id-ID")}\n` +
            `Hari 3   → Rp ${global.checkinHari3.toLocaleString("id-ID")}\n` +
            `Hari 4   → Rp ${global.checkinHari4.toLocaleString("id-ID")}\n` +
            `Hari 5   → Rp ${global.checkinHari5.toLocaleString("id-ID")}\n` +
            `Hari 6   → Rp ${global.checkinHari6.toLocaleString("id-ID")}\n` +
            `Hari 7+  → Rp ${global.checkinHari7plus.toLocaleString("id-ID")} 🎉\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            (sudah
                ? `✅ Kamu sudah check-in hari ini!\nKembali besok untuk melanjutkan streak.`
                : `🎁 Hadiah hari ini (streak ${streak}): <b>Rp ${hadiahHariIni.toLocaleString("id-ID")}</b>\n\nKlik tombol di bawah untuk check-in!`
            );

        await safeEditOrReply(ctx, pesan, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    sudah
                        ? [{ text: "✅ Sudah Check-in Hari Ini", callback_data: "ignore" }]
                        : [{ text: `🎁 Check-in Sekarang (+Rp ${hadiahHariIni.toLocaleString("id-ID")})`, callback_data: "do_checkin" }],
                    [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                ]
            }
        });
    });

    bot.action("do_checkin", async (ctx) => {
        ctx.answerCbQuery();
        if (!ctx.from) return;
        if (isRateLimited(ctx.from.id, 3000)) return ctx.answerCbQuery("⏳ Tunggu sebentar.", { show_alert: true });
        const userId  = String(ctx.from.id);
        const hariIni = moment().tz("Asia/Jakarta").format("YYYY-MM-DD");
        const file    = `${checkinDir}/${userId}.json`;

        const data = safeReadJSON(file, { lastCheckin: null, streak: 0, totalCheckin: 0 });

        // Cek sudah check-in hari ini
        if (data.lastCheckin === hariIni) {
            return safeEditOrReply(ctx,
                "✅ Kamu sudah check-in hari ini!\nKembali besok untuk melanjutkan streak.",
                { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
            );
        }

        // Hitung streak baru
        const kemarin   = moment().tz("Asia/Jakarta").subtract(1, "day").format("YYYY-MM-DD");
        const newStreak = data.lastCheckin === kemarin ? data.streak + 1 : 1;
        const hadiah    = hitungHadiahCheckin(newStreak);

        // Update data check-in
        const newData = {
            lastCheckin : hariIni,
            streak      : newStreak,
            totalCheckin: (data.totalCheckin || 0) + 1
        };
        fs.writeFileSync(file, JSON.stringify(newData, null, 2));

        // Tambah saldo
        const db = loadDB();
        if (!db.users[userId]) getUser(userId);
        db.users[userId].saldo += hadiah;
        await saveDB(db);

        await saveFinalTransaction(
            { user_id: userId, service: "Check-in Harian", price: 0, created_ts: Date.now() },
            { status: "success", finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"), price_sell: 0, hadiah }
        );

        const pesan =
            `🎉 <b>Check-in Berhasil!</b>\n\n` +
            `🔥 Streak: <b>${newStreak} hari</b>\n` +
            `💰 Hadiah: <b>+Rp ${hadiah.toLocaleString("id-ID")}</b>\n` +
            `💳 Saldo sekarang: <b>Rp ${db.users[userId].saldo.toLocaleString("id-ID")}</b>\n\n` +
            (newStreak === 7
                ? `🏆 Selamat! Kamu mencapai streak 7 hari! Bonus maksimal aktif!\n\n`
                : newStreak < 7
                    ? `📅 Lanjutkan ${7 - newStreak} hari lagi untuk streak penuh!\n\n`
                    : `🔥 Streak ${newStreak} hari! Terus pertahankan!\n\n`
            ) +
            `Kembali besok untuk check-in lagi!`;

        await safeEditOrReply(ctx, pesan, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] }
        });
    });

    function hitungHadiahCheckin(streak) {
        if (streak <= 1) return global.checkinHari1 || 100;
        if (streak === 2) return global.checkinHari2 || 150;
        if (streak === 3) return global.checkinHari3 || 200;
        if (streak === 4) return global.checkinHari4 || 250;
        if (streak === 5) return global.checkinHari5 || 300;
        if (streak === 6) return global.checkinHari6 || 400;
        return global.checkinHari7plus || 500;
    }

    // ========================= INFO & SYARAT KETENTUAN =========================

    bot.action("menu_info", async (ctx) => {
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
            `<blockquote>ℹ️ <b>INFO & SYARAT KETENTUAN</b></blockquote>\n\nPilih kategori:`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "📋 Syarat & Ketentuan Nokos", callback_data: "info_nokos" }],
                        [{ text: "💰 Cara Deposit", callback_data: "info_deposit" }],
                        [{ text: "📞 Hubungi Owner", url: `https://t.me/${global.ownerUsername}` }],
                        [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                    ]
                }
            }
        );
    });

    bot.action("info_nokos", async (ctx) => {
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
`─── 📋 SYARAT & KETENTUAN PEMBELIAN NOKOS 📋 ───

⛔️ Harap Baca Dengan Teliti!
Layanan ini menyediakan Nomor Kosong (Nokos) untuk keperluan verifikasi OTP berbagai aplikasi.

1. 🌟 NOMOR SEKALI PAKAI
Nomor yang diberikan adalah nomor virtual sekali pakai untuk menerima kode OTP. Setelah OTP diterima atau waktu habis, nomor tidak dapat digunakan kembali.

2. 🛡 GARANSI
Garansi berlaku HANYA jika:
• Nomor tidak menerima OTP dalam batas waktu.
(Saldo otomatis dikembalikan jika OTP gagal masuk dan dibatalkan).

3. ⏰ BATAS WAKTU
Tunggu OTP maksimal <b>20 menit</b>. Setelah <b>5 menit</b> pertama, tombol batalkan akan tersedia jika OTP belum masuk.
Jika OTP tidak masuk dalam 8 menit, saldo dikembalikan otomatis.

4. 💰 HARGA
Harga sudah termasuk biaya layanan dan dapat berubah sewaktu-waktu sesuai ketersediaan.`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "menu_info" }]] }
            }
        );
    });


    bot.action("info_deposit", async (ctx) => {
        ctx.answerCbQuery();
        await safeEditOrReply(ctx,
`💰 <b>CARA DEPOSIT</b>

1. Klik menu <b>💰 Deposit</b>
2. Pilih nominal (minimal Rp 2.000)
3. Scan QRIS menggunakan e-wallet atau m-banking
4. Transfer <b>SAMA PERSIS</b> dengan nominal yang tertera (termasuk kode unik 3 digit)
5. Tunggu 1-3 menit — saldo masuk otomatis!

⚠️ <b>Penting:</b>
• Transfer harus SAMA PERSIS dengan total yang tertera
• Kode unik berbeda tiap transaksi untuk identifikasi otomatis
• Jika lebih dari 15 menit belum masuk, hubungi owner

📞 Hubungi owner jika ada kendala.`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "menu_info" }]] }
            }
        );
    });

    // ================= RIWAYAT =================
    bot.action("menu_history", async (ctx) => {
        ctx.answerCbQuery();
        ensureTransactionsDB();
        const db = safeReadJSON(transactionsPath,{});
        const uid = String(ctx.from.id);

        // Filter: tampilkan hanya yang SUKSES dan DEPOSIT — yang dibatal/expired disembunyikan
        const allTrx  = (db[uid] || []).slice().reverse();
        const trxList = allTrx
            .filter(t => t.status === "success" || (t.service === "Deposit" && t.status === "success"))
            .slice(0, 10);

        if (!trxList.length) return safeEditOrReply(ctx,
            "📭 Belum ada transaksi sukses.",
            { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
        );

        const statusIcon = (s) => s === "success" ? "✅" : s === "canceled" ? "❌" : "⏰";

        let text = "📜 <b>Riwayat Transaksi Sukses</b>\n\n";
        trxList.forEach((trx, i) => {
            const nama = cleanProductName(trx.service || "N/A");
            const harga = Number(trx.price_sell || trx.price || 0).toLocaleString("id-ID");
            text += `${statusIcon(trx.status)} <b>${nama}</b>\n`;
            text += `   💰 Rp ${harga} | ${trx.finished_at?.slice(0,16) || "-"}\n\n`;
        });

        return safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } });
    });

    // ================= TOP DEPOSITS =================
    bot.action("top_deposits", async (ctx) => {
        ctx.answerCbQuery();
        ensureTransactionsDB();
        const db = safeReadJSON(transactionsPath,{});
        const totals = {};
        for (const uid in db) {
            totals[uid] = db[uid].filter(t => t.service === "Deposit" && t.status === "success").reduce((s, t) => s + Number(t.price_sell || t.price || 0), 0);
        }
        const top = Object.entries(totals).filter(([, v]) => v > 0).sort(([, a], [, b]) => b - a).slice(0, 10);
        if (!top.length) return safeEditOrReply(ctx, "Belum ada data deposit.", { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } });

        let text = "🏆 <b>Top 10 Depositor</b>\n\n";
        top.forEach(([uid, total], i) => {
            const u = getUser(uid);
            text += `${i + 1}. @${u.username || uid} — <b>Rp ${total.toLocaleString("id-ID")}</b>\n`;
        });
        return safeEditOrReply(ctx, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } });
    });

    // ========================= DEPOSIT =========================

    bot.action("menu_deposit", async (ctx) => {
        const userId = ctx.from.id;
        if (fs.existsSync(`${depositDir}/${userId}.json`)) {
            return safeEditOrReply(ctx, "⚠️ Kamu masih punya deposit pending.", {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "deposit_cancel" }]] }
            });
        }
        await safeEditOrReply(ctx,
            `<blockquote><b>💰 DEPOSIT SALDO</b></blockquote>\n` +
            `Pilih nominal atau masukkan jumlah sendiri.\nMinimal <b>Rp 2.000</b>\n\n` +
            `⚡ Deposit otomatis terdeteksi via QRIS dengan <b>kode unik</b>.\n` +
            `Bayar sesuai nominal yang tertera (termasuk kode unik).\n` +
            `Saldo masuk otomatis setelah pembayaran terdeteksi.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "Rp 2.000", callback_data: "deposit_amount_2000" }, { text: "Rp 5.000", callback_data: "deposit_amount_5000" }],
                        [{ text: "Rp 10.000", callback_data: "deposit_amount_10000" }, { text: "Rp 20.000", callback_data: "deposit_amount_20000" }],
                        [{ text: "Rp 50.000", callback_data: "deposit_amount_50000" }, { text: "Rp 100.000", callback_data: "deposit_amount_100000" }],
                        [{ text: "💰 Nominal Lain", callback_data: "deposit_custom_amount" }],
                        [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                    ]
                }
            }
        );
        ctx.answerCbQuery();
    });

    bot.action(/^deposit_amount_(\d+)$/, async (ctx) => {
        const amount = Number(ctx.match[1]);
        if (isNaN(amount) || amount < 2000) return ctx.answerCbQuery("❌ Nominal tidak valid. Minimal Rp 2.000.", { show_alert: true });
        if (isRateLimited(ctx.from.id, 3000)) return ctx.answerCbQuery("⏳ Tunggu sebentar.", { show_alert: true });
        // Cek ulang deposit pending sebelum buat baru
        if (fs.existsSync(`${depositDir}/${ctx.from.id}.json`)) {
            return ctx.answerCbQuery("⚠️ Masih ada deposit pending!", { show_alert: true });
        }
        try { await ctx.deleteMessage(); } catch {}
        return createDeposit(bot, ctx, ctx.from.id, amount);
    });

    bot.action("deposit_custom_amount", async (ctx) => {
        setState(ctx.from.id, "waiting_amount");
        await safeEditOrReply(ctx,
            `<blockquote><b>💰 DEPOSIT</b></blockquote>\nMasukkan nominal deposit (minimal Rp 2.000):`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
        );
        ctx.answerCbQuery();
    });

    bot.action("deposit_cancel", async (ctx) => { await cancelDeposit(ctx, ctx.from.id); });


    // ========================= DEPOSIT KE OWNER (Manual QRIS) =========================

    // Langkah 1: Tampilkan foto QRIS owner + instruksi
    bot.action("menu_deposit_owner", async (ctx) => {
        ctx.answerCbQuery();
        const userId = ctx.from.id;
        const minimal = global.depositOwnerMinimal || 5000;
        const qrisUrl = global.qrisOwnerImage || "";

        const caption =
            `🏧 <b>DEPOSIT KE OWNER</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `Scan QRIS di atas untuk melakukan pembayaran.\n\n` +
            `📌 <b>Cara Deposit:</b>\n` +
            `1️⃣ Scan QRIS & bayar sesuai nominal yang kamu inginkan\n` +
            `2️⃣ Screenshot bukti pembayaran\n` +
            `3️⃣ Kirim foto bukti ke bot ini dengan caption berupa <b>nominal deposit</b>\n\n` +
            `📝 <b>Contoh caption:</b>\n` +
            `<code>10000</code>  ← tulis angka saja tanpa titik/koma\n\n` +
            `⚠️ Minimal deposit: <b>Rp ${minimal.toLocaleString("id-ID")}</b>\n` +
            `⏳ Saldo akan ditambah setelah owner konfirmasi.\n\n` +
            `<i>Kirim foto bukti pembayaran sekarang 👇</i>`;

        setState(userId, "waiting_deposit_owner_proof");

        try {
            await ctx.deleteMessage();
        } catch {}

        if (qrisUrl) {
            try {
                await ctx.replyWithPhoto(qrisUrl, {
                    caption,
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "❌ Batal", callback_data: "cancel_deposit_owner" }]
                        ]
                    }
                });
                return;
            } catch (e) {
                console.warn("[DEPOSIT OWNER] Gagal kirim foto QRIS:", e.message);
            }
        }

        // Fallback: kirim teks saja kalau foto gagal
        await ctx.reply(caption, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "❌ Batal", callback_data: "cancel_deposit_owner" }]
                ]
            }
        });
    });

    // Batal deposit ke owner
    bot.action("cancel_deposit_owner", async (ctx) => {
        ctx.answerCbQuery();
        clearState(ctx.from.id);
        try { await ctx.deleteMessage(); } catch {}
        return kirimMenuUtama(bot, ctx);
    });

    // Konfirmasi oleh owner: tombol ACC deposit manual
    bot.action(/^acc_dep_owner_(\d+)_(\d+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) {
            return ctx.answerCbQuery("❌ Bukan owner!", { show_alert: true });
        }
        ctx.answerCbQuery();

        const targetUserId = ctx.match[1];
        const nominal      = Number(ctx.match[2]);

        const db = loadDB();
        const uid = String(targetUserId);

        if (!db.users[uid]) {
            db.users[uid] = {
                id: uid,
                username: "",
                registered: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"),
                saldo: 0,
                vip: false
            };
        }

        const saldoSebelum = db.users[uid].saldo || 0;
        db.users[uid].saldo = saldoSebelum + nominal;
        db.users[uid].points = (db.users[uid].points || 0) + 1;
        db.users[uid].depositCount = (db.users[uid].depositCount || 0) + 1;
        await saveDB(db);

        // Simpan transaksi
        await saveFinalTransaction(
            { user_id: uid, service: "Deposit Manual (Owner)", price: nominal, created_ts: Date.now() },
            { status: "success", finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"), price_sell: nominal }
        );

        const waktu = moment().tz("Asia/Jakarta");
        const u     = db.users[uid];

        // Edit pesan di chat owner → tambah tanda ACC
        try {
            await ctx.editMessageReplyMarkup({
                inline_keyboard: [
                    [{ text: `✅ SUDAH DI-ACC oleh @${ctx.from.username || "owner"} — ${waktu.format("HH:mm:ss")}`, callback_data: "noop_acc_done" }]
                ]
            });
        } catch {}

        // Notif ke user: deposit berhasil
        try {
            await bot.telegram.sendMessage(Number(targetUserId),
                `✅ <b>Deposit Berhasil!</b>\n\n` +
                `💰 Saldo bertambah: <b>+Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
                `💳 Saldo sekarang: <b>Rp ${db.users[uid].saldo.toLocaleString("id-ID")}</b>\n\n` +
                `🎉 Terima kasih sudah deposit ke owner!`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] }
                }
            );
        } catch (e) { console.warn("[DEPOSIT OWNER ACC] Notif user gagal:", e.message); }

        // Broadcast ke channel transaksi (sama seperti deposit auto)
        const logMsg =
            `💰 <b>DEPOSIT BERHASIL</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `📋 <b>TRANSACTION DETAILS</b>\n` +
            `• Nama User: ${u.username || uid}\n` +
            `• Jumlah Deposit: <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
            `• Pembayaran: QRIS Manual\n` +
            `• Points Earned: +1\n` +
            `• Tanggal: ${waktu.format("MMM DD, YYYY")}\n` +
            `• Waktu: ${waktu.format("HH.mm.ss")}\n\n` +
            `📊 <b>USER STATISTICS</b>\n` +
            `• User ID: ${uid}\n` +
            `• Saldo Total: <b>Rp ${db.users[uid].saldo.toLocaleString("id-ID")}</b>\n` +
            `• Status: ✅ Transaksi Sukses\n` +
            `• Sistem: Manual (Owner)\n\n` +
            `🎯 <b>ROYALTY SYSTEM</b>\n` +
            `• Total Points: ${db.users[uid].points || 0}\n` +
            `• Deposit Count: ${db.users[uid].depositCount || 0}x\n` +
            `• Reward Status: Active`;

        if (global.grupNotifDeposit) {
            await autoUpSend(bot, global.grupNotifDeposit, logMsg, global.botUsername);
        }

        // Balas ke owner: konfirmasi sukses
        await ctx.reply(
            `✅ <b>Deposit berhasil dikonfirmasi!</b>\n\n` +
            `👤 User: <code>${uid}</code>\n` +
            `💰 Nominal: <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
            `💳 Saldo baru: <b>Rp ${db.users[uid].saldo.toLocaleString("id-ID")}</b>`,
            { parse_mode: "HTML" }
        );
    });

    // Tombol TOLAK deposit manual oleh owner
    bot.action(/^tolak_dep_owner_(\d+)_(\d+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) {
            return ctx.answerCbQuery("❌ Bukan owner!", { show_alert: true });
        }
        ctx.answerCbQuery();

        const targetUserId = ctx.match[1];
        const nominal      = Number(ctx.match[2]);

        // Edit pesan di chat owner
        try {
            await ctx.editMessageReplyMarkup({
                inline_keyboard: [
                    [{ text: `❌ DITOLAK oleh @${ctx.from.username || "owner"}`, callback_data: "noop_tolak_done" }]
                ]
            });
        } catch {}

        // Notif ke user
        try {
            await bot.telegram.sendMessage(Number(targetUserId),
                `❌ <b>Deposit Ditolak</b>\n\n` +
                `Deposit manual sebesar <b>Rp ${nominal.toLocaleString("id-ID")}</b> ditolak oleh owner.\n\n` +
                `Silakan hubungi CS jika ada pertanyaan.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "💬 Hubungi CS", url: `https://t.me/${global.csUsername || ""}` }],
                            [{ text: "🔙 Menu Utama", callback_data: "back_menu" }]
                        ]
                    }
                }
            );
        } catch {}

        await ctx.reply("❌ Deposit telah ditolak. User sudah dinotifikasi.", { parse_mode: "HTML" });
    });

    // Tombol dummy (sudah diproses, tidak perlu aksi)
    bot.action("noop_acc_done",   async (ctx) => ctx.answerCbQuery());
    bot.action("noop_tolak_done", async (ctx) => ctx.answerCbQuery());

    // Step 1: Buka menu WD → pilih e-wallet
    bot.action("menu_wd", async (ctx) => {
        ctx.answerCbQuery();
        if (!ctx.from) return;
        const userId = ctx.from.id;
        // Hanya owner yang bisa WD
        if (!global.ownerID.includes(String(userId))) {
            return safeEditOrReply(ctx, "❌ Menu ini hanya untuk Owner.", {
                reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] }
            });
        }


        // Cek apakah ada WD pending
        const wdFile = `${wdDir}/${userId}.json`;
        if (fs.existsSync(wdFile)) {
            const wd = safeReadJSON(wdFile, {});
            return safeEditOrReply(ctx,
                `⚠️ <b>Kamu masih punya WD pending</b>\n\n` +
                `💸 Nominal : Rp ${wd.nominal.toLocaleString("id-ID")}\n` +
                `📱 Ke      : ${wd.ewallet} - ${wd.nomor}\n` +
                `🕐 Waktu   : ${wd.created_at}\n\n` +
                `Tunggu owner memproses WD kamu.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "❌ Batalkan WD", callback_data: "wd_cancel" }],
                            [{ text: "⬅ Kembali", callback_data: "back_menu" }]
                        ]
                    }
                }
            );
        }

        const u = getUser(userId, ctx.from.username);
        const rows = [];
        for (let i = 0; i < EWALLET_LIST.length; i += 2) {
            const a = EWALLET_LIST[i], b = EWALLET_LIST[i + 1];
            rows.push([
                { text: `${a.emoji} ${a.nama}`, callback_data: `wd_pilih_${a.id}` },
                b ? { text: `${b.emoji} ${b.nama}`, callback_data: `wd_pilih_${b.id}` } : { text: " ", callback_data: "ignore" }
            ]);
        }
        rows.push([{ text: "⬅ Kembali", callback_data: "back_menu" }]);

        await safeEditOrReply(ctx,
            `<blockquote><b>💸 WITHDRAW SALDO</b></blockquote>\n\n` +
            `💰 Saldo kamu: <b>Rp ${u.saldo.toLocaleString("id-ID")}</b>\n` +
            `📌 Minimal WD: <b>Rp ${global.wdMinimal.toLocaleString("id-ID")}</b>\n\n` +
            `Pilih tujuan e-wallet / bank:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } }
        );
    });

    // Step 2: Pilih e-wallet → minta nomor HP/rekening
    bot.action(/^wd_pilih_(.+)$/, async (ctx) => {
        ctx.answerCbQuery();
        const ewalletId = ctx.match[1];
        const ewallet = EWALLET_LIST.find(e => e.id === ewalletId);
        if (!ewallet) return ctx.reply("❌ E-wallet tidak ditemukan.");

        const userId = ctx.from.id;
        // Simpan pilihan e-wallet ke state
        setState(userId, `wd_nomor_${ewalletId}`);

        await safeEditOrReply(ctx,
            `<blockquote><b>💸 WITHDRAW — ${ewallet.emoji} ${ewallet.nama}</b></blockquote>\n\n` +
            `Masukkan nomor ${ewallet.id.startsWith("b") ? "rekening" : "HP"} tujuan:\n\n` +
            `Contoh: <code>08123456789</code>`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "⬅ Batal", callback_data: "menu_wd" }]] }
            }
        );
    });

    // Step 3: Cancel WD pending (oleh user)
    bot.action("wd_cancel", async (ctx) => {
        ctx.answerCbQuery();
        const userId = String(ctx.from.id);
        const wdFile = `${wdDir}/${userId}.json`;

        if (!fs.existsSync(wdFile)) {
            return safeEditOrReply(ctx, "Tidak ada WD pending.",
                { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
            );
        }

        const wd = safeReadJSON(wdFile, {});
        fs.unlinkSync(wdFile);

        // Notif owner bahwa WD dibatalkan user
        for (const ownerId of global.ownerID) {
            try {
                await bot.telegram.sendMessage(ownerId,
                    `⚠️ <b>WD DIBATALKAN USER</b>\n\n` +
                    `👤 @${wd.username || "?"} (<code>${userId}</code>)\n` +
                    `💸 Rp ${wd.nominal.toLocaleString("id-ID")} → ${wd.ewallet} ${wd.nomor}\n\n` +
                    `User membatalkan permohonan WD sendiri.`,
                    { parse_mode: "HTML" }
                );
            } catch {}
        }

        await safeEditOrReply(ctx, "❌ WD dibatalkan.",
            { reply_markup: { inline_keyboard: [[{ text: "⬅ Menu Utama", callback_data: "back_menu" }]] } }
        );
    });

    // Step 4: Owner ACC WD
    bot.action(/^owner_wd_acc_(\d+)_(.+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        const userId = ctx.match[1];
        const wdId   = ctx.match[2]; // timestamp saat WD dibuat
        const wdFile = `${wdDir}/${userId}.json`;

        if (!fs.existsSync(wdFile)) {
            await ctx.answerCbQuery("⚠️ WD tidak ditemukan (mungkin sudah dibatalkan).", { show_alert: true });
            try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
            return;
        }

        const wd = safeReadJSON(wdFile, {});
        // Validasi ID supaya tidak double-process
        if (String(wd.created_ts) !== String(wdId)) {
            await ctx.answerCbQuery("⚠️ ID WD tidak cocok.", { show_alert: true });
            return;
        }

        // Potong saldo user
        const db = loadDB();
        if (!db.users[userId]) {
            await ctx.answerCbQuery("⚠️ User tidak ditemukan.", { show_alert: true });
            return;
        }

        if (db.users[userId].saldo < wd.nominal) {
            await ctx.answerCbQuery(`⚠️ Saldo user tidak cukup! Saldo: Rp ${db.users[userId].saldo.toLocaleString("id-ID")}`, { show_alert: true });
            return;
        }

        db.users[userId].saldo -= wd.nominal;
        await saveDB(db);
        fs.unlinkSync(wdFile);

        // Simpan ke riwayat transaksi
        await saveFinalTransaction(
            { user_id: userId, service: `WD ${wd.ewallet}`, price: wd.nominal, created_ts: wd.created_ts },
            {
                status: "success",
                finished_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"),
                price_sell: wd.nominal,
                wd_ewallet: wd.ewallet,
                wd_nomor: wd.nomor
            }
        );

        await ctx.answerCbQuery("✅ WD berhasil di-ACC!");

        // Edit pesan owner
        try {
            await ctx.editMessageText(
                ctx.callbackQuery.message.text + `\n\n✅ <b>Di-ACC oleh @${ctx.from.username || "owner"}</b>\n⏰ ${moment().tz("Asia/Jakarta").format("HH:mm:ss")}`,
                { parse_mode: "HTML" }
            );
        } catch {}

        // Notif ke user
        try {
            await bot.telegram.sendMessage(Number(userId),
                `✅ <b>Withdraw Berhasil!</b>\n\n` +
                `💸 Nominal : <b>Rp ${wd.nominal.toLocaleString("id-ID")}</b>\n` +
                `📱 Tujuan  : <b>${wd.ewallet} - ${wd.nomor}</b>\n` +
                `⏰ Waktu   : ${moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")}\n\n` +
                `Dana sedang dikirim oleh owner. Harap tunggu! 🚀`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] } }
            );
        } catch {}

        // Log ke grup
        if (global.grupNotifDeposit) {
            await sendLog(bot, global.grupNotifDeposit,
                `<b>💸 WD BERHASIL</b>\n👤 @${wd.username || "?"} (<code>${userId}</code>)\n💰 Rp ${wd.nominal.toLocaleString("id-ID")}\n📱 ${wd.ewallet} - ${wd.nomor}\n👑 ACC: @${ctx.from.username}`
            );
        }
    });

    // Step 5: Owner Tolak WD
    bot.action(/^owner_wd_tolak_(\d+)_(.+)$/, async (ctx) => {
        if (!global.ownerID.includes(String(ctx.from.id))) return ctx.answerCbQuery("❌ Bukan owner.");
        const userId = ctx.match[1];
        const wdFile = `${wdDir}/${userId}.json`;

        if (!fs.existsSync(wdFile)) {
            await ctx.answerCbQuery("⚠️ WD tidak ditemukan.", { show_alert: true });
            try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
            return;
        }

        const wd = safeReadJSON(wdFile, {});
        fs.unlinkSync(wdFile);

        await ctx.answerCbQuery("❌ WD ditolak.");

        try {
            await ctx.editMessageText(
                ctx.callbackQuery.message.text + `\n\n❌ <b>Ditolak oleh @${ctx.from.username || "owner"}</b>`,
                { parse_mode: "HTML" }
            );
        } catch {}

        // Notif ke user — saldo tidak terpotong
        try {
            await bot.telegram.sendMessage(Number(userId),
                `❌ <b>Withdraw Ditolak</b>\n\n` +
                `Permohonan WD Rp ${wd.nominal.toLocaleString("id-ID")} ke ${wd.ewallet} ${wd.nomor} ditolak oleh owner.\n\n` +
                `Saldo kamu <b>tidak terpotong</b>.\n` +
                `Hubungi owner untuk informasi lebih lanjut.`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] } }
            );
        } catch {}
    });
    bot.action("deposit_ai_helper", async (ctx) => {
        setState(ctx.from.id, "waiting_deposit_problem");
        await safeEditOrReply(ctx,
            `🤖 <b>Asisten AI Deposit</b>\n\nJelaskan kendalamu dalam satu kalimat:\n\n- <code>saldo belum masuk</code>\n- <code>qris error</code>\n- <code>cara deposit</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: "back_menu" }]] } }
        );
        ctx.answerCbQuery();
    });

    // ========================= LAYANAN NOKOS (WARUNGSMS) =========================

    // Handler "menu_layanan" (Beli Nokos) memakai provider smscode.gg — lihat di bawah.

        bot.action("order_refresh", (ctx) => manualCheckOrder(ctx, ctx.from.id));
    bot.action("order_cancel",  (ctx) => cancelOrder(ctx, ctx.from.id));

    // ============================================================
    // ============= HANDLER BELI NOKOS (smscode.gg) ==============
    // ============================================================
    bot.action("menu_layanan", async (ctx) => {
        ctx.answerCbQuery();
        if (isRateLimited(ctx.from.id, 1500)) return;
        if (!global.smscodeApiKey || global.smscodeApiKey === "ISI_TOKEN_SMSCODE_DISINI") {
            return safeEditOrReply(ctx, "⚠️ Fitur Beli Nokos belum aktif.\nOwner: isi <code>global.smscodeApiKey</code> di settings.js dulu.", {
                parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Menu", callback_data: "back_menu" }]] }
            });
        }
        await safeEditOrReply(ctx, "⏳ Memuat daftar negara...", { parse_mode: "HTML" });
        try {
            const countries = await smscodeGetCountries();
            console.log(`[SMSCODE] uid=${ctx.from.id} → ${countries.length} negara`);
            if (!countries.length) {
                return safeEditOrReply(ctx, "❌ Tidak ada negara tersedia saat ini.", {
                    reply_markup: { inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: "menu_layanan" }, { text: "⬅ Menu", callback_data: "back_menu" }]] }
                });
            }
            setSession(ctx.from.id, "countryListV2", countries);
            return showCountryPageV2(ctx, 1);
        } catch (err) {
            console.log("SMSCODE COUNTRIES ERROR:", err.code, err.message);
            let errMsg = `❌ ${err.message}`;
            if (err.isRateLimit) errMsg = `⏳ Server sibuk. Tunggu ${err.retryAfter || 60} detik lalu klik Coba Lagi.`;
            await safeEditOrReply(ctx, errMsg, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: "menu_layanan" }, { text: "⬅ Menu", callback_data: "back_menu" }]] }
            });
        }
    });

    // Layer 1: pagination negara
    bot.action(/^v2cp_(\d+)$/, async (ctx) => { ctx.answerCbQuery(); return showCountryPageV2(ctx, Number(ctx.match[1])); });
    // Layer 1 → 2: pilih negara
    bot.action(/^v2ctr_(\d+)$/, async (ctx) => { ctx.answerCbQuery(); return showAppPageV2(ctx, Number(ctx.match[1]), 1); });
    // Layer 2: pagination aplikasi
    bot.action(/^v2ap_(\d+)_(\d+)$/, async (ctx) => { ctx.answerCbQuery(); return showAppPageV2(ctx, Number(ctx.match[1]), Number(ctx.match[2])); });
    // Layer 2 → 3: pilih aplikasi
    bot.action(/^v2svc_(\d+)_(\d+)$/, async (ctx) => { ctx.answerCbQuery(); return showProductPageV2(ctx, Number(ctx.match[1]), Number(ctx.match[2]), 1); });
    // Layer 3: pagination produk
    bot.action(/^v2pp_(\d+)_(\d+)_(\d+)$/, async (ctx) => { ctx.answerCbQuery(); return showProductPageV2(ctx, Number(ctx.match[1]), Number(ctx.match[2]), Number(ctx.match[3])); });

    // BELI V2: buyv2_{index} → currentProductsV2
    bot.action(/^buyv2_(\d+)$/, async (ctx) => {
        const userId = ctx.from.id;
        const idx    = Number(ctx.match[1]);
        if (isRateLimited(userId, 2000)) return ctx.answerCbQuery("⏳ Terlalu cepat.", { show_alert: true });

        // Cek order pending (file order dipakai bersama V1/V2 → 1 order aktif per user)
        const trxFile = `${trxDir}/${userId}.json`;
        if (fs.existsSync(trxFile)) {
            const existing = safeReadJSON(trxFile, {});
            if (existing.expires_ts && Date.now() > existing.expires_ts) {
                try { fs.unlinkSync(trxFile); } catch {}
            } else {
                return ctx.answerCbQuery("⚠️ Kamu masih punya order pending!", { show_alert: true });
            }
        }

        const currentProducts = getSession(userId).currentProductsV2 || [];
        const item = currentProducts[idx];
        if (!item) return ctx.answerCbQuery("❌ Produk tidak ditemukan. Buka ulang menu.", { show_alert: true });
        const productId = item.product_id; // id numerik smscode

        const harga = item._hargaJual || Number(item.price_api || 0);
        const user  = getUser(userId, ctx.from.username);

        const freshDb    = loadDB();
        const freshSaldo = freshDb.users?.[String(userId)]?.saldo ?? user.saldo;
        if (freshSaldo < harga) {
            return ctx.answerCbQuery(`Saldo tidak cukup. Saldo: Rp ${freshSaldo.toLocaleString("id-ID")}`, { show_alert: true });
        }

        await ctx.answerCbQuery("Membuat order...");
        try {
            const orderData = await smscodeCreateOrder(productId);

            // ANTI-BUG HARGA: cek harga real dari response API (field amount)
            const priceModalReal  = Number(orderData.price || 0);
            const priceModalCache = Number(item.price_api || 0);

            const isOwnerCheck = global.ownerID.includes(String(userId));
            let hargaJualReal = priceModalReal;
            if (!isOwnerCheck) {
                hargaJualReal = user.vip
                    ? Math.round(priceModalReal + priceModalReal * global.profitVip / 100)
                    : Math.round(priceModalReal + priceModalReal * global.profitUser / 100);
            }

            const tolerance = Math.max(50, priceModalCache * 0.1);
            if (priceModalReal > priceModalCache + tolerance) {
                console.warn(`[V2 HARGA NAIK] uid=${userId} pid=${productId} cache=Rp${priceModalCache} real=Rp${priceModalReal}`);
                try { await smscodeCancelOrder(orderData.order_id); } catch (e) { console.warn("Cancel V2 anti-bug gagal:", e.message); }
                return ctx.reply(
                    `⚠️ <b>Harga Berubah!</b>\n\n` +
                    `Harga tampil  : Rp ${priceModalCache.toLocaleString("id-ID")}\n` +
                    `Harga sekarang: Rp ${priceModalReal.toLocaleString("id-ID")}\n\n` +
                    `Order dibatalkan otomatis. Saldo kamu <b>tidak terpotong</b>.\nRefresh menu dan order ulang.`,
                    { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔄 Refresh Menu", callback_data: "menu_layanan" }, { text: "⬅ Menu", callback_data: "back_menu" }]] } }
                );
            }

            if (freshDb.users?.[String(userId)]?.saldo < hargaJualReal) {
                console.warn(`[V2 SALDO KURANG] uid=${userId} saldo=${freshDb.users[String(userId)].saldo} hargaReal=${hargaJualReal}`);
                try { await smscodeCancelOrder(orderData.order_id); } catch {}
                return ctx.reply(
                    `❌ Saldo tidak cukup setelah harga real diketahui.\nHarga real: Rp ${hargaJualReal.toLocaleString("id-ID")}\nOrder dibatalkan.`,
                    { parse_mode: "HTML" }
                );
            }

            const hargaFinal = hargaJualReal;
            freshDb.users[String(userId)].saldo -= hargaFinal;
            await saveDB(freshDb);

            const cancelAfterTs = Date.now() + 2 * 60 * 1000; // smscode: min 2 menit
            const expiresTs = orderData.expired_at
                ? new Date(orderData.expired_at).getTime()
                : (Date.now() + 20 * 60 * 1000);

            fs.writeFileSync(trxFile, JSON.stringify({
                order_id    : orderData.order_id,
                provider    : "smscode",
                user_id     : userId,
                price       : hargaFinal,
                price_api   : priceModalReal,
                created_ts  : Date.now(),
                expires_ts  : expiresTs,
                cancel_after: cancelAfterTs,
                phone_number: orderData.phone_number,
                service     : cleanProductName(orderData.service || item.name || ""),
                country     : ""
            }, null, 2));

            const orderMsg = await ctx.reply(
                `📦 <b>Order Dibuat</b>\n\n` +
                `<b>Order ID:</b> <code>${orderData.order_id}</code>\n` +
                `<b>Layanan:</b> ${cleanProductName(item.name)}\n\n` +
                `<b>Nomor:</b>\n<pre>${orderData.phone_number}</pre>\n\n` +
                `<b>Harga:</b> Rp ${harga.toLocaleString("id-ID")}\n` +
                `⏳ Menunggu OTP (maks 20 menit)\n` +
                `🔒 Tombol batal tersedia setelah <b>2 menit</b>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [
                    [{ text: "📋 Salin Nomor", copy_text: { text: String(orderData.phone_number) } }],
                    [{ text: "🔄 Cek OTP", callback_data: "order_refresh" }]
                ] } }
            );

            try {
                const trxData = safeReadJSON(trxFile, {});
                trxData.msg_chat_id = orderMsg.chat.id;
                trxData.msg_id      = orderMsg.message_id;
                trxData.msg_ids     = [orderMsg.message_id];
                fs.writeFileSync(trxFile, JSON.stringify(trxData, null, 2));
            } catch (e) { console.warn("Save V2 msg_id error:", e.message); }

            setTimeout(async () => {
                if (!fs.existsSync(trxFile)) return;
                try {
                    await bot.telegram.editMessageReplyMarkup(orderMsg.chat.id, orderMsg.message_id, null, {
                        inline_keyboard: [
                            [{ text: "📋 Salin Nomor", copy_text: { text: String(orderData.phone_number) } }],
                            [{ text: "🔄 Cek OTP", callback_data: "order_refresh" }, { text: "❌ Batalkan Order", callback_data: "order_cancel" }]
                        ]
                    });
                } catch {}
            }, 2 * 60 * 1000);

            startPollingOrder(bot, ctx, userId, orderData.order_id);
        } catch (err) {
            console.log("V2 CREATE ORDER ERROR:", err.code, err.message);
            ctx.reply("❌ Gagal membuat order: " + err.message);
        }
    });
    // ===================== END NOKOS V2 =========================

    // FIX BUG: handler "ignore" untuk tombol placeholder (menu WD tombol kosong)
    // Tanpa ini, Telegram akan menampilkan loading spinner yang tidak berhenti
    bot.action("ignore", async (ctx) => {
        try { await ctx.answerCbQuery(); } catch {}
    });

    // ========================= SEARCH APP V2 =========================
    bot.action("search_app_v2", async (ctx) => {
        // simpan negara yang sedang dipilih agar hasil cari bisa diarahkan ke v2svc
        const cIdx = getSession(ctx.from.id).currentCtrIdxV2;
        if (cIdx === undefined || cIdx === null) {
            return ctx.answerCbQuery("Pilih negara dulu sebelum cari.", { show_alert: true });
        }
        setState(ctx.from.id, `search_app_v2_${cIdx}`);
        await safeEditOrReply(ctx, `🔍 <b>Cari Aplikasi Nokos</b>\n\nKetik minimal 3 huruf (contoh: <code>gram</code>, <code>wa</code>)`, { parse_mode: "HTML" });
        ctx.answerCbQuery();
    });


    // ========================= BACK TO MENU =========================
    bot.action("back_menu", async (ctx) => {
        try { await ctx.answerCbQuery(); } catch {}
        // FIX: await deleteMessage supaya pesan lama sudah hilang sebelum menu baru muncul
        // Tanpa await, deleteMessage dan kirimMenuUtama bisa berjalan bersamaan → double pesan
        if (ctx.callbackQuery?.message) {
            try {
                await ctx.telegram.deleteMessage(ctx.chat.id, ctx.callbackQuery.message.message_id);
            } catch {}
        }
        try { return await kirimMenuUtama(bot, ctx); } catch (e) { console.error("BACK MENU ERROR:", e.message); }
    });

    // ========================= PHOTO HANDLER (Deposit ke Owner) =========================
    bot.on("photo", async (ctx) => {
        const userId = ctx.from.id;
        const state  = getState(userId);

        if (state !== "waiting_deposit_owner_proof") return; // abaikan foto di luar konteks ini

        const caption  = (ctx.message.caption || "").trim();
        const nominal  = Number(caption.replace(/[^0-9]/g, ""));
        const minimal  = global.depositOwnerMinimal || 5000;

        if (isNaN(nominal) || nominal < minimal) {
            return ctx.reply(
                `❌ <b>Nominal tidak valid atau terlalu kecil.</b>\n\n` +
                `Minimal deposit: <b>Rp ${minimal.toLocaleString("id-ID")}</b>\n\n` +
                `Kirim ulang foto dengan caption berupa nominal deposit.\n` +
                `Contoh caption: <code>10000</code>`,
                { parse_mode: "HTML" }
            );
        }

        clearState(userId);

        const u       = getUser(userId, ctx.from.username);
        const fileId  = ctx.message.photo[ctx.message.photo.length - 1].file_id;
        const waktu   = moment().tz("Asia/Jakarta");
        const nama    = ctx.from.first_name || ctx.from.username || String(userId);

        // Konfirmasi ke user bahwa permintaan sudah diterima
        await ctx.reply(
            `✅ <b>Bukti diterima!</b>\n\n` +
            `📋 Nominal: <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
            `⏳ Menunggu konfirmasi owner...\n\n` +
            `Saldo akan ditambah setelah owner melakukan konfirmasi. 🙏`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "🔙 Menu Utama", callback_data: "back_menu" }]] }
            }
        );

        // Kirim ke semua owner: foto bukti + tombol ACC/TOLAK
        const ownerCaption =
            `🏧 <b>PERMOHONAN DEPOSIT MANUAL</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `👤 Nama  : ${nama}\n` +
            `🆔 User ID: <code>${userId}</code>\n` +
            `📱 Username: @${ctx.from.username || "-"}\n` +
            `💰 Nominal: <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
            `🕐 Waktu  : ${waktu.format("DD MMM YYYY HH:mm:ss")} WIB\n\n` +
            `💳 Saldo user saat ini: <b>Rp ${u.saldo.toLocaleString("id-ID")}</b>\n\n` +
            `<i>Tekan ACC untuk konfirmasi & tambah saldo, atau TOLAK untuk menolak.</i>`;

        const ownerKeyboard = {
            inline_keyboard: [
                [
                    { text: `✅ ACC +Rp ${nominal.toLocaleString("id-ID")}`, callback_data: `acc_dep_owner_${userId}_${nominal}` },
                    { text: "❌ TOLAK", callback_data: `tolak_dep_owner_${userId}_${nominal}` }
                ]
            ]
        };

        for (const ownerId of global.ownerID) {
            try {
                await bot.telegram.sendPhoto(Number(ownerId), fileId, {
                    caption: ownerCaption,
                    parse_mode: "HTML",
                    reply_markup: ownerKeyboard
                });
            } catch (e) {
                console.warn(`[DEPOSIT OWNER] Gagal kirim ke owner ${ownerId}:`, e.message);
            }
        }
    });

    // ========================= TEXT HANDLER =========================
    bot.on("text", async (ctx) => {
        const userId = ctx.from.id;
        const state = getState(userId);
        const text = ctx.message.text.trim();

        // ===== ADMIN: TAMBAH/KURANGI SALDO USER =====
        if (state === "admin_input_add_saldo" || state === "admin_input_minus_saldo") {
            if (!global.ownerID.includes(String(userId))) { clearState(userId); return; }
            clearState(userId);

            const parts = text.split(/\s+/);
            if (parts.length < 2) return ctx.reply("❌ Format salah. Contoh: <code>8506098180 10000</code>", { parse_mode: "HTML" });
            const targetId = String(parts[0]);
            const nominal  = Number(parts[1].replace(/[^0-9]/g, ""));
            if (isNaN(nominal) || nominal <= 0) return ctx.reply("❌ Nominal tidak valid.");

            const db = loadDB();
            if (!db.users[targetId]) {
                // Auto-buat user kalau belum ada
                db.users[targetId] = { id: targetId, username: "", registered: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss"), saldo: 0, vip: false };
            }
            const before = db.users[targetId].saldo || 0;
            const isAdd  = state === "admin_input_add_saldo";
            if (isAdd) db.users[targetId].saldo = before + nominal;
            else       db.users[targetId].saldo = Math.max(0, before - nominal);
            await saveDB(db);

            const after = db.users[targetId].saldo;
            const u     = db.users[targetId];

            await ctx.reply(
                `${isAdd ? "➕" : "➖"} <b>Saldo Berhasil ${isAdd ? "Ditambah" : "Dikurangi"}!</b>\n\n` +
                `👤 User: @${u.username || "?"} (<code>${targetId}</code>)\n` +
                `💵 Sebelum: Rp ${before.toLocaleString("id-ID")}\n` +
                `${isAdd ? "➕" : "➖"} ${isAdd ? "Ditambah" : "Dikurangi"}: Rp ${nominal.toLocaleString("id-ID")}\n` +
                `💰 Sekarang: <b>Rp ${after.toLocaleString("id-ID")}</b>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Admin Panel", callback_data: "admin_panel" }]] } }
            );

            // Notif user
            try {
                await bot.telegram.sendMessage(Number(targetId),
                    `${isAdd ? "💰" : "⚠️"} <b>Saldo Kamu ${isAdd ? "Bertambah" : "Berkurang"}</b>\n\n` +
                    `${isAdd ? "➕" : "➖"} ${nominal.toLocaleString("id-ID")} Rupiah\n` +
                    `💳 Saldo sekarang: <b>Rp ${after.toLocaleString("id-ID")}</b>\n\n` +
                    `Disesuaikan oleh owner.`,
                    { parse_mode: "HTML" }
                );
            } catch (e) { console.warn("Notif user gagal:", e.message); }
            return;
        }

        // ===== ADMIN: TAMBAH PRODUK MANUAL =====
        if (state === "admin_manual_add_input") {
            if (!global.ownerID.includes(String(userId))) { clearState(userId); return; }
            clearState(userId);

            const parts = text.split("|").map(s => s.trim());
            if (parts.length < 3) return ctx.reply("❌ Format salah.\nContoh: <code>Netflix 1 Bulan | 25000 | 10 | Akun share</code>", { parse_mode: "HTML" });

            const name  = parts[0];
            const price = Number(parts[1].replace(/[^0-9]/g, ""));
            const stock = Number(parts[2].replace(/[^0-9]/g, ""));
            const desc  = parts[3] || "";

            if (!name || isNaN(price) || price <= 0 || isNaN(stock) || stock < 0) {
                return ctx.reply("❌ Data tidak valid. Pastikan harga & stok angka.");
            }

            const products = loadManualProducts();
            const newProd  = {
                id   : `MP${Date.now()}`,
                name, price, stock, desc,
                created_at: moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
            };
            products.push(newProd);
            await saveManualProducts(products);

            return ctx.reply(
                `✅ <b>Produk Berhasil Ditambah!</b>\n\n` +
                `📦 Nama : <b>${name}</b>\n` +
                `💰 Harga: Rp ${price.toLocaleString("id-ID")}\n` +
                `📦 Stok : ${stock}\n` +
                (desc ? `📝 Desk : ${desc}\n` : "") +
                `🆔 ID   : <code>${newProd.id}</code>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kelola Produk", callback_data: "admin_manual" }]] } }
            );
        }

        // ===== ADMIN: EDIT PRODUK MANUAL =====
        if (state && state.startsWith("admin_manual_edit_input_")) {
            if (!global.ownerID.includes(String(userId))) { clearState(userId); return; }
            const pid = state.replace("admin_manual_edit_input_", "");
            clearState(userId);

            const parts = text.split("|").map(s => s.trim());
            if (parts.length < 3) return ctx.reply("❌ Format salah.", { parse_mode: "HTML" });

            const name  = parts[0];
            const price = Number(parts[1].replace(/[^0-9]/g, ""));
            const stock = Number(parts[2].replace(/[^0-9]/g, ""));
            const desc  = parts[3] || "";

            if (!name || isNaN(price) || isNaN(stock)) return ctx.reply("❌ Data tidak valid.");

            const products = loadManualProducts();
            const idx = products.findIndex(p => p.id === pid);
            if (idx === -1) return ctx.reply("❌ Produk tidak ada.");

            products[idx] = { ...products[idx], name, price, stock, desc };
            await saveManualProducts(products);

            return ctx.reply(
                `✅ <b>Produk Berhasil Diedit!</b>\n\n📦 ${name}\n💰 Rp ${price.toLocaleString("id-ID")}\n📦 Stok: ${stock}`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Kelola Produk", callback_data: "admin_manual" }]] } }
            );
        }

        // ===== DEPOSIT NOMINAL =====
        if (state === "waiting_amount") {
            const amount = Number(text.replace(/[^0-9]/g, ""));
            if (isNaN(amount) || amount < 2000) return ctx.reply("❌ Nominal tidak valid. Minimal Rp 2.000.");
            clearState(userId);
            return createDeposit(bot, ctx, userId, amount);
        }

        // ===== WD: INPUT NOMOR HP / REKENING =====
        if (state && state.startsWith("wd_nomor_")) {
            const ewalletId = state.replace("wd_nomor_", "");
            const ewallet   = EWALLET_LIST.find(e => e.id === ewalletId);
            if (!ewallet) { clearState(userId); return ctx.reply("❌ E-wallet tidak valid."); }

            const nomor = text.replace(/[^0-9]/g, "");
            if (nomor.length < 8 || nomor.length > 20) {
                return ctx.reply("❌ Nomor tidak valid. Masukkan nomor HP/rekening yang benar.");
            }

            // Simpan nomor, minta nominal
            setState(userId, `wd_nominal_${ewalletId}_${nomor}`);

            const u = getUser(userId, ctx.from.username);
            return ctx.reply(
                `<blockquote><b>💸 WITHDRAW — ${ewallet.emoji} ${ewallet.nama}</b></blockquote>\n\n` +
                `📱 Nomor    : <b>${nomor}</b>\n` +
                `💰 Saldo mu : <b>Rp ${u.saldo.toLocaleString("id-ID")}</b>\n` +
                `📌 Minimal  : <b>Rp ${global.wdMinimal.toLocaleString("id-ID")}</b>\n\n` +
                `Masukkan nominal WD:`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "❌ Batal", callback_data: "menu_wd" }]] }
                }
            );
        }

        // ===== WD: INPUT NOMINAL =====
        if (state && state.startsWith("wd_nominal_")) {
            const parts      = state.replace("wd_nominal_", "").split("_");
            const ewalletId  = parts[0];
            const nomor      = parts[1];
            const ewallet    = EWALLET_LIST.find(e => e.id === ewalletId);
            if (!ewallet) { clearState(userId); return ctx.reply("❌ E-wallet tidak valid."); }

            const nominal = Number(text.replace(/[^0-9]/g, ""));
            if (isNaN(nominal) || nominal < global.wdMinimal) {
                return ctx.reply(`❌ Nominal WD minimal Rp ${global.wdMinimal.toLocaleString("id-ID")}.`);
            }
            if (isRateLimited(userId, 3000)) return ctx.reply("⏳ Tunggu sebentar.");

            // Re-read saldo segar dari DB
            const freshDb2   = loadDB();
            const u          = freshDb2.users?.[userId] || getUser(userId, ctx.from.username);
            if (u.saldo < nominal) {
                return ctx.reply(
                    `❌ Saldo tidak cukup.\n\n` +
                    `Saldo kamu : Rp ${u.saldo.toLocaleString("id-ID")}\n` +
                    `Nominal WD : Rp ${nominal.toLocaleString("id-ID")}`
                );
            }

            clearState(userId);

            // Cek WD pending
            const wdFile = `${wdDir}/${userId}.json`;
            if (fs.existsSync(wdFile)) {
                return ctx.reply("⚠️ Kamu masih punya WD pending. Tunggu diproses owner dulu.");
            }

            const now       = moment().tz("Asia/Jakarta");
            const createdTs = Date.now();

            // Simpan WD pending
            const wdData = {
                user_id:    String(userId),
                username:   ctx.from.username || "",
                ewallet:    ewallet.nama,
                ewallet_id: ewalletId,
                nomor,
                nominal,
                created_at: now.format("YYYY-MM-DD HH:mm:ss"),
                created_ts: createdTs,
                status:     "pending"
            };
            fs.writeFileSync(wdFile, JSON.stringify(wdData, null, 2));

            // Konfirmasi ke user
            await ctx.reply(
                `<blockquote><b>📋 KONFIRMASI WITHDRAW</b></blockquote>\n\n` +
                `📱 E-Wallet : <b>${ewallet.emoji} ${ewallet.nama}</b>\n` +
                `🔢 Nomor    : <b>${nomor}</b>\n` +
                `💸 Nominal  : <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
                `💰 Sisa Saldo: <b>Rp ${(u.saldo - nominal).toLocaleString("id-ID")}</b>\n\n` +
                `⏳ Permohonan WD kamu sudah dikirim ke owner.\nTunggu konfirmasi! Saldo belum terpotong.`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "❌ Batalkan WD", callback_data: "wd_cancel" }],
                            [{ text: "🔙 Menu Utama", callback_data: "back_menu" }]
                        ]
                    }
                }
            );

            // Kirim permohonan ke owner
            const notifOwner =
                `<b>📩 PERMOHONAN WITHDRAW</b>\n\n` +
                `👤 User    : @${ctx.from.username || "unknown"}\n` +
                `🆔 ID      : <code>${userId}</code>\n` +
                `📱 E-Wallet: <b>${ewallet.emoji} ${ewallet.nama}</b>\n` +
                `🔢 Nomor   : <b>${nomor}</b>\n` +
                `💸 Nominal : <b>Rp ${nominal.toLocaleString("id-ID")}</b>\n` +
                `💰 Saldo   : Rp ${u.saldo.toLocaleString("id-ID")}\n` +
                `⏰ Waktu   : ${now.format("YYYY-MM-DD HH:mm:ss")}\n\n` +
                `Klik <b>✅ ACC</b> untuk setujui atau <b>❌ Tolak</b>.`;

            for (const ownerId of global.ownerID) {
                try {
                    await bot.telegram.sendMessage(Number(ownerId), notifOwner, {
                        parse_mode: "HTML",
                        reply_markup: {
                            inline_keyboard: [[
                                { text: "✅ ACC WD", callback_data: `owner_wd_acc_${userId}_${createdTs}` },
                                { text: "❌ Tolak", callback_data: `owner_wd_tolak_${userId}_${createdTs}` }
                            ]]
                        }
                    });
                } catch (e) { console.warn(`NOTIF OWNER WD [${ownerId}]:`, e.message); }
            }
            return;
        }


        if (state === "waiting_deposit_problem") {
            clearState(userId);
            const t = text.toLowerCase();
            let reply = "";
            if (t.includes("saldo") && (t.includes("masuk") || t.includes("nambah"))) {
                reply = `🤖 <b>Saldo Belum Masuk</b>\n\n1. Pastikan transfer <b>SAMA PERSIS</b> (termasuk kode unik).\n2. Sistem otomatis mendeteksi dalam 1-3 menit.\n3. Jika lebih 30 menit, hubungi owner.`;
            } else if (t.includes("qris") || t.includes("qr") || t.includes("error")) {
                reply = `🤖 <b>Masalah QRIS</b>\n\n1. Coba buat deposit baru.\n2. Gunakan e-wallet (GoPay/DANA/OVO) atau m-banking.\n3. Pastikan API key RamaShop valid.\n\nMasalah berlanjut? Hubungi owner.`;
            } else if (t.includes("cara") || t.includes("gimana")) {
                reply = `🤖 <b>Cara Deposit</b>\n\n1. Klik 💰 Deposit\n2. Pilih nominal (minimal Rp 2.000)\n3. Scan QRIS di e-wallet/m-banking\n4. Transfer SAMA PERSIS (termasuk kode unik)\n5. Tunggu 1-3 menit — saldo masuk otomatis!`;
            } else {
                reply = `🤖 Tidak terdeteksi masalahmu. Coba jelaskan lebih spesifik atau hubungi owner langsung.`;
            }
            return ctx.reply(reply, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅ Menu", callback_data: "back_menu" }]] } });
        }

        // ===== SEARCH APP V2 (smscode) =====
        if (state && state.startsWith("search_app_v2")) {
            const cIdx = Number(state.replace("search_app_v2_", "")) || 0;
            clearState(userId);
            if (text.length < 3) return ctx.reply("❌ Minimal 3 huruf.");
            const services = getSession(userId).serviceListV2 || [];
            const kw = text.toLowerCase().trim();
            // cari + simpan index asli di serviceListV2 supaya callback v2svc benar
            const matched = [];
            services.forEach((svc, i) => {
                if ((svc.name || "").toLowerCase().includes(kw) || (svc.code || "").toLowerCase().includes(kw)) {
                    matched.push({ svc, i });
                }
            });
            if (!matched.length) return ctx.reply("❌ Aplikasi tidak ditemukan.", { reply_markup: { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: `v2ctr_${cIdx}` }]] } });

            let rows = [];
            for (let k = 0; k < Math.min(matched.length, 20); k += 2) {
                const a = matched[k], b = matched[k + 1];
                const row = [{ text: a.svc.name, callback_data: `v2svc_${cIdx}_${a.i}` }];
                if (b) row.push({ text: b.svc.name, callback_data: `v2svc_${cIdx}_${b.i}` });
                rows.push(row);
            }
            rows.push([{ text: "⬅ Kembali", callback_data: `v2ctr_${cIdx}` }]);
            return ctx.reply(`🔎 Ditemukan ${matched.length} aplikasi`, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
        }

    });

    // ===== AUTO UPDATE HARGA (Callback Harga) =====
    if (global.hargaMonitorOn) {
        const mins = Math.max(5, Number(global.hargaIntervalMenit) || 30);
        setTimeout(() => runHargaMonitor(bot, { firstRun: true }), 20000); // baseline (tanpa broadcast)
        const hi = setInterval(() => runHargaMonitor(bot), mins * 60 * 1000);
        registerPolling("harga_monitor", hi);
        console.log(`[HARGA] Monitor harga aktif tiap ${mins} menit → @${global.hargaChannel || global.wajibJoinHarga || "(channel belum diset)"}`);
    }

}

// ======================================================
// ====================== HOT RELOAD ====================
// ======================================================

const file = import.meta.url;
fs.watchFile(new URL(file), () => {
    fs.unwatchFile(new URL(file));
    console.log(chalk.redBright(`🔄 Update ${file}`));
    process.exit(0);
});
