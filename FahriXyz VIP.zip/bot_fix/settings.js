
// ================= SETTINGS GLOBAL =================

global.botToken      = "8673413428:AAG0E5Usrx-O4VoZdGbihvo6wzHt0Oany-Y";
global.ownerID       = ["7343282193"];
global.ownerUsername = "Fahr1XyZ";
global.botName       = "FahriXyz Shop OTP";

// ⚠️ WAJIB: username bot tanpa @ (untuk link ORDER SEKARANG)
global.botUsername   = "FahriXyz_OTP_bot";  // Username bot TANPA @ - sesuai @FahriXyz_OTP_bot

// ============== WAJIB JOIN ==============
// Isi username TANPA @ (hanya username saja)
// Bot HARUS menjadi Admin di KEDUA channel ini agar verifikasi berjalan!
// KEDUANYA adalah CHANNEL (bukan grup) — bot perlu permission "Read Messages" sebagai admin
global.wajibJoinSaluran     = "FahriXyz_OTP";      // Channel Utama TANPA @ (wajib bot jadi admin)
global.wajibJoinSaluranNama = "📢 Channel Utama";   // Nama tampilan channel utama
global.wajibJoinGrup        = "Proof_Fahr1Xyz";     // Channel Log Transaksi TANPA @ (wajib bot jadi admin)
global.wajibJoinGrupNama    = "📋 Log Transaksi";   // Nama tampilan channel log

// Channel CEK HARGA (notif harga naik/turun) — WAJIB JOIN juga
// Isi username channel TANPA @ (bot HARUS jadi admin di channel ini agar verifikasi jalan)
// Kosongkan ("") jika belum dibuat agar tidak dipakai sebagai syarat join.
global.wajibJoinHarga     = "FahriXy";                  // contoh: "FahriXyz_Harga" (TANPA @)
global.wajibJoinHargaNama = "📊 Info Harga";     // Nama tampilan channel cek harga

// ============== AUTO UP TRANSAKSI (Channel broadcast notif) ==============
// Username channel TANPA @ tempat notif ORDER & DEPOSIT di-broadcast
// Bot HARUS menjadi Admin di channel ini dengan permission "Post Messages"
// Contoh: "Proof_Fahr1Xyz"
global.autoUpChannel = "Proof_Fahr1Xyz";

// ===================== NOKOS API (mbjebe.store) =====================
// Provider: mbjebe.store — Server 3
// Docs: https://mbjebe.store/api-docs
// Cara dapat key: Login mbjebe.store → Profil → Developer API → Generate API Key
// ===================== PROVIDER NOKOS (smscode.gg) =====================
// Provider OTP/nomor virtual = smscode.gg (API v1 / IDR)
// Docs: https://smscode.gg/docs
// Token: Login smscode.gg → Account Settings → Generate API Token
global.smscodeApiKey = "6a73326a18756a47fbbf11e3571e62868d61e86daecfb8221dd3281eeb9c50a3";

// ===================== GATEWAY QRIS DEPOSIT (Cashi.id) =====================
// Top up saldo USER ke bot pakai Cashi.id (nominal PAS, settle langsung ke saldo merchant).
// Docs: https://cashi.id/documentation  | Base: https://cashi.id/api
// Cara dapat key: daftar di cashi.id → Portal Merchant → ambil API Key.
global.depositGateway = "cashi";                 // gateway aktif: "cashi" (only)
global.cashiApiKey    = "8fcc8a30d3e7bfffb73987d99ff45dc63a0e24879a768334bfd25a4d5da44954"; // API key dari dashboard Cashi.id
global.cashiQrisCustom = false;                  // true = nama merchant di QRIS jadi nama toko (aktifkan dulu fiturnya di dashboard Cashi)
global.cashiReferer    = "";                     // opsional: isi domain bila Cashi pakai domain lock (header Referer/Origin)

// ===================== AUTO UPDATE HARGA (Callback Harga) =====================
// Bot cek harga smscode tiap interval, deteksi NAIK/TURUN, lalu broadcast ke channel.
global.hargaMonitorOn   = true;                  // true = aktifkan auto update harga
// Pantau BANYAK aplikasi populer × BANYAK negara (nama sesuai di smscode).
global.hargaApps        = ["WhatsApp", "Telegram", "Facebook", "Google", "Instagram"];
global.hargaCountries   = ["Indonesia", "Malaysia", " philippinensis"];         // bisa tambah negara lain, mis: ["Indonesia","Malaysia","Philippines"]
global.hargaIntervalMenit = 30;                  // cek harga tiap N menit
global.hargaChannel     = "FahriXy";                    // username channel broadcast TANPA @ (bot HARUS admin). Kosong = pakai wajibJoinHarga
// (fallback lama bila hargaApps/hargaCountries dikosongkan)
global.hargaServiceName = "Telegram";
global.hargaCountryName = "Indonesia";

// ===================== CHECK-IN HARIAN =====================
global.checkinHari1    = 100;
global.checkinHari2    = 150;
global.checkinHari3    = 200;
global.checkinHari4    = 250;
global.checkinHari5    = 300;
global.checkinHari6    = 400;
global.checkinHari7plus = 500;

// ===================== SISTEM WITHDRAW =====================
global.wdMinimal = 10000;

// ===================== REFERRAL =====================
global.referralPersen = 5;

// ===================== PROFIT (markup harga jual) =====================
global.profitUser = 65; // % untuk user biasa
global.profitVip  = 0; // % untuk user VIP

global.menuImages = [
    "https://files.catbox.moe/67j8qo.png",
    "https://files.catbox.moe/67j8qo.png",
    "https://files.catbox.moe/67j8qo.png"
];

// ============== DEPOSIT KE OWNER (Manual QRIS) ==============
// Ganti URL di bawah dengan link foto QRIS milik owner
// Upload foto QRIS ke https://catbox.moe lalu paste link-nya di sini
global.qrisOwnerImage   = "https://files.catbox.moe/ji0s3b.jpg";
// Minimal nominal deposit manual ke owner (dalam Rupiah)
global.depositOwnerMinimal = 2000;

// ============== GRUP & NOTIFIKASI =============
// Username grup/channel TANPA @ atau numeric chat ID (misal: -1001234567890)
// Untuk notif WD, deposit, & maintenance
global.grubinformasilink  = "https://t.me/FahriXyz_OTP";   // channel Informasi FahriXyz Shop (Infomasi)
global.grubinformasi  = "@FahriXyz_OTP";   // channel Informasi FahriXyz Shop (Infomasi/Maintenance)
global.grupNotifDeposit   = "@Proof_Fahr1Xyz";   // notif deposit & WD ke channel log transaksi
global.grupNotifPembelian = "@Proof_Fahr1Xyz";   // notif order pembelian ke channel log transaksi


// ============== TOMBOL CHANNEL DI NOTIF TRANSAKSI =============
// 4 tombol yang muncul di bawah setiap notif transaksi di channel
// Sesuai tampilan profesional: CS | Order | Channel | Callback
global.csUsername      = "Fahr1Xyz";          // Customer Service TANPA @ → @Fahr1Xyz
global.callbackChannel = "Proof_Fahr1Xyz";  // Callback Transaksi TANPA @ → @FahriXyz_ShopTrx
global.callbackHarga = "FahriXy";  // Callback Harga TANPA @ → @FahriXy
// global.botUsername & global.wajibJoinSaluran sudah diset di atas (Order Layanan & Channel Utama)

// ============== LAPORAN OTOMATIS =============
global.laporanHarian   = true;
global.laporanMingguan = true;
global.laporanBulanan  = true;

// ============== MAINTENANCE OTOMATIS =============
global.maintenanceEnabled = true;
global.maintenanceStart   = "23:00";
global.maintenanceEnd     = "00:10";
