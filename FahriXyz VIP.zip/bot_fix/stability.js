// ======================================================
// =================== STABILITY MODULE =================
// Diimport di main.js dan index.js
// Menyelesaikan 6 masalah stabilitas untuk 700+ user
// ======================================================

import fs from "fs";

// ── 1. RATE LIMITER per user ───────────────────────────
const userLastAction = new Map();
export function isRateLimited(userId, limitMs = 1500) {
    const now = Date.now();
    const last = userLastAction.get(String(userId)) || 0;
    if (now - last < limitMs) return true;
    userLastAction.set(String(userId), now);
    return false;
}
setInterval(() => userLastAction.clear(), 10 * 60 * 1000);

// ── 2. PER-USER SESSION (gantikan global.appList shared) ──
// Setiap user punya browsing state sendiri, tidak saling timpa
const _sessions = new Map();
const SESSION_MAX_ENTRIES = 2000; // maks 2000 user aktif di memory sekaligus

export function getSession(userId) {
    const k = String(userId);
    if (!_sessions.has(k)) {
        // Jika sudah mencapai batas, hapus yang terlama
        if (_sessions.size >= SESSION_MAX_ENTRIES) {
            let oldestKey = null, oldestTs = Infinity;
            for (const [uk, us] of _sessions) {
                if ((us.__ts || 0) < oldestTs) { oldestTs = us.__ts; oldestKey = uk; }
            }
            if (oldestKey) _sessions.delete(oldestKey);
        }
        _sessions.set(k, { __ts: Date.now() });
    } else {
        _sessions.get(k).__ts = Date.now();
    }
    return _sessions.get(k);
}
export function setSession(userId, key, val) {
    const s = getSession(userId);
    s[key] = val;
    s.__ts  = Date.now();
}
// Bersihkan session tidak aktif setiap 20 menit (hemat RAM untuk ribuan user)
setInterval(() => {
    const cutoff = Date.now() - 20 * 60 * 1000;
    let deleted = 0;
    for (const [uid, s] of _sessions) {
        if ((s.__ts || 0) < cutoff) { _sessions.delete(uid); deleted++; }
    }
    if (deleted > 0) console.log(`[SESSION GC] Cleaned ${deleted} sessions. Active: ${_sessions.size}`);
}, 20 * 60 * 1000);

// ── 3. ACTIVE POLLING TRACKER (cegah orphan interval) ──
const _pollingMap = new Map();
export function registerPolling(key, intervalId) {
    const old = _pollingMap.get(key);
    if (old) clearInterval(old); // bunuh lama kalau ada
    _pollingMap.set(key, intervalId);
}
export function unregisterPolling(key) {
    _pollingMap.delete(key);
}

// ── 4. WRITE QUEUE (cegah race condition tulis bersamaan) ──
const _writeQueue = [];
let _writeBusy = false;
export function queueWrite(fn) {
    return new Promise((resolve, reject) => {
        _writeQueue.push({ fn, resolve, reject });
        _processQueue();
    });
}
async function _processQueue() {
    if (_writeBusy || _writeQueue.length === 0) return;
    _writeBusy = true;
    const { fn, resolve, reject } = _writeQueue.shift();
    try { resolve(await fn()); }
    catch (e) { reject(e); }
    finally { _writeBusy = false; _processQueue(); }
}

// ── 5. SAFE READ JSON (cegah crash file korup) ──────────
export function safeReadJSON(filePath, defaultVal = {}) {
    try {
        if (!fs.existsSync(filePath)) return defaultVal;
        const raw = fs.readFileSync(filePath, "utf-8");
        if (!raw || raw.trim() === "") return defaultVal;
        return JSON.parse(raw);
    } catch {
        console.warn(`[SAFE READ] File korup atau kosong: ${filePath}`);
        // Backup file rusak
        try { fs.renameSync(filePath, filePath + ".corrupt." + Date.now()); } catch {}
        return defaultVal;
    }
}

// ── 6. SAFE SEND (cegah crash kalau user blokir bot) ────
export async function safeSend(telegram, chatId, text, options = {}) {
    try {
        return await telegram.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
    } catch (e) {
        const desc = e?.description || e?.message || "";
        const ignored = ["bot was blocked", "chat not found", "user is deactivated", "PEER_ID_INVALID"];
        if (!ignored.some(s => desc.includes(s))) {
            console.warn(`[SAFE SEND → ${chatId}] ${desc}`);
        }
    }
}

// ── 7. SLEEP ─────────────────────────────────────────────
export function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// ── 8. AXIOS DENGAN RETRY + TIMEOUT + CIRCUIT BREAKER ──────
import axios from "axios";

// Circuit breaker: track failure per host, skip jika terlalu banyak gagal
const _failCount = new Map();
const _circuitOpen = new Map();
function _recordFail(host) {
    const n = (_failCount.get(host) || 0) + 1;
    _failCount.set(host, n);
    if (n >= 5) {
        _circuitOpen.set(host, Date.now() + 30000); // buka circuit 30 detik
        console.warn(`[CIRCUIT] Host ${host} dinonaktifkan 30 detik (${n} kegagalan beruntun)`);
    }
}
function _recordSuccess(host) { _failCount.set(host, 0); _circuitOpen.delete(host); }
function _isCircuitOpen(host) {
    const until = _circuitOpen.get(host);
    if (!until) return false;
    if (Date.now() > until) { _circuitOpen.delete(host); _failCount.set(host, 0); return false; }
    return true;
}

export async function axiosWithRetry(config, retries = 3, delayMs = 800) {
    let host = "";
    try { host = new URL(config.url).hostname; } catch {}

    if (_isCircuitOpen(host)) {
        throw new Error(`Service ${host} sedang tidak tersedia sementara, coba lagi dalam 30 detik`);
    }

    for (let i = 0; i < retries; i++) {
        try {
            const res = await axios({ timeout: 15000, ...config });
            _recordSuccess(host);
            return res;
        } catch (err) {
            const isLast = i === retries - 1;
            if (isLast) { _recordFail(host); throw err; }
            const code = err?.response?.status;
            // Jangan retry 4xx (kecuali 429 Too Many Requests)
            if (code && code >= 400 && code !== 429 && code < 500) { _recordFail(host); throw err; }
            await sleep(delayMs * (i + 1));
        }
    }
}
